var tNet = 
{
		Node0: {
				label : "Attack",
				id : "1",
				level : 1,
				layer : 1,
				analytic : "Attack",
				inputs : ["2","3"],
				angle: 0.10170158144709107
		},
		Node1: {
				label : "Communication",
				id : "2",
				level : 1,
				layer : 2,
				analytic : "Communication",
				subNodes : ["2.1","2.2"],
				angle: 0.905341531273521
		},
		Node2: {
				label : "GatherInfo",
				id : "3",
				level : 1,
				layer : 2,
				analytic : "GatherInfo",
				subNodes : ["3.1","3.2"],
				angle: 0.4876252349733061
		},
		Node3: {
				label : "Eml",
				id : "2.1",
				level : 2,
				layer : 3,
				analytic : "Eml",
				subselect : "x1",
				threshold : [0.85],
				angle: 0.5855577641775368
		},
		Node4: {
				label : "LOF",
				id : "2.2",
				level : 2,
				layer : 3,
				analytic : "LOF",
				subselect : "x2",
				threshold : [0.005],
				angle: 0.25334287575373726
		},
		Node5: {
				label : "HTTP",
				id : "3.1",
				level : 2,
				layer : 3,
				analytic : "HTTP",
				subselect : "x3",
				threshold : [0.3],
				angle: 0.4076328880002318
		},
		Node6: {
				label : "queryTerm",
				id : "3.2",
				level : 2,
				layer : 3,
				analytic : "queryTerm",
				subselect : "x4",
				threshold : [0.3],
				subNodes : ["3.2.1","3.2.2"],
				angle: 0.6932791352911795
		},
		Node7: {
				label : "A1",
				id : "3.2.1",
				level : 3,
				layer : 4,
				analytic : "A1",
				subselect : "x5",
				threshold : [0.86],
				angle: 0.00949166817929925
		},
		Node8: {
				label : "A2",
				id : "3.2.2",
				level : 3,
				layer : 4,
				analytic : "A2",
				subselect : "x6",
				threshold : [0.86],
				angle: 0.09703204591819259
		}
};
