This directory is used to run the Gshell+Gremlin server. 

Starting Up

To start the ggsserver, simply invoke bin/run.sh.
The default server port is 8083.
