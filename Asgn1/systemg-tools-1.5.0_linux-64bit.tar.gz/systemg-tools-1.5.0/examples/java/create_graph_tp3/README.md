
To build this sample, you will need 
- java 1.8 or higher.
- maven installed

Invoke `java -version` and `javac -version` to confirm that
java 1.8 is installed.  If not, root can install it via apt-get or 
yum commands, or a user can install it by downloading it, unzipping
it and setting PATH, JAVA_HOME environment variables appropriately.

Invoke `mvn -version` to confirm that
you have maven installed.

Then invoke `mvn package` to compile
the sample code here.

Finally, invoke `./runsimple.sh` to 
run the Simple.java sample program.