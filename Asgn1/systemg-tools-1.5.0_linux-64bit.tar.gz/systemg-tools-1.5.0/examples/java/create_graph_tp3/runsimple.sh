#!/bin/sh

# download any platform dependent files in to the local M2 directory tree. ... and then to unpack it in to our target subdirectory.  NarSystem will then find the shared library files there
mvn nar:nar-download  nar:nar-test-unpack    

add_maven_deps_to_classpath() {
  # Need to generate classpath from maven pom. This is costly so generate it                                                        
  # and cache it. Save the file into our target dir so a mvn clean will get                                                         
  # clean it up and force us create a new one.                                                                                      
  f="target/cached_classpath.txt"
  if [ ! -f "${f}" ]
  then
    mvn dependency:build-classpath -Dmdep.outputFile="${f}" &> /dev/null
  fi
  CLASSPATH=${CLASSPATH}:`cat "${f}"`
}

# Add maven target directory                                                                                                        
add_maven_deps_to_classpath
CLASSPATH=${CLASSPATH}:target/classes
CLASSPATH=${CLASSPATH}:target/test-classes
CLASSPATH=${CLASSPATH}:target/test-nar/
export CLASSPATH

java com.ibm.research.systemg.examples.Simple3 $1 $2 $3 $4 $5 $6 $7

