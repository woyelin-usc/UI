package com.ibm.research.systemg.examples;

import com.ibm.research.systemg.transstore.tinkerpop3.TS3Graph;
import org.apache.tinkerpop.gremlin.structure.Graph;
import org.apache.tinkerpop.gremlin.structure.Edge;
import org.apache.tinkerpop.gremlin.structure.Element;
import org.apache.tinkerpop.gremlin.structure.Vertex;

public class Simple3 {


    public static void main(String args[] ) throws Exception {
        Graph graph = new TS3Graph("mysimplegraph");
        Vertex vMary = graph.addVertex("Mary");
        Vertex vJoe  = graph.addVertex("Joe");
        vJoe.addEdge("likes", vMary);
        graph.close();
    }
}