
To build this sample, 
you will need maven installed.

Invoke `mvn -version` to confirm that
you have maven installed.

Then invoke `mvn package` to compile
the sample code here.

Finally, invoke `./runsimple.sh` to 
run the Simple.java sample program.