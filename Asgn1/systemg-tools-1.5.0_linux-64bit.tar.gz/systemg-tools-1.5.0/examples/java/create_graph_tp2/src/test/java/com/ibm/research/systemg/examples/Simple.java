package com.ibm.research.systemg.examples;

import org.propelgraph.util.CreateGraph;
import org.propelgraph.NotFoundException;
import org.propelgraph.AlreadyExistsException;
import org.propelgraph.UnsupportedFActionException;
import com.tinkerpop.blueprints.Graph;
import com.tinkerpop.blueprints.Edge;
import com.tinkerpop.blueprints.Vertex;
import java.io.IOException;

public class Simple {


    public static void main(String args[] ) throws IOException, InterruptedException, InstantiationException, IllegalAccessException, ClassNotFoundException, AlreadyExistsException, AlreadyExistsException, NotFoundException, UnsupportedFActionException {
	Graph graph = CreateGraph.openGraph("sgtrans", "mysimplegraph");
	Vertex vMary = graph.addVertex("Mary");
	Vertex vJoe  = graph.addVertex("Joe");
	vJoe.addEdge("likes", vMary);
	graph.shutdown();
    }
}