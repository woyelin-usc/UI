var graph_vis = systemg.graphvis();

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

function conductQuery(type, query, callback) {
    $('#data-output').empty();
    // if (type == "gshell") {
    // var typedGraph = rawQuery.match("")
    // var rx = /--graph\s+\w*/;
    // var result = rx.exec(query);
    // if (result) {
    //     var typedGraph = result[0].replace(/--graph\s+/, "");
    //     if (typedGraph != curGraph) {
    //         callback("the graph name specified in the query must be the current selected graph");
    //     }
    // } else {
    //     query += " --graph " + curGraph;
    // }
    // }
    graphQuery.runRawQuery(query, type, function(d) {
        var newGraph = "";
        if (type == "gshell") {
            var rx = /--graph\s+\w*/;
            var result = rx.exec(query);
            if (result) {
                newGraph = result[0].replace(/--graph\s+/, "");
                setCurGraph(newGraph);
            }
        } else if (type == "gremlin") {
            graphQuery.runRawQuery('g.graphName', 'gremlin', function(dd) {
                newGraph = dd.response.replaceAll("===>", "");
                newGraph = newGraph.replaceAll("\n", "");
                setCurGraph(newGraph);
            });
        }
        callback(d);
    })
};

function setCurGraph(graphName) {
    var old_graph = $("#setting-gsgraph").text();
    if (old_graph != graphName) {
        console.log("old graph: " + old_graph);
        console.log("new graph: " + graphName);
        $("#setting-gsgraph").text(graphName);
        $('#dataset').text(graphName);
        updateGraphInfoTab(graphName);
    }
}

//initialze cmd setting:
$(function() {
    var consoles = {
        gshell: "gShell",
        gremlin: "Gremlin"
    }

    for (var c_name in consoles) {
        if (consoles.hasOwnProperty(c_name)) {
            $("#query-lan-selection").append("<option rev='" + c_name + "'>" + consoles[c_name] + "</option>");
        }
    }
    var width_value = $("#cmd_input").width();
    var left_value = $("#cmd_input").offset().left - $("#content").offset().left;

    for (var c_name in consoles) {
        if (consoles.hasOwnProperty(c_name)) {
            $("#console_content").append("<div class='float-terminal' id=" + c_name + "></div>");
            $("#" + c_name).css({ left: left_value, width: width_value });
            $("#" + c_name).hide();
            $('#' + c_name).terminal(
                (function(name) {
                    return function(cmd, term) {
                        term.echo("Executed. Result will be shown shortly");
                        conductQuery(name, cmd, function(d) {
                            processQueryResponse(term, name, d);
                        });
                    }
                })(c_name), {
                    prompt: c_name + '> ',
                    greetings: "",
                    onBlur: function(d, e) {
                        $(d).hide();
                        // console.log(e);
                        // console.log(this);
                        console.log("blurred");
                        // this.hide();
                    }
                });
        }
    }

    $("#query-lan-selection").change(function(element) {
        var selected_console = $("#query-lan-selection option:selected").attr('rev');
        $(".float-terminal").hide();
        $("#" + selected_console).show();
        var selectedConsole = $("#" + selected_console).terminal();
        console.log(selectedConsole);
        selectedConsole.focus();
    })


    function processQueryResponse(terminal, type, data) {
        var curGraph = $("#setting-gsgraph").text();
        renderGraphData(curGraph, data);
        if (type == "gremlin") {
            // data.response = data.response.repdata.response = data.response.replaceAll("\n", "<br/>>>");laceAll("\n", "<br/>>>");
            terminal.echo(data.response);
        } else {
            terminal.echo(data.query + " executed and the result is now in raw data panel..");
        }
    }

    $("#cmd_input").focus(function(d) {
        var selected_console = $("#query-lan-selection option:selected").attr('rev');
        console.log(selected_console);
        $("#" + selected_console).show();
        var selectedConsole = $("#" + selected_console).terminal();
        console.log(selectedConsole);
        selectedConsole.focus();
        // $("#"+selected_console+".cmd").focus();
    });

});

function adjustWindowLayout() {
    var windowHeight = $(window).height();
    var paneTitleHeight = 31;
    var fixedBannerHeight = 40;
    var tabTitleHeight = 27;
    var footerHeight = 30;
    var queryBoxHeight = 22;
    var statsHeight = 136;
    var leftSiderBarAvaHeight = (windowHeight - paneTitleHeight - fixedBannerHeight - tabTitleHeight - footerHeight);
    var guiCtrlHeight = leftSiderBarAvaHeight * 2 / 5;
    var consoleHeight = leftSiderBarAvaHeight * 3 / 5;
    var visHeight = windowHeight - fixedBannerHeight - footerHeight - queryBoxHeight;
    var rightSiderBarAvaHeight = windowHeight - paneTitleHeight - fixedBannerHeight - paneTitleHeight - footerHeight;
    $("#gui-controller").css("height", guiCtrlHeight + "px");
    $(".side-pane").css("height", consoleHeight + "px");
    $("#viscomp").height(visHeight);
    statsHeight = Math.min(statsHeight, rightSiderBarAvaHeight *2 /5);
    $("#graph-stats").height(statsHeight);
    $("#analytic-list").height(rightSiderBarAvaHeight - statsHeight);

}

$(function() {
    $(window).on('resize', function() {
        adjustWindowLayout()
    });
    adjustWindowLayout()

    $("#side-spliter").click(function(d) {
        if ($("#side-status").hasClass("glyphicon-chevron-left")) {
            //fold
            $("#side-status").removeClass("glyphicon-chevron-left");
            $("#side-status").addClass("glyphicon-chevron-right");
            $("#window-panel").attr("class", "col-sm-12 col-md-12 col-lg-12");
            $("#side-panel").hide();
        } else {
            //expand
            $("#side-status").removeClass("glyphicon-chevron-right");
            $("#side-status").addClass("glyphicon-chevron-left");
            $("#window-panel").attr("class", "col-sm-7 col-md-8 col-lg-9");
            $("#side-panel").show();
        }
        graph_vis.refresh();
    });
    $("#console-spliter").click(function(d) {
        var windowHeight = $(window).height() - $("#node-legend").height() - $("#edge-legend").height() - 30 - 70 - 15;
        if ($("#console-status").hasClass("glyphicon-chevron-down")) {
            $("#console-status").removeClass("glyphicon-chevron-down");
            $("#console-status").addClass("glyphicon-chevron-up");
            $("#viscomp").height(windowHeight + 35);
            $("#console-panel").hide();
        } else {
            //expand
            $("#console-status").removeClass("glyphicon-chevron-up");
            $("#console-status").addClass("glyphicon-chevron-down");
            $("#console-panel").show();
            $("#viscomp").height(windowHeight * 2 / 3);
        }
        graph_vis.refresh();
    })

    $("#dataset").click(function(d) {
        upload_graphlist();
    });
});

/////////////////// initialize Vjit Actions //////////////////////
function upload_graphlist(defaultGraph) {
    graphQuery.getGraphList(function(data) {
        var htmlText = '<li><a href="#" data-toggle="modal" data-target="#upload_model">Create New</a></li><li role="presentation" class="divider"></li>'

        if (data.stores && data.stores.length > 0) {
            data.stores.forEach(function(d) {
                htmlText += "<li><div style='disaply:block'> <button class='btn btn-danger btn-xs' rev='" + d.name + "''> x </button> <a id='" + d.name + "' rev='" + d.name + "' rel='" + d.name + "' href='#'>" + d.name + "</a>  </div></li>";
            });
        };

        $("#dataset-dropdown").html(htmlText);
        $("#dataset-dropdown li a").click(function() {
            $(".cmd").val("");
            var rel = $(this).attr('rel'),
                val = $(this).text(),
                rev = $(this).attr('rev');
            // console.log(rel);
            if (rel == undefined) return; // upload button

            if ($("#setting-gsgraph").text() != "" && $("#setting-gsgraph").text() != val) {
                graphQuery.runRawQuery("g.shutdown()", "gremlin", function() {
                    openGraph(val, rel);
                });
            } else {
                openGraph(val, rel);
            };
        });
        if (defaultGraph) {
            console.log(defaultGraph);
            $("#" + defaultGraph)[0].click();
        }
        $("#dataset-dropdown li button").click(function() {
            var rel = $(this).attr('rev');
            deleteGraph(rel);
        });
    });

    function openGraph(val, rel) {
        graphQuery.runRawQuery('g=CreateGraph.openGraph("sgtrans","' + val + '")', "gremlin", function() {
            $("#setting-gsgraph").text(val);

            console.log($("#setting-gsgraph").text());

            graph_vis.setDirected(rel);
            $('#dataset').text(val);
            // console.log(rel);
            $("#query_raw").removeAttr("disabled", true);
            $(".cmd").removeAttr("disabled", true);
            initQuery();
            updateGraphInfoTab(val);
            renderGraph(val);
        });
    }
}

function getEgonets(graph_name, ids){
    var query = "find_multiple_vertices --graph " + graph_name + " --id " + ids + " --out tmp";
    graphQuery.runRawQuery(query,"gshell", function(){
        query = "get_egonet --graph "  + graph_name + " --in tmp";
         graphQuery.runRawQuery(query,"gshell", function(data){
            renderGraphData(graph_name, data);
         });
    });
}
function updateGraphInfoTab(graph_name) {

    $("#graph-stats").empty();
    $("#graph-stats").append('<table class="table"><tbody></tbody></table>');
    graphQuery.getGraphInfo(graph_name, function(data) {
        window.graphProperties = data.properties;
        data.info.forEach(function(d) {
            for (var key in d) {
                if (d.hasOwnProperty(key)) {
                    // console.log(key);
                    $("#graph-stats>table>tbody")
                        .append('<tr><td>' + key + ':</td><td>' + d[key] + '</td></tr>');
                }
            }
        });
        $("#analytic-list").empty();
        $("#analytic-list").append('<table class="table"><tbody></tbody></table>');
        graphQuery.getAnalyticList(function(analyticList) {
            analyticList.analytics.forEach(function(d) {
                var aName = d.name.replaceAll("_", " ");
                aName = aName.substr(9);
                var runned = false;
                if (data[d.name]) {
                    runned = true;
                };
                $("#analytic-list>table>tbody")
                    .append('<tr class="anlaytic-title" id="' + d.name + '"><td>' + aName + ':</td><td><button rev="' + d.name + '" class="btn btn-default btn-xs">' + (runned ? "Re-run" : "Run") + '</button></td></tr>');
                $("#analytic-list>table>tbody")
                    .append('<tr><td style="display:none" colspan="2" id="' + d.name + '-result"></td></tr>');
                if (runned) {
                    var analyticResultString = "<div style='max-height:150px;overflow:auto'><table class='table table-striped'><tbody>";
                    var analyticResult = data[d.name][0];
                    // console.log(analyticResult);
                    for (var key in analyticResult) {
                        if (analyticResult.hasOwnProperty(key)) {
                            if (key == "timestamp") {
                                // console.log(+analyticResult[key]*1000);
                                var timestamp = new Date(+analyticResult[key]*1000);
                                // console.log(timestamp);
                                analyticResult[key] = formatDate(timestamp);
                            }
                            // analyticResultString += "<tr><td style="word">" + key + ":</td><td>" + analyticResult[key] + "</td></tr>";
                            analyticResultString += "<tr><td ><strong>" + key + "</strong>: " + analyticResult[key] + "</td></tr>";
                        }
                    }
                    // console.log(analyticResultString);
                    analyticResultString += '</tbody></table></div>';
                    $("#" + d.name + "-result").empty();
                    $("#" + d.name + "-result").show();
                    $("#" + d.name + "-result").append(analyticResultString);
                }
            });
            $("#analytic-list button").on("click", function(d) {
                var analytics = $(this).attr("rev");
                var curGraph = $("#setting-gsgraph").text();
                var query_gshell = analytics + " --graph " + curGraph + " --displaymode 2";
                var reset_analytic = "analytic_reset_engine --graph " + curGraph;
                $(this).text("Running");
                $(this).prop('disabled', true);
                var $that = $(this);
                conductQuery("gshell", reset_analytic, function(result) {
                    conductQuery("gshell", query_gshell, function(result) {
                        updateGraphInfoTab(curGraph);
                    })
                })

            });
        });
    });
}

function formatDate(value) {
    var monthDate = value.toISOString()
        .replace(/^(\d+)-(\d+)-(\d+).*$/, // Only extract Y-M-D
            function(a, y, m, d) {
                return [
                        ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', // Month Names
                            'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dec'
                        ]
                        [m - 1], // Month
                        d
                    ].join('-') // Stitch together
            });
    var timeString = value.toLocaleTimeString();
    return timeString + " " + monthDate;
}

function addToConsole(flag, content) {
    var style = "";
    if (flag == "error") {
        style = "style='color:red'";
    }
    if (flag == "result") {
        style = "style='color:black'";
    }
    if (flag == "cmd") {
        style = "style='color:blue'"
        items = content.split("|^|");
        items.reverse();
        items.forEach(function(content) {
            $("#console").append("<span " + style + ">>>Query executed: [" + content + "]</span><br>");
        });
    } else {
        $("#console").append("<span " + style + ">>>" + (flag == "error" ? "Error: [" : "") + content + (flag == "error" ? "]" : "") + "</span><br>");
    }

    if (flag == "info") {
        $("#status-msg").text(content);
    }
    $("#console").get(0).scrollTop = $("#console").get(0).scrollHeight;
}

function initQuery() {

    $("#query-type").text("Please Select");

    $("#control-tab").tab();

}




/////////////////// Upload //////////////////////
$(function() {


    var url = '/systemg/vis/upload',
        graphid = null,
        type = 'undirected',
        permission = null,
        desp = null,
        handle = null;

    var node_files = {
        list: [],
        returnedList: []
    };
    var edge_files = {
        list: [],
        returnedList: []
    };

    $(".config li a").click(function() {
        var selText = $(this).text();
        $(this).parents('.btn-group').find('.dropdown-toggle').html(selText + ' <span class="caret"></span>');
        type = selText;
        // console.log(type);
    });

    function add_info_to_console(json) {
        for (var j = 0; j < json["info"].length; j++) {
            for (var key in json["info"][j]) {
                if (json["info"][j].hasOwnProperty(key)) {
                    if (typeof json["info"][j][key] != 'string' || (json["info"][j][key].indexOf("close") < 0 && json["info"][j][key].indexOf("open") < 0)) {
                        addToConsole("info", key + " " + json["info"][j][key]);
                    }
                }
            }
        }
    }

    function createGraph(graphName, type, graphDescription, nodeList, edgeList) {
        $("#upload-close").click();
        graphQuery.createGraph(graphName, type, function(d) {
            var result = d;
            add_info_to_console(result);
            clearUploadForm();
            addNodes(0);
        });

        function addEdges(cur) {
            edgeFile = edgeList[cur];
            graphQuery.loadCsvEdges(graphName, edgeFile.fileurl, 0, 1, edgeFile.label, function(edge_result) {
                add_info_to_console((edge_result));
                graphQuery.flushGraph(graphName);
                cur += 1;
                if (cur == edgeList.length) {
                    graphQuery.calDegree(graphName, function(d) {
                        upload_graphlist(graphName);
                    })
                } else {
                    addEdges(cur);
                }
            });
        }

        function addNodes(cur) {
            var nodeFile = nodeList[cur];
            graphQuery.loadCsvVertices(graphName, nodeFile.fileurl, 0, nodeFile.label, function(node_result) {
                add_info_to_console((node_result));
                graphQuery.flushGraph(graphName);
                cur += 1;
                if (cur == nodeList.length) {
                    addEdges(0);
                } else {
                    addNodes(cur);
                }
            });
        };


        // $.post("/systemg/vis/upload", {
        //     command: "create",
        //     graphid: graphName,
        //     type: type,
        //     desp: graphDescription,
        //     nodelist: nodeList,
        //     edgelist: edgeList
        // }).done(function(data) {
        //     // console.log(data);
        //     var jsonData = JSON.parse(data);
        //     for (var i = 0; i < jsonData.length; i++) {
        //
        //     }
        //     var isSuccessed = true;
        //     jsonData.forEach(function(element, index) {
        //         if (element && element.error) {
        //             addToConsole("error", element.error);
        //         }
        //     });
        //     if (isSuccessed) {
        //         clearUploadForm();
        //         upload_graphlist(graphName);
        //         $("#upload-close").click();
        //     }
        // });
    }


    function clearUploadForm() {
        node_files = {
            list: [],
            returnedList: []
        };
        edge_files = {
            list: [],
            returnedList: []
        };
        $('#graph-name').val("");
        $('#graph-desp').val("");
        $('.file-list').empty();
        $('.uprogress').css(
            'width',
            '0%'
        );
        init_uploading("#node-form", node_files);

        init_uploading("#edge-form", edge_files);

        $('a[href="#intro"]').tab('show');
    }


    init_uploading("#node-form", node_files);

    init_uploading("#edge-form", edge_files);

    $('#graph-create').on("click", function() {



        if (node_files.returnedList.length < 1) {
            alert("No Node File Uploaded");
            return;
        }

        if (edge_files.returnedList.length < 1) {
            alert("No Edge File Uploaded");
            return;
        }

        if ($('#graph-name').val() == '') {
            alert("Please Name the Graph");
            return;
        }

        var graphName = $('#graph-name').val();
        var graphDescription = $('#graph-desp').val();

        // var result = tryCreateGraph(graphName, type, graphDescription);

        console.log(type);
        var result = createGraph(graphName, type, graphDescription, node_files.returnedList, edge_files.returnedList);


    });

    function init_uploading(form, fileList) {
        // $(form).find(".cancel-upload").prop('disabled', true);
        $(form).find(".start-upload").prop('disabled', true);
        $(form).find('.start-upload').click(function() {
            $(form).find(".start-upload").prop('disabled', true);
            // var progressCnt = 0;
            fileList.list.forEach(function(data) {
                data.submit()
                $('#' + data.uniqueID).find('button').text("Prcessing")
                    .prop('disabled', true)
                    .removeClass('btn-danger')
                    .addClass('btn-info')
            });

        });

        var removeButton = $('<button/>')
            .addClass('btn btn-danger')
            .text('Remove')
            .on('click', function() {
                var $this = $(this),
                    data = $this.data();
                var index = fileList.list.indexOf(data);
                fileList.list.splice(index, 1);
                $('#' + data.uniqueID).remove();
            });

        $(form).find('.upload').fileupload({
                url: url,
                dataType: 'json',
                add: function(e, data) {
                    data.context = $(form).find('.file-list');
                    $.each(data.files, function(index, file) {
                        data.uniqueID = 'file' + Math.floor(Math.random() * 100000);
                        var node = $('<tr/>')
                            .attr('id', data.uniqueID)
                            .append($('<td/>').text(file.name));
                        if (!index) {
                            node.append($('<td/>').text(Math.floor(file.size / 1000) + 'K'));
                            node.append($('<td/>')
                                .append($('<input/>').attr('type', "text").val("_"))
                            );
                            node.append($('<td/>')
                                .append(removeButton.clone(true).data(data))
                            );
                        }
                        node.appendTo(data.context);
                        fileList.list.push(data);
                    });
                    $(form).find(".start-upload").prop('disabled', false);
                    $(form).find('.uprogress').css(
                        'width', '0%'
                    );
                },
                progressall: function(e, data) {
                    var progress = parseInt(data.loaded / data.total * 100, 10);
                    $(form).find('.uprogress').css(
                        'width',
                        progress + '%'
                    );
                },
                done: function(e, data) {
                    $('#' + data.uniqueID).find('button').text("Uploaded")
                        .removeClass('btn-info')
                        .addClass('btn-success')
                        // fileList.list.
                    var l = $('#' + data.uniqueID).find('input').val();
                    var index = fileList.list.indexOf(data);
                    fileList.list.splice(index, 1);
                    $.each(data.result, function(index, file) {
                        console.log(file);
                        fileList.returnedList.push({
                            filename: file.name,
                            fileurl: file.url,
                            label: l
                        })

                    });
                },
                error: function(e, data) {
                    // console.log(e);
                    console.log(data);
                }

            }).prop('disabled', !$.support.fileInput)
            .parent().addClass($.support.fileInput ? undefined : 'disabled');


    }
});

/////////////////// VisComp Chooser //////////////////////
$(function() {
    $('.select-vis').click(function() {
        $("#comp-close").click();
        var type = $(this).attr("rev");
        graph_vis.renderer(type);
        graph_vis.render();
        // graph_vis.addControlPanelTo("gui-controller");
    });
});

/////////////////// Query //////////////////////
$(function() {

    $("#iframe").height($(window).height() * 0.75);

    $('.btn-next').click(function() {
        $('.nav-tabs > .active').next('li').find('a').trigger('click');
    });

    $('.btn-previous').click(function() {
        $('.nav-tabs > .active').prev('li').find('a').trigger('click');
    });

    $("#query").click(function() {
        var graphid = $("#setting-gsgraph").text();
        var type = $('#query-type').text();
        console.log(type);
        if (type == "Node" || type == "Edge") {

            var rules = $('#query-builder').queryBuilder('getRules');
            if (rules.condition) {
                var ret = parseRule(rules,type);
                ret['type'] = $('#query-type').text();
                console.log(ret);
                renderGraph(graphid, ret);
                // console.log(ret);
                // $("#iframe").html('<iframe name="graphvis" src="/systemg-lite/components/qgraph/tab_graphvis.html" style="width:100%;height:100%;" frameborder="0"></iframe>');
            } else {
                renderGraph(graphid);
            }
        } else if (type == "Ego") {
            var sid = $('#query-id').val();
            console.log(sid);
            renderGraph(graphid, sid);
        }
    });
});

var op = {
    'equal': "==",
    'not_equal': "!=",
    'less': "<",
    'less_or_equal': "<=",
    'greater': ">",
    'greater_or_equal': '>=',
    "AND": '&&',
    "OR": '||'
};

function parseRule(rules, type) {

    // console.log(rules);
    if (rules.condition) {
        if (rules.rules.length == 1) {
            return parseRule(rules.rules[0],type);
        } else {
            var str = "";
            var fields = [];
            var conditions = [];
            for (var i = 0; i < rules.rules.length; i++) {
                var ret = parseRule(rules.rules[i], type);
                for (var j = 0; j < ret.fields.length; j++) {
                    if (fields.indexOf(ret.fields[j]) < 0) {
                        fields.push(ret.fields[j]);
                    }
                }
                conditions.push(ret.string);
            }
            str += conditions.join(" " + op[rules.condition] + " ") + "";
            return {
                fields: fields,
                string: str
            }
        }
    } else {
        var f = [(rules.field)];
        var fieldType = window.graphPropertiesMap[type+"_"+rules.field];
        var s = rules.field + " " + op[rules.operator] + " " + (fieldType=='string'?"'":"") + rules.value + (fieldType=='string'?"'":"");
        console.log(s);
        return {
            fields: f,
            string: s
        }
    }

}

function deleteGraph(gid) {
    // var content = {
    //     graphid: gid,
    //     cmd: "delete"
    // }
    if (!confirm("Do you want to delete graph " + gid + "?")) {
        return;
    }
    graphQuery.deleteGraph(gid, function(data) {
        console.log(data);
        $('#dataset').text("Please Select");
        // $("#query_raw").attr("disabled", true);
        // $(".cmd").attr("disabled", true);
        upload_graphlist();
    })

}

window.deleteEdge = function(gid, edge, callback){
    addToConsole("info", "Deleting Edge <strong>" + edge.id + "</strong> from graph " + gid);
    graphQuery.deleteEdge(gid, edge, function(data) {
        console.log(data);
        // data = (data);
        // addToConsole("cmd", data["query"]);
        if (data['error']) {
            console.log("test");
            data['error'].forEach(function(d) {
                addToConsole("error", d["MESSAGE"]);
            })
            callback(false);
            addToConsole("error", "Deleting failed");
        } else {
            addToConsole("info", "Edge [" + edge.id + "]  has been deleted in graph [" + gid + "]");
            callback(true);
        }
    });
}

window.deleteNode = function(gid, id, callback) {
    addToConsole("info", "Deleting node <strong>" + id + "</strong> from graph " + gid);
    graphQuery.deleteNode(gid, id, function(data) {
        console.log(data);
        // data = (data);
        // addToConsole("cmd", data["query"]);
        if (data['error']) {
            console.log("test");
            data['error'].forEach(function(d) {
                addToConsole("error", d["MESSAGE"]);
            })
            callback(false);
            addToConsole("error", "Deleting failed");
        } else {
            addToConsole("info", "Node [" + id + "]  has been deleted in graph [" + gid + "]");
            callback(true);
        }
    });
}

window.updateEdgeValue = function(gid, edge, prop, value, callback) {
    addToConsole("info", "Updating Edge <strong>" + edge.id + "</strong> from graph " + gid);
    graphQuery.updateEdgeValue(gid, edge, prop, value, function(data) {
        // data = $.parseJSON(data);
        // addToConsole("cmd", data["query"]);
        if (data['error']) {
            console.log("test");
            data['error'].forEach(function(d) {
                addToConsole("error", d["MESSAGE"]);
            })
            addToConsole("error", "Updating failed");
            callback(false);
        } else {
            addToConsole("info", "Edge Value Updated for [" + edge.id + "]  in graph [" + gid + "]");
            callback(true);
        }

    });
}

window.updateNodeValue = function(gid, id, prop, value, callback) {
    addToConsole("info", "Updating node <strong>" + id + "</strong> from graph " + gid);
    graphQuery.updateNodeValue(gid, id, prop, value, function(data) {
        // data = $.parseJSON(data);
        // addToConsole("cmd", data["query"]);
        if (data['error']) {
            console.log("test");
            data['error'].forEach(function(d) {
                addToConsole("error", d["MESSAGE"]);
            })
            addToConsole("error", "Updating failed");
            callback(false);
        } else {
            addToConsole("info", "Node Value Updated for [" + id + "]  in graph [" + gid + "]");
            callback(true);
        }

    });
}

function renderGraphData(gid, data) {

    // data = $.parseJSON(data);

    if (data) {
        $('#data-output').JSONView(data);
    }
    if (data.error) {
        data.error.forEach(function(d) {
            console.log(d["MESSAGE"]);
            addToConsole("error", d["MESSAGE"]);
        })
    }

    if (!data.error && (data.info || data.paths || data.summary || data.nodes || data.edges)) {
        addToConsole("result", "Result received:");
    }

    if (data.info) {
        data.info.forEach(function(d) {
            for (key in d) {
                if (d.hasOwnProperty(key)) {
                    if (d[key] != "store is closed. opening now" &&
                        d[key] != "native store is opened") {
                        addToConsole("info", key + ": " + d[key])
                    }
                }
            }
        })
    }

    if (data.paths) {
        data.paths.forEach(function(d) {
            for (key in d) {
                if (d.hasOwnProperty(key)) {
                    addToConsole("result", key + ": " + d[key])
                }
            }
        })
    }

    if (data.summary) {
        data.summary.forEach(function(d) {
            for (key in d) {
                if (d.hasOwnProperty(key)) {
                    addToConsole("result", key + ": " + d[key])
                }
            }
        })
    }

    if (data.response) {
        var formatted_response = data.response.replaceAll("\n", "<br/>>>");
        addToConsole("result", formatted_response);
    }

    if (!data.nodes) {
        $("#result").val(data.toString());
        return;
    }

    var cur_url = window.location.toString();

    cur_url = cur_url.substring(0, cur_url.lastIndexOf('/'));

    // console.log(data)

    // console.log(data);

    // addToConsole("cmd", data["query"]);
    // $("#console").append("<span>>>"</span><br>");

    // addToConsole("info", "Result summary: [number of nodes: " + data['summary'][0]['number of nodes'] + "; Number of Edges: " + data['summary'][0]['number of edges'] + "]");
    // window.md5_link = cur_url + "/components/qgraph/tab_graphvis.html?" + data;
    addToConsole("info", "Rendering graph...");
    graph_vis.clear();
    // console.log(window.md5_link);

    g = data;

    if (!g.nodes) {
        return;
    }
    if (g.nodes.length > 2000) {
        if (!confirm("The graph has more than 3000 nodes. Rendering it may take a long time. Do you still want to do it?")) {
            return;
        }
    }

    // if (!query) {
    window.orgData = g;
    // }
    window.data = g;


    if (!window.data.edges) {
        window.data.edges = [];
    }

    window.data.edges.forEach(function(d) {
        d.id = d.eid;
        d.hover_color = '#fec44f';
        d.size = 0.01;
        // d.type = "curvedArrow";
        // d._label = d.Relationship;
    });

    window.data.nodes.forEach(function(d) {
        d.x = Math.random();
        d.y = Math.random();
        // d.x = +d.coordinate_x;
        // d.y = +d.coordinate_y;
        d.size = 1;
        d._label = d.id;
    });


    $("#query-box").show();

    graph_vis.data(gid, window.data);
    graph_vis.render();
    addToConsole("info", "Rendering graph finished.");
    graph_vis.addControlPanelTo("gui-controller");
}


window.renderGraphData = renderGraphData;

window.renderGraph = function(gid, query) {

    var content = {
        graphid: gid
    };

    // console.log(query);

    window.egoID = "";

    if (query) {
        if (query.type) {
            content.type = query.type;
            content.fields = query.fields.join(":");
            content.string = query.string;
            window.egoID = "";
        } else if (query.cmd) {
            content.cmd = query.cmd;
            content.queryType = query.queryType;
            window.egoID = "";
        } else {
            content.sid = query;
            window.egoID = query;
        }
    }

    var graphCallback = function(data) {
        renderGraphData(gid, data);
    };

    if (content.sid) {
        addToConsole("info", "Retrieving the ego network of <strong>" + content.sid + "</strong> from graph " + gid + "...");
        graphQuery.getEgonet(content.graphid, content.sid, graphCallback);
    } else
    if (content.type) {
        addToConsole("info", "Filtering graph " + gid);
        if (content.type == "Node") {
            graphQuery.queryNodeFilteredGraph(content.graphid, content.fields, content.string, graphCallback);
        } else if (content.type == "Edge") {
            graphQuery.queryEdgeFilteredGraph(content.graphid, content.fields, content.string, graphCallback);
        }
    } else if (content.cmd) {
        if (content.cmd == "delete") {
            addToConsole("info", "Deleting graph " + gid);
            graphQuery.deleteGraph(content.graphid, graphCallback);
        } else {
            addToConsole("info", "Running " + content.queryType + " query...");
            graphQuery.runRawQuery(content.cmd, content.queryType, graphCallback);
        }
    } else {
        addToConsole("info", "Retrieving graph " + gid + "...");
        graphQuery.getSafeGraph(content.graphid, 1400, graphCallback);
    }

}

$(function() {

    var _filters;

    $("#query-dropdown li a").click(function() {
        var rev = $(this).attr('rev');

        $('#query-type').text(rev);

        var data = window.graphProperties;
        var propSet = [];
        window.graphPropertiesMap = {};
        if (rev == "Node" || rev == "Edge") {
            for (var i = 0; i < data.length; i++) {
                if (rev == "Node" && data[i].type == "node") {
                    propSet.push(data[i].name);
                    window.graphPropertiesMap["Node_" + data[i].name] = data[i]['value'];
                } else if (rev == "Edge" && data[i].type == "edge") {
                    propSet.push(data[i].name)
                    window.graphPropertiesMap["Edge_" + data[i].name] = data[i]['value']
                }
            }

            console.log(propSet);

            _filters = propSet.map(function(d) {
                return {
                    id: d,
                    label: d,
                    type: 'string',
                    operators: ['equal', 'not_equal', 'less', 'less_or_equal', 'greater', 'greater_or_equal']
                        // operators: ['equal', 'not_equal']
                }
            });

            // console.log(_filters);

            $('#query-builder').queryBuilder('destroy');

            $('#query-builder').queryBuilder({
                plugins: ['sortable'],
                filters: _filters,

            });
            $('#query—ego').hide();
            $('#query-builder').show();
            $("#sparql_query").hide();

        } else if (rev == "Ego") {

            $('#query—ego').show();
            $('#query-builder').hide();
            $("#sparql_query").hide();

        } else {
            $('#query—ego').hide();
            $('#query-builder').hide();
            $("#sparql_query").show();

        }

        $("#query").show();
    });

});
