// Global namespace
var Global = {};

// Layout

Global.X = [1, 0, 0];
Global.Y = [0, 1, 0];
Global.Z = [0, 0, 1];

Global.E2GFactor = 0.4;
Global.E2GFactorMin = 0.2;

Global.unit = 100;
Global.zero = [0, 0, Global.unit];
Global.infinite = [0, 0, -Global.unit];
Global.nv2D = Global.Z;

// Geometry
Global.maxEdgeSegment = 50;
Global.edgeFillGap = 0;
Global.nodeSegmentW = 4;
Global.nodeSegmentH = 4;
Global.sphereWireSegment = 50;

Global.edgeWidth3D = 2;
Global.nodeSize3D = 1;
Global.nodeColor3D = "steelblue";
Global.sphereMeshSegment = 200;
Global.edgeMaxWeight = 5.0;
Global.KDEBandwidth = 0.089;
Global.kdeSamplingBlockSize = 25;
Global.translationFactor = 1 / 500;

// Style
Global.edgeWidth = 1.0;
Global.nodeSize = [3, 4];
Global.nodeBoxSize = 3;

Global.nodeAlpha = [0.0, 0.7, 1.0];
Global.nodeColor = 'rgba(255,255,255,';
Global.nodeColorHighlight = 'rgba(255,0,0,1.0)';

Global.edgeColor = 'rgba(255, 255, 255, 0.5)';

Global.contourColor = 'rgba(106,81,163, 0.1)';
Global.contourNLevels = 10;

Global.category20 = d3.scale.category20();

Global.kdeColors = [
    "#FFFFFF",
    "#E2FEFF",
    "#C2F5FF",
    "#A8EBFF",
    "#91E4FF",
    "#7FC8FF"
    // "#ffffff",
    // "#f7fbff",
    // "#deebf7",
    // "#c6dbef",
    // "#9ecae1",
    // "#6baed6",
    // "#4292c6",
    // "#2171b5",
    // "#08519c",
    // "#08306b"
];

Global.year_color_map = {
    1920: "165,0,38",
    1930: "215,48,39",
    1940: "244,109,67",
    1950: "253,174,97",
    1960: "254,224,144",
    1970: "171,217,233",
    1980: "116,173,209",
    1990: "69,117,180",
    2000: "49,54,149",
};

Global.size_color_map = d3.scale.linear()
    .domain([10, 50, 100])
    .range([
        "#efedf5",
        "#bcbddc",
        "#756bb1"
    ]);

// Speed
Global.ROIWidth = 0.3;
Global.ROVWidth = 0.6;
Global.quadtreeResL = 0.005;
Global.quadtreeResH = Global.quadtreeResL / 2;
Global.kdeRenderBlockSize = 50;
Global.textureWidth = 1200;
Global.E2GFactorThreshold1 = 1.24;
Global.E2GFactorThreshold2 = 2.25;

//
Global.showWireSphere = true;
Global.showMeshSphere = false;
Global.picking = true;

//

Global.useIFrame = false;

// Control
var ControlPanel = {};
ControlPanel.mouseStatus = 0;

ControlPanel.showAs2DCanvas = false;
if (ControlPanel.showAs2DCanvas) {
    Global.textureWidth = 500;
    Global.showWireSphere = false;
}
Global.kdeTextureWidth = Global.textureWidth * 1.5;

ControlPanel.E2GFactor = Global.E2GFactor;
ControlPanel.KDEBandwidth = Global.KDEBandwidth;
ControlPanel.translate = [0.0, 0.0];
ControlPanel.showKDE = true;
ControlPanel.nodeStroke = false;
ControlPanel.showNodes = true;
ControlPanel.showEdges = true;
ControlPanel.showQuadtree = false;
ControlPanel.showWordle = true;
ControlPanel.showNodeColorBy = "decade"; //"none", "genre", "decade";
ControlPanel.forceWordleUpdate = false;
ControlPanel.forceHideNodes = false;
ControlPanel.forceShowEdges = false;
ControlPanel.forceHideKDE = false;

// Development
// Global.debug = true;
Global.debug = false;
Global.debug_surface = false;

Global.msg = function(text) {
    var dom = $("#dev-msg", window.parent.document);
    var old = dom.html();
    dom.html(old + "<br />" + text);
}

Global.log = function(obj) {
    console.log(obj);
}

Global.warning = function(text, where) {
    console.log("[warning] " + text + " - " + where);
}
