var CrystalSphere = function() {

    var _use_default_edge_color = true;
    var _use_default_node_color = true;
    var color = d3.scale.category10();
    var edge_color = d3.scale.category20b();
    var nsize = d3.scale.linear().range([3, 10]);
    var nthick = d3.scale.linear().range([.5, 4]);
    var lthick = d3.scale.linear().range([.5, 4]);

    var renderer;
    var scene;
    var graph;
    var sphere;
    var mouse;
    var camara;
    var windowSize;
    var highlighting = false;
    var cur_highlighed_id = -1;
    var pickingScene;
    var pickingTexture;
    var number_of_nodes;
    var i2n;
    var mouseclicking = false;
    // var readJson = function(url) {
    //     var json;
    //     $.ajax({
    //         url: url,
    //         dataType: 'json',
    //         async: false,
    //         success: function(data) {
    //             json = data;
    //         }
    //     });

    //     json['nodes'] = listToMap(json['nodes']);


    //     return json;
    // }

    // var layout = function(g) {

        // var _graph = g;
        // console.log(g);
        // var _force = d3.layout.force()
        //     .size([600, 600])
        //     .linkStrength(function(d) {
        //         // console.log(d);
        //         // console.log(d.weight);
        //         return d.weight / 4000;
        //     })
        //     .friction(0.9)
        //     .linkDistance(1)
        //     .charge(-30)

        // var nodes = [];

        // for (var n in _graph.nodes) {
        //     if (_graph.nodes.hasOwnProperty(n)) {
        //         nodes.push(_graph.nodes[n]);
        //     }
        // }

        // var links = []

        // for (var i = 0; i < _graph.links.length; i++) {
        //     links.push({
        //         source: _graph.nodes[_graph.links[i].source],
        //         target: _graph.nodes[_graph.links[i].target],
        //         weight: _graph.links[i].weight
        //     });
        //     _graph.nodes[_graph.links[i].target].COUNT = _graph.links[i].weight;
        //     _graph.nodes[_graph.links[i].target].weight = _graph.links[i].weight;
        // }
        // var links = _graph.links;

        // nodes.forEach(function(d) {
        //     if (d.x) d.x = +d.x;
        //     if (d.y) d.y = +d.y;
        // });


        // console.log(nodes);

        // console.log(links);

        // _force
        //     .nodes(nodes)
        //     .links(links)
        //     .on("tick", null);

        // var n = nodes.length;
        // _force.start();
        // for (var i = n * n; i > 0; --i) {
        //     _force.tick();
        // }
        // _force.stop();
        // for (var i = 0; i < nodes.length; ++i) {
        //     nodes[i].x = (nodes[i].x - 300) / 600
        //     nodes[i].y = (nodes[i].y - 300) / 600
        // }
    // }



    function listToMap(list) {
        var map = {};
        for (var i = 0; i < list.length; i++) {
            var item = list[i],
                id = item['id'];

            item['i'] = i;
            map[id] = item;
        }
        return map;
    }
    // var dataset = rData.random(10000,100);
    // var dataset = rData.json("data/current.json");


    function picking() {
        if (mouse.x == 0 && mouse.y == 0) return;

        renderer.render(pickingScene, camera, pickingTexture);
        var gl = renderer.getContext();
        var pixelBuffer = new Uint8Array(4);
        gl.readPixels(mouse.x, pickingTexture.height - mouse.y, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixelBuffer);
        var id = (pixelBuffer[0] << 16) | (pixelBuffer[1] << 8) | (pixelBuffer[2]);

        if (id >= number_of_nodes) {
            if (highlighting) {
                graph.unhighlight();
                highlighting = false;

                hideTooltip();

                cur_highlighed_id = -1;
            }
        } else {
            highlighting = true;

            if (cur_highlighed_id != id) {
                cur_highlighed_id = id;
                graph.highlight(id);
            }
            var node = dataset['nodes'][i2n[id]];
            // showTooltip(mouse.x, mouse.y, node);
            showTooltipIDOnly(mouse.x, mouse.y, node);

            if (mouseclicking) {

            }

        }
        mouseclicking = false;
    }

    function get_direction(x, y) {
        var hw = window.innerWidth / 2,
            hh = window.innerHeight / 2;
        if (x < hw && y < hh) return 0;
        if (x >= hw && y < hh) return 1;
        if (x >= hw && y >= hh) return 2;
        if (x < hw && y >= hh) return 3;
    }

    function get_tipsy(id) {
        return '<div class="tipsy" style="position:absolute;left:0px; top:0px;display: none; visibility: visible; opacity: 0.8;" id="tooltip-' + id + '"><div class="tipsy-arrow"></div><div class="tipsy-inner" style="padding:10px;padding-bottom:13px"></div></div>';
    }

    function showTooltipIDOnly(x, y, node) {
        $(".tipsy").remove();

        var id = node.id;

        $("body").append(get_tipsy(id));

        var content = $("#tooltip-" + id + " .tipsy-inner");
        content.text('id : ' + id);

        var wrapper = $("#tooltip-" + id);

        var direction = get_direction(x, y);
        var arrow = $("#tooltip-" + id + " .tipsy-arrow");
        if (direction == 0) {
            wrapper.addClass("tipsy-nw");
            wrapper.css("top", y + 15);
            wrapper.css("left", x - 13);
        } else if (direction == 1) {
            wrapper.addClass("tipsy-ne");
            wrapper.css("top", y + 15);
            wrapper.css("left", x - wrapper.width() + 3);
        } else if (direction == 2) {
            wrapper.addClass("tipsy-se");
            wrapper.css("top", y - wrapper.height() - 15);
            wrapper.css("left", x - wrapper.width() + 3);
        } else if (direction == 3) {
            wrapper.addClass("tipsy-sw");
            wrapper.css("top", y - wrapper.height() - 15);
            wrapper.css("left", x - 13);
        }

        wrapper.show();
    }

    function hideTooltip() {
        $(".tipsy").remove();
    }

    function animate() {
        animationID = requestAnimationFrame(animate);
        graph.update();
        renderer.render(scene, camera);

        if (Global.picking) {
            // if (ControlPanel.mouseStatus == 0 && ControlPanel.E2GFactor > Global.E2GFactorThreshold2) {
            if (ControlPanel.E2GFactor > Global.E2GFactorThreshold2) {
                picking();
            } else {
                if (highlighting) {
                    graph.unhighlight();
                    highlighting = false;
                    // hideTooltip();
                }
            }
        }
    }

    this.animate = animate;

    this.test = function(val) {
        console.log(val);
    }

    this.needsUpdate = function(updateGraph, updateSurface) {
        graph.needsUpdate(updateGraph, updateSurface);
    }

    var groupFill = function(d, i) {
        return color(d.cid);
    };

    var configure = {};

    var rendererInstance;

    CrystalSphere.prototype.bindClickNodeEvent = function(callback) {

    }

    CrystalSphere.prototype.initialize = function() {

    }

    CrystalSphere.prototype.zoomToFit = function() {
        // var factor = ControlPanel.E2GFactor;
        // console.log(factor);
        ControlPanel.E2GFactor = parseFloat(0.4);
        this.needsUpdate(true, true);
    }

    CrystalSphere.prototype.zoomIn = function() {
        var factor = ControlPanel.E2GFactor;
        // console.log(factor);
        ControlPanel.E2GFactor = parseFloat(factor + 0.5);
        this.needsUpdate(true, true);
    }

    CrystalSphere.prototype.zoomOut = function() {
        var factor = ControlPanel.E2GFactor;
        // console.log(factor);
        ControlPanel.E2GFactor = parseFloat(Math.max(factor - 0.5, 0.4));
        this.needsUpdate(true, true);
    }

    CrystalSphere.prototype.clear = function() {

    }

    CrystalSphere.prototype.refresh = function() {
        var windowSize = Math.min($("#viscomp").height(), $("#viscomp").width());
        camera.updateProjectionMatrix();
        renderer.setSize(windowSize, windowSize);
        graph.needsUpdate(false, true);

        pickingTexture.width = windowSize;
        pickingTexture.height = windowSize;
    }

    CrystalSphere.prototype.resetConfig = function() {
        configure = {
            "Node Default Color": {
                name: "defaultNodeColor",
                type: "color",
                valueType: "string",
                renderType: "global",
                value: "#eeeeee"
            },
            "Edge Default Color": {
                name: "defaultEdgeColor",
                type: "color",
                valueType: "string",
                renderType: "global",
                value: "#eeeeee"
            },
            "Show Nodes": {
                name: "drawNodes",
                type: "boolean",
                valueType: "boolean",
                renderType: "global",
                value: true
            },
            "Node Color Mapping": {
                name: "color",
                type: "property",
                valueType: "string",
                renderType: "node",
                value: 'none'
            },
            "Node Size Mapping": {
                name: "size",
                type: "property",
                valueType: "number",
                renderType: "node",
                value: 'none'
            },
            "Filter Node Label by Node Size": {
                name: "labelThreshold",
                type: "number",
                valueType: "number",
                renderType: "global",
                min: 1,
                max: 10,
                value: 2,
            },
            "Node Label Mapping": {
                name: "_label",
                type: "property",
                valueType: "string",
                renderType: "node",
                value: 'id'
            },
            "Node Label Size": {
                name: "defaultLabelSize",
                type: "number",
                valueType: "number",
                renderType: "global",
                min: 5,
                max: 15,
                value: 9,
            },
            "Show Edges": {
                name: "drawEdges",
                type: "boolean",
                valueType: "boolean",
                renderType: "global",
                value: true
            },
            "Edge Color Mapping": {
                name: "color",
                type: "property",
                valueType: "string",
                renderType: "edge",
                value: 'none'
            },
            "Edge Label Mapping": {
                name: "_label",
                type: "property",
                valueType: "string",
                renderType: "edge",
                value: 'none'
            },
            "Edge Label Size": {
                name: "defaultEdgeLabelSize",
                type: "number",
                valueType: "number",
                renderType: "global",
                min: 5,
                max: 15,
                value: 9,
            },
            "Edge Thickness Mapping": {
                name: "size",
                type: "property",
                valueType: "number",
                renderType: "edge",
                value: 'label'
            },
            "Edge Style": {
                name: "type",
                type: "category",
                valueType: "string",
                renderType: "edge",
                value: 'line',
                categories: {
                    'Line': 'line',
                    'Curve': 'curve',
                    'Line With Arrow': 'arrow',
                    'Curve With Arrow': 'curvedArrow'
                }
            }
        }

    };

    CrystalSphere.prototype.render = function(render_refresh, _graph) {

        // dataset['nodes']
        console.log(_graph);
        var minx = 20000,miny = 20000,maxx = -20000,maxy = -20000;
        _graph.nodes.forEach(function(d){
            minx = Math.min(d["renderer1:x"],minx);
            maxx = Math.max(d["renderer1:x"],maxx);
            miny = Math.min(d["renderer1:y"],miny);
            maxy = Math.max(d["renderer1:y"],maxy);
        });
        _graph.nodes.forEach(function(d){
            d["x"] = (d["renderer1:x"] - minx)/(maxx - minx);
            d["y"] = (d["renderer1:y"] - miny)/(maxy - miny);
        });
        dataset = {};
        dataset["nodes"] = listToMap(_graph["nodes"]);
        dataset["links"] = _graph["edges"];
        dataset["properties"] = _graph["properties"]
        // dataset['links'] = dataset["edges"];
        // layout(dataset);
        number_of_nodes = Object.keys(dataset['nodes']).length;
        i2n = {};
        for (var n in dataset['nodes']) {
            i2n[dataset['nodes'][n].i] = n;
        }

        //
        if (!Detector.webgl) Detector.addGetWebGLMessage();
        windowSize = Math.min($("#viscomp").height(), $("#viscomp").width());
        camera = new THREE.PerspectiveCamera(45, 1, 1, 10000);
        camera.position.z = 300;

        //
        if (Global.debug) {
            camera.position.set(0, 0, -Global.unit * 2.8);
            camera.up.set(0, 1, 0);
            camera.lookAt(new THREE.Vector3(0, 0, 1));
        }

        //WebGLRenderer CanvasRenderer
        renderer = new THREE.WebGLRenderer({
            alpha: true
                // antialias: true
        });
        var animationID;
        renderer.context.canvas.addEventListener("webglcontextlost", function(event) {
            console.log("webglcontextlost");
            event.preventDefault();
            cancelAnimationFrame(animationID);
        }, false);

        renderer.context.canvas.addEventListener("webglcontextrestored", function(event) {
            console.log("webglcontextrestored");
        }, false);
        //
        renderer.setClearColor(0x19193B);
        renderer.setSize(windowSize, windowSize);
        //
        var container = document.getElementById('viscomp');
        $(container).empty();
        $(container).html('<canvas id="tmpcanvas" style="display:none"></canvas>');
        $(renderer.domElement).attr("id", "sgraph");
        container.appendChild(renderer.domElement);


        scene = new THREE.Scene();

        //**
        if (Global.picking) {
            pickingScene = new THREE.Scene();
            pickingTexture = new THREE.WebGLRenderTarget(windowSize, windowSize);
            pickingTexture.generateMipmaps = false;
        }

        mouse = new THREE.Vector2();
        container.addEventListener('mousemove', function(e) {
            mouse.x = e.clientX;
            mouse.y = e.clientY;
        });


        renderer.domElement.addEventListener('click', function(e) {
            mouseclicking = true;
        });

        //**

        sphere = new Geomotry.Sphere();
        sphere.layout(scene);

        //

        graph = new Graph(dataset, scene, pickingScene);
        if (Global.picking)
            renderer.render(pickingScene, camera, pickingTexture);
        //

        // var controls = new THREE.OrbitControls(camera, renderer.domElement);
        // controls.addEventListener('change', render);

        new Mouse.Drag(container, graph);
        new Mouse.Wheel(container, graph);

        //
        // window.addEventListener('resize', onWindowResize, false);

        // function onWindowResize() {


        //     // container.style.paddingLeft = ((window.innerWidth - windowSize) / 2) + 'px';
        // }
        renderer.render(scene, camera);
        animate();
    };

    CrystalSphere.prototype.addControlPanelTo = function(_is_new_graph, dom, updateColorLegend, setting) {

        var gui = new dat.GUI({
            autoPlace: false,
            width: '100%'
        });

        // if (_is_new_graph) {
        //     resetConfig();
        // }

        gui.addColor(setting, 'background').name("Background Color").onChange(function(value) {
            $("#viscomp").css("background-color", value);
            renderer.setClearColor(parseInt(value.replace(/^#/, ''), 16));

        });

        var customContainer = document.getElementById(dom);
        $(customContainer).empty();
        customContainer.appendChild(gui.domElement);
    };


};
