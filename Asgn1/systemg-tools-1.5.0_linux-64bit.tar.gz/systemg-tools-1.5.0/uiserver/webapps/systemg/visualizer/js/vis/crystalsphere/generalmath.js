// GeneralMath namespace
var ComplexMath = {};

ComplexMath.moduleSq = function(a) {
    return a[0] * a[0] + a[1] * a[1];
};

ComplexMath.getComplex = function(re, im) {
    var p = [];
    p[0] = re;
    p[1] = im;
    return p;
};

var VectorMath = {};

VectorMath.times3D = function(u, v) {
    return u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
};

VectorMath.cos3D = function(u, v) {
    return VectorMath.times3D(u, v) / (VectorMath.module3D(u) * VectorMath.module3D(v));
};

VectorMath.module3D = function(u) {
    return Math.sqrt(VectorMath.times3D(u, u));
};

VectorMath.sub2D = function(a, b) {
    var diff = [];
    diff[0] = a[0] - b[0];
    diff[1] = a[1] - b[1];
    return diff;
};

VectorMath.sub3D = function(u, v) {
    return [u[0] - v[0], u[1] - v[1], u[2] - v[2]];
};

VectorMath.add3D = function(u, v) {
    return [u[0] + v[0], u[1] + v[1], u[2] + v[2]];
};

VectorMath.sub3D = function(u, v) {
    var diff = [];
    diff[0] = u[0] - v[0];
    diff[1] = u[1] - v[1];
    diff[2] = u[2] - v[2];
    return diff;
};

VectorMath.corss = function(v1, v2) {
    return [
        v1[1] * v2[2] - v1[2] * v2[1],
        v1[2] * v2[0] - v1[0] * v2[2],
        v1[0] * v2[1] - v1[1] * v2[0]
    ]
};

VectorMath.normalize3 = function(v) {
    var module = VectorMath.module3D(v);
    return VectorMath.applyScalar3(v, 1 / module);
}

VectorMath.rotationByAxis = function(n1, n2) {
    var radian = VectorMath.radian3D(n1, n2);
    var axis = VectorMath.corss(n1, n2);

    return [radian, VectorMath.normalize3(axis)];
}

VectorMath.radian3D = function(u, v) {
    return Math.acos(VectorMath.cos3D(u, v));
};

VectorMath.getNormalVector3D = function(p1, p2, p3) {

    var x = ((p2[1] - p1[1]) * (p3[2] - p1[2]) - (p2[2] - p1[2]) * (p3[1] - p1[1])),
        y = ((p2[2] - p1[2]) * (p3[0] - p1[0]) - (p2[0] - p1[0]) * (p3[2] - p1[2])),
        z = ((p2[0] - p1[0]) * (p3[1] - p1[1]) - (p2[1] - p1[1]) * (p3[0] - p1[0]));

    return [x, y, z];
};

VectorMath.radianToDegree = function(radian) {
    return radian * (180 / Math.PI);
};

VectorMath.degreeToRadian = function(radian) {
    return degree * (Math.PI / 180);
};

VectorMath.applyMatrix3 = function(v, m) {

    var x = v[0];
    var y = v[1];
    var z = v[2];

    var re = [];

    re[0] = m[0] * x + m[3] * y + m[6] * z;
    re[1] = m[1] * x + m[4] * y + m[7] * z;
    re[2] = m[2] * x + m[5] * y + m[8] * z;

    return re;
};

VectorMath.applyByMatrix3 = function(m, v) {

    var x = v[0];
    var y = v[1];
    var z = v[2];

    var re = [];

    re[0] = m[0] * x + m[1] * y + m[2] * z;
    re[1] = m[3] * x + m[4] * y + m[5] * z;
    re[2] = m[6] * x + m[7] * y + m[8] * z;

    return re;
};

VectorMath.applyScalar3 = function(v, s) {

    return [v[0] * s, v[1] * s, v[2] * s];
};

VectorMath.getRotationMatrix = function(axis, radian) {
    var m = [];

    var sin = Math.sin(radian),
        cos = Math.cos(radian),
        x = axis[0],
        y = axis[1],
        z = axis[2];

    m[0] = cos + x * x * (1 - cos);
    m[1] = x * y * (1 - cos) - z * sin;
    m[2] = y * sin + x * z * (1 - cos);

    m[3] = z * sin + x * y * (1 - cos);
    m[4] = cos + y * y * (1 - cos);
    m[5] = -x * sin + y * z * (1 - cos);

    m[6] = -y * sin + x * z * (1 - cos);
    m[7] = x * sin + y * z * (1 - cos);
    m[8] = cos + z * z * (1 - cos);

    return m;
};

VectorMath.equals = function(u, v) {
    if (u.length != v.length) return false;

    for (var i in u)
        if (u[i] != v[i]) return false;

    return true;
};

var EuclideanMath = {};

EuclideanMath.getCircle3D = function(p1, p2, p3, nv) {

    if (nv == undefined) nv = VectorMath.getNormalVector3D(p1, p2, p3);

    var x1 = p1[0],
        y1 = p1[1],
        z1 = p1[2],

        x2 = p2[0],
        y2 = p2[1],
        z2 = p2[2],

        x3 = p3[0],
        y3 = p3[1],
        z3 = p3[2],

        n1 = nv[0],
        n2 = nv[1],
        n3 = nv[2];

    var xx1 = x1 * x1,
        xx2 = x2 * x2,
        xx3 = x3 * x3,

        yy1 = y1 * y1,
        yy2 = y2 * y2,
        yy3 = y3 * y3,

        zz1 = z1 * z1,
        zz2 = z2 * z2,
        zz3 = z3 * z3;

    var denominator = (2 * (n3 * x2 * y1 - n3 * x3 * y1 - n3 * x1 * y2 + n3 * x3 * y2 +
        n3 * x1 * y3 - n3 * x2 * y3 - n2 * x2 * z1 + n2 * x3 * z1 + n1 * y2 * z1 -
        n1 * y3 * z1 + n2 * x1 * z2 - n2 * x3 * z2 - n1 * y1 * z2 + n1 * y3 * z2 -
        n2 * x1 * z3 + n2 * x2 * z3 + n1 * y1 * z3 - n1 * y2 * z3));

    var x = (n3 * xx2 * y1 - n3 * xx3 * y1 - n3 * xx1 * y2 + n3 * xx3 * y2 -
        n3 * yy1 * y2 + n3 * y1 * yy2 + n3 * xx1 * y3 - n3 * xx2 * y3 + n3 * yy1 * y3 -
        n3 * yy2 * y3 - n3 * y1 * yy3 + n3 * y2 * yy3 - n2 * xx2 * z1 +
        n2 * xx3 * z1 + 2 * n1 * x1 * y2 * z1 + 2 * n2 * y1 * y2 * z1 - n2 * yy2 * z1 -
        2 * n1 * x1 * y3 * z1 - 2 * n2 * y1 * y3 * z1 + n2 * yy3 * z1 + n3 * y2 * zz1 -
        n3 * y3 * zz1 + n2 * xx1 * z2 - n2 * xx3 * z2 - 2 * n1 * x1 * y1 * z2 -
        n2 * yy1 * z2 + 2 * n1 * x1 * y3 * z2 + 2 * n2 * y1 * y3 * z2 - n2 * yy3 * z2 -
        2 * n3 * y1 * z1 * z2 + 2 * n3 * y3 * z1 * z2 + n2 * zz1 * z2 + n3 * y1 * zz2 -
        n3 * y3 * zz2 - n2 * z1 * zz2 - n2 * xx1 * z3 + n2 * xx2 * z3 +
        2 * n1 * x1 * y1 * z3 + n2 * yy1 * z3 - 2 * n1 * x1 * y2 * z3 - 2 * n2 * y1 * y2 * z3 +
        n2 * yy2 * z3 + 2 * n3 * y1 * z1 * z3 - 2 * n3 * y2 * z1 * z3 - n2 * zz1 * z3 +
        n2 * zz2 * z3 - n3 * y1 * zz3 + n3 * y2 * zz3 + n2 * z1 * zz3 -
        n2 * z2 * zz3) / denominator;

    var y = (n3 * xx1 * x2 - n3 * x1 * xx2 - n3 * xx1 * x3 + n3 * xx2 * x3 +
        n3 * x1 * xx3 - n3 * x2 * xx3 + n3 * x2 * yy1 - n3 * x3 * yy1 - n3 * x1 * yy2 +
        n3 * x3 * yy2 + n3 * x1 * yy3 - n3 * x2 * yy3 - 2 * n1 * x1 * x2 * z1 +
        n1 * xx2 * z1 + 2 * n1 * x1 * x3 * z1 - n1 * xx3 * z1 - 2 * n2 * x2 * y1 * z1 +
        2 * n2 * x3 * y1 * z1 + n1 * yy2 * z1 - n1 * yy3 * z1 - n3 * x2 * zz1 +
        n3 * x3 * zz1 + n1 * xx1 * z2 - 2 * n1 * x1 * x3 * z2 + n1 * xx3 * z2 +
        2 * n2 * x1 * y1 * z2 - 2 * n2 * x3 * y1 * z2 - n1 * yy1 * z2 + n1 * yy3 * z2 +
        2 * n3 * x1 * z1 * z2 - 2 * n3 * x3 * z1 * z2 - n1 * zz1 * z2 - n3 * x1 * zz2 +
        n3 * x3 * zz2 + n1 * z1 * zz2 - n1 * xx1 * z3 + 2 * n1 * x1 * x2 * z3 -
        n1 * xx2 * z3 - 2 * n2 * x1 * y1 * z3 + 2 * n2 * x2 * y1 * z3 + n1 * yy1 * z3 -
        n1 * yy2 * z3 - 2 * n3 * x1 * z1 * z3 + 2 * n3 * x2 * z1 * z3 + n1 * zz1 * z3 -
        n1 * zz2 * z3 + n3 * x1 * zz3 - n3 * x2 * zz3 - n1 * z1 * zz3 +
        n1 * z2 * zz3) / denominator;

    var z = (-n2 * xx1 * x2 + n2 * x1 * xx2 + n2 * xx1 * x3 - n2 * xx2 * x3 -
        n2 * x1 * xx3 + n2 * x2 * xx3 + 2 * n1 * x1 * x2 * y1 - n1 * xx2 * y1 -
        2 * n1 * x1 * x3 * y1 + n1 * xx3 * y1 + n2 * x2 * yy1 - n2 * x3 * yy1 -
        n1 * xx1 * y2 + 2 * n1 * x1 * x3 * y2 - n1 * xx3 * y2 - 2 * n2 * x1 * y1 * y2 +
        2 * n2 * x3 * y1 * y2 + n1 * yy1 * y2 + n2 * x1 * yy2 - n2 * x3 * yy2 -
        n1 * y1 * yy2 + n1 * xx1 * y3 - 2 * n1 * x1 * x2 * y3 + n1 * xx2 * y3 +
        2 * n2 * x1 * y1 * y3 - 2 * n2 * x2 * y1 * y3 - n1 * yy1 * y3 + n1 * yy2 * y3 -
        n2 * x1 * yy3 + n2 * x2 * yy3 + n1 * y1 * yy3 - n1 * y2 * yy3 +
        2 * n3 * x2 * y1 * z1 - 2 * n3 * x3 * y1 * z1 - 2 * n3 * x1 * y2 * z1 + 2 * n3 * x3 * y2 * z1 +
        2 * n3 * x1 * y3 * z1 - 2 * n3 * x2 * y3 * z1 - n2 * x2 * zz1 + n2 * x3 * zz1 +
        n1 * y2 * zz1 - n1 * y3 * zz1 + n2 * x1 * zz2 - n2 * x3 * zz2 - n1 * y1 * zz2 +
        n1 * y3 * zz2 - n2 * x1 * zz3 + n2 * x2 * zz3 + n1 * y1 * zz3 -
        n1 * y2 * zz3) / denominator;

    var r1 = VectorMath.module3D(VectorMath.sub3D([x, y, z], p1));
    // var r2 = VectorMath.module3D(VectorMath.sub3D([x, y, z], p2));
    // var r3 = VectorMath.module3D(VectorMath.sub3D([x, y, z], p3));
    // Global.log("r123");
    // Global.log(r1);
    // Global.log(r2);
    // Global.log(r3);
    return [[x, y, z], r1];
};


//