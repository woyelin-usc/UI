// // Riemann namespace
// var Riemann = {};

// Riemann.View = function() {

//     //
//     var rData = new Riemann.Data();

//     // var dataset = rData.random(10000,100);
//     // var dataset = rData.json("data/current.json");
//     var dataset = rData.json("data/imdb.json");
//     // var dataset = rData.whoosh_movie(4008);
//     // var dataset = rData.whoosh_movie(3114);
//     // var dataset = rData.json_online("dblp_vis_coauthor");
//     // var dataset = rData.json_online("idmb_3713-5647");
//     // var dataset = rData.json_online("idmb");

//     var number_of_nodes = Object.keys(dataset['nodes']).length;
//     var i2n = {};
//     for (var n in dataset['nodes']) {
//         i2n[dataset['nodes'][n].i] = n;
//     }

//     //
//     if (!Detector.webgl) Detector.addGetWebGLMessage();
//     var windowSize = Math.min(window.innerHeight, window.innerWidth);
//     var camera = new THREE.PerspectiveCamera(45, 1, 1, 10000);
//     camera.position.z = 300;

//     //
//     if (Global.debug) {
//         camera.position.set(0, 0, -Global.unit * 2.8);
//         camera.up.set(0, 1, 0);
//         camera.lookAt(new THREE.Vector3(0, 0, 1));
//     }

//     //WebGLRenderer CanvasRenderer
//     var renderer = new THREE.WebGLRenderer({
//         alpha: true
//         // antialias: true
//     });
//     var animationID;
//     renderer.context.canvas.addEventListener("webglcontextlost", function(event) {
//         console.log("webglcontextlost");
//         event.preventDefault();
//         cancelAnimationFrame(animationID);
//     }, false);

//     renderer.context.canvas.addEventListener("webglcontextrestored", function(event) {
//         console.log("webglcontextrestored");
//     }, false);
//     //
//     renderer.setClearColor(0xFFFFFF);
//     renderer.setSize(windowSize, windowSize);
//     //
//     var container = document.getElementById('viscomp');
//     $(container).empty();
//     $(container).html('<canvas id="tmpcanvas" style="display:none"></canvas>');
//     container.appendChild(renderer.domElement);


//     var scene = new THREE.Scene();

//     //**
//     if (Global.picking) {
//         var pickingScene = new THREE.Scene();
//         var pickingTexture = new THREE.WebGLRenderTarget(windowSize, windowSize);
//         pickingTexture.generateMipmaps = false;
//     }

//     var mouse = new THREE.Vector2();
//     container.addEventListener('mousemove', function(e) {
//         mouse.x = e.clientX;
//         mouse.y = e.clientY;
//     });

//     var mouseclicking = false;

//     renderer.domElement.addEventListener('click', function(e) {
//         mouseclicking = true;
//     });

//     //**

//     var sphere = new Geomotry.Sphere();
//     sphere.layout(scene);

//     //

//     var graph = new Graph(dataset, scene, pickingScene);
//     if (Global.picking)
//         renderer.render(pickingScene, camera, pickingTexture);
//     //

//     // var controls = new THREE.OrbitControls(camera, renderer.domElement);
//     // controls.addEventListener('change', render);

//     new Mouse.Drag(container, graph);
//     new Mouse.Wheel(container, graph);

//     //
//     window.addEventListener('resize', onWindowResize, false);

//     function onWindowResize() {
//         var windowSize = Math.min(window.innerHeight, window.innerWidth);
//         camera.updateProjectionMatrix();
//         renderer.setSize(windowSize, windowSize);
//         ControlPanel.forceWordleUpdate = true;
//         graph.needsUpdate(false, true);

//         pickingTexture.width = windowSize;
//         pickingTexture.height = windowSize;

//         // container.style.paddingLeft = ((window.innerWidth - windowSize) / 2) + 'px';
//     }

//     //

//     function render() {
//         renderer.render(scene, camera);
//     }

//     var highlighting = false;
//     var cur_highlighed_id = -1;

//     function picking() {
//         if (mouse.x == 0 && mouse.y == 0) return;

//         renderer.render(pickingScene, camera, pickingTexture);
//         var gl = renderer.getContext();
//         var pixelBuffer = new Uint8Array(4);
//         gl.readPixels(mouse.x, pickingTexture.height - mouse.y, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixelBuffer);
//         var id = (pixelBuffer[0] << 16) | (pixelBuffer[1] << 8) | (pixelBuffer[2]);

//         if (id >= number_of_nodes) {
//             if (highlighting) {
//                 graph.unhighlight();
//                 highlighting = false;

//                 hideTooltip();

//                 cur_highlighed_id = -1;
//             }
//         } else {
//             highlighting = true;

//             if (cur_highlighed_id != id) {
//                 cur_highlighed_id = id;
//                 graph.highlight(id);
//             }
//             var node = dataset['nodes'][i2n[id]];
//             showTooltip(mouse.x, mouse.y, node);
//             // showTooltipIDOnly(mouse.x, mouse.y, node);

//             if (mouseclicking) {
//                 console.log("clicked :" + id);
//                 var url = "http://www.imdb.com/title/tt" + node.imdbID;
//                 if (Global.useIFrame) {
//                     loadframe(url);
//                 } else {
//                     window.open(url);
//                 }
//             }

//         }
//         mouseclicking = false;
//     }

//     function get_direction(x, y) {
//         var hw = window.innerWidth / 2,
//             hh = window.innerHeight / 2;
//         if (x < hw && y < hh) return 0;
//         if (x >= hw && y < hh) return 1;
//         if (x >= hw && y >= hh) return 2;
//         if (x < hw && y >= hh) return 3;
//     }

//     function get_tipsy(id) {
//         return '<div class="tipsy" style="position:absolute;left:0px; top:0px;display: none; visibility: visible; opacity: 0.8;" id="tooltip-' + id + '"><div class="tipsy-arrow"></div><div class="tipsy-inner" style="padding:10px;padding-bottom:13px"></div></div>';
//     }

//     function showTooltipIDOnly(x, y, node) {
//         $(".tipsy").remove();

//         var id = node.id;

//         $("body").append(get_tipsy(id));

//         var content = $("#tooltip-" + id + " .tipsy-inner");
//         content.text('id : ' + id);

//         var wrapper = $("#tooltip-" + id);

//         var direction = get_direction(x, y);
//         var arrow = $("#tooltip-" + id + " .tipsy-arrow");
//         if (direction == 0) {
//             wrapper.addClass("tipsy-nw");
//             wrapper.css("top", y + 15);
//             wrapper.css("left", x - 13);
//         } else if (direction == 1) {
//             wrapper.addClass("tipsy-ne");
//             wrapper.css("top", y + 15);
//             wrapper.css("left", x - wrapper.width() + 3);
//         } else if (direction == 2) {
//             wrapper.addClass("tipsy-se");
//             wrapper.css("top", y - wrapper.height() - 15);
//             wrapper.css("left", x - wrapper.width() + 3);
//         } else if (direction == 3) {
//             wrapper.addClass("tipsy-sw");
//             wrapper.css("top", y - wrapper.height() - 15);
//             wrapper.css("left", x - 13);
//         }

//         wrapper.show();
//     }

//     function showTooltip(x, y, node) {
//         $(".tipsy").remove();

//         var id = node.id,
//             title = node.title,
//             img = node.img,
//             year = node.year;

//         $("body").append(get_tipsy(id));

//         var content = $("#tooltip-" + id + " .tipsy-inner");
//         content.html('<p style="font-size: 14px;">' + title + ' (' + year + ')</p><img width="150px" src="' + img + '">');

//         var wrapper = $("#tooltip-" + id);

//         var direction = get_direction(x, y);
//         var arrow = $("#tooltip-" + id + " .tipsy-arrow");
//         if (direction == 0) {
//             wrapper.addClass("tipsy-nw");
//             wrapper.css("top", y + 15);
//             wrapper.css("left", x - 13);
//         } else if (direction == 1) {
//             wrapper.addClass("tipsy-ne");
//             wrapper.css("top", y + 15);
//             wrapper.css("left", x - wrapper.width() + 3);
//         } else if (direction == 2) {
//             wrapper.addClass("tipsy-se");
//             wrapper.css("top", y - wrapper.height() - 15);
//             wrapper.css("left", x - wrapper.width() + 3);
//         } else if (direction == 3) {
//             wrapper.addClass("tipsy-sw");
//             wrapper.css("top", y - wrapper.height() - 15);
//             wrapper.css("left", x - 13);
//         }

//         wrapper.show();
//     }

//     function loadframe(url) {
//         var iframe = $("#netflix", window.parent.document);
//         if (iframe.length == 0) {
//             $("#content2", window.parent.document).html('<iframe id="netflix" name="netflix" src="' + url + '" frameborder="0"></iframe>');
//         } else {
//             iframe.attr("src", url);
//         }
//         return false;
//     }

//     function hideTooltip() {
//         $(".tipsy").remove();
//     }

//     function animate() {
//         animationID = requestAnimationFrame(animate);
//         graph.update();
//         render();
//         // stats.update();

//         if (Global.picking) {
//             // if (ControlPanel.mouseStatus == 0 && ControlPanel.E2GFactor > Global.E2GFactorThreshold2) {
//             if (ControlPanel.E2GFactor > Global.E2GFactorThreshold2) {
//                 picking();
//             } else {
//                 if (highlighting) {
//                     graph.unhighlight();
//                     highlighting = false;
//                     hideTooltip();
//                 }
//             }
//         }
//     }

//     // public

//     this.render = render;
//     this.animate = animate;

//     this.test = function(val) {
//         console.log(val);
//     }

//     this.needsUpdate = function(updateGraph, updateSurface) {
//         graph.needsUpdate(updateGraph, updateSurface);
//     }
// }

// Riemann.Data = function() {

//     this.random = function(nodeN, edgeN) {
//         if (nodeN == undefined) nodeN = 100;
//         if (edgeN == undefined) edgeN = 100;

//         // 2D points
//         var nodes = [];
//         for (var i = 0; i < nodeN; i++) {
//             nodes[i] = {},
//             nodes[i].x = Math.random() * 2 - 1,
//             nodes[i].y = Math.random() * 2 - 1;
//         }

//         var links = [];
//         for (var i = 0; i < edgeN; i++) {
//             links[i] = {},
//             links[i]["source"] = Math.floor((Math.random() * nodeN)),
//             links[i]["target"] = Math.floor((Math.random() * nodeN));
//         }

//         var graph = {
//             "nodes": nodes,
//             "links": links
//         };

//         showStatistics(graph);

//         return graph;
//     }

//     this.gaussian = function(nodeN, edgeN) {
//         if (nodeN == undefined) nodeN = 100;
//         if (edgeN == undefined) edgeN = 100;

//         // 2D points
//         var nodes = [];
//         for (var i = 0; i < nodeN; i++) {
//             nodes[i] = {},
//             nodes[i].x = Math.random() * 2 - 1,
//             nodes[i].y = Math.random() * 2 - 1;
//         }

//         var links = [];
//         for (var i = 0; i < edgeN; i++) {
//             links[i] = {},
//             links[i]["source"] = Math.floor((Math.random() * nodeN)),
//             links[i]["target"] = Math.floor((Math.random() * nodeN));
//         }

//         var graph = {
//             "nodes": nodes,
//             "links": links
//         };

//         showStatistics(graph);

//         return graph;
//     }



//     function showStatistics(graph) {
//         var n_nodes = Object.keys(graph['nodes']).length;
//         var n_edges = graph['links'].length;
//         var density = n_edges / n_nodes;

//         // Global.msg("# nodes : " + n_nodes);
//         // Global.msg("# edges : " + n_edges);
//         // Global.msg("# density : " + density);
//         console.log("# nodes : " + n_nodes);
//         console.log("# edges : " + n_edges);
//         console.log("# edge density : " + density);
//     }

//     // new Riemann.Data().test();
//     this.test = function() {
//         // var graph = this.json("data/nba_100.json");
//         var graph = this.random();
//         console.log(graph);
//     }
// }

// // new Riemann.Data().test();

// var rView = new Riemann.View();
// rView.render();
// rView.animate();

// //
