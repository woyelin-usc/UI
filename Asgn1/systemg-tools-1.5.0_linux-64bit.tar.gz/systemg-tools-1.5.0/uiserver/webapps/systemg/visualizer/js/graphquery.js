var graphQuery = {};

var TASK_NUMBER = 0;
var execQuery = function(content, callback, async) {
    TASK_NUMBER += 1;
    var sptask = "task";
    if (TASK_NUMBER > 1) {
        sptask = "tasks";
    }
    $("#task-number").text(TASK_NUMBER + " " + sptask + " running");
    var _async = "true";
    if (arguments.length == 3) {
        _async = async;
    };
    var taskID = "task" + Math.floor(Math.random() * 1000000);
    var url_base = "/systemg/";
    $("#task-list").append("<li id='" + taskID + "' class='list-group-item'>" + url_base + content.url + "</li>");
    if (content.endpoint != undefined) {
        url_base += content.endpoint;
    } else {
        url_base += "api/rest/";
    }
    $.ajax({
        type: content.type,
        url: url_base + content.url,
        async: _async,
        dataType: "json",
        // data: content,
        success: function(data) {
            // console.log(data);
            $("#" + taskID).remove();
            TASK_NUMBER -= 1;
            if (TASK_NUMBER > 1) {
                sptask = "tasks";
            }
            $("#task-number").text(TASK_NUMBER + " " + sptask + " running");
            addToConsole("cmd", data['query']);
            if (callback) {
                console.log(data);
                callback(data);
            }
        },
        error: function(data) {
            // if (data.status == 404) {
            alert("Cannot connect to the server. Please try again later or contact the system administrator to check if the server is running properly.");
            // }
        }
    });
}

graphQuery.getGraphList = function(callback) {
    var query = "list_all";
    graphQuery.runGShell(query, callback);
}

graphQuery.createGraph = function(graph_id, type, callback) {
    var url = "graphs/" + graph_id + "?_cmd=create&_type=" + type;
    var content = {
        type: "POST",
        url: url
    }
    execQuery(content, callback);
    // var query = "create --graph \"" + graph_id + "\" --type " + type;
    // graphQuery.runGShell(query, callback);
}

graphQuery.loadCsvVertices = function(graph_id, url, keypos, label, callback) {
    var url = "graphs/" + graph_id + "/vertices?_cmd=load&_csvurl=" + url + "&_keypos=" + keypos + "&_label=" + label;
    var content = {
        type: "POST",
        url: url
    }
    execQuery(content, callback)
    // var query = "load_csv_vertices --graph \"" + graph_id + "\" --csvurl " + url + " --keypos " + keypos + " --label " + label;
    // console.log(query);
    // graphQuery.runGShell(query, callback);
}

graphQuery.loadCsvEdges = function(graph_id, url, srcpos, targpos, label, callback) {
    var url = "graphs/" + graph_id + "/edges?_cmd=load&_csvurl=" + url + "&_srcpos=" + srcpos + "&_targpos=" + targpos + "&_label=" + label;
    var content = {
        type: "POST",
        url: url
    }
    execQuery(content, callback);
    // var query = "load_csv_edges --graph \"" + graph_id + "\" --csvurl " + url + " --srcpos " + srcpos + " --targpos " + targpos + " --label " + label;
    // graphQuery.runGShell(query, callback);
}

graphQuery.getGraph = function(graph_id, callback) {
    // var url = "graphs/" + graph_id;
    // var content = {
    //     type: "GET",
    //     url: url
    // }
    // execQuery(content, callback);
    var query = "print_all --graph \"" + graph_id + "\"";
    graphQuery.runGShell(query, callback);
}
    // public function queryNodeFilteredGraph($user_name, $graph_id, $fields, $condition) {

graphQuery.queryNodeFilteredGraph = function(graph_id, fields, condition, callback) {
        // fields = escape(fields);
        // condition = escape(condition);
        // var tmpRnd = Math.floor(Math.random() * 10000);
        // var url = "graphs/" + graph_id + "/vertices?_cmd=filter&_prop=" + fields + "&_condition=\"" + condition + "\"&_out=result" + tmpRnd;
        // var content = {
        //     type: "GET",
        //     url: url
        // }
        // execQuery(content, function() {
        //     url = "graphs/" + graph_id + "?_cmd=subgraph&_in=result" + tmpRnd + "&_maxnumvertices=2000";
        //     content.url = url;
        //     execQuery(content, callback);
        // })
        var query = "filter_graph --graph " + graph_id + " --type vertex --condition \"" + condition + "\" --prop " + fields;
        var url = "api/gshell?_cmd=" + escape(query);
        var content = {
            type: "GET",
            url: url,
            endpoint: ""
        }
        execQuery(content, callback);

    }
    // public function flushGraph($user_name, $graph_id) {

// graphQuery.queryEdgeFilteredGraph = function(graph_id, fields, condition, callback) {
//     fields = escape(fields);
//     condition = escape(condition);
//     var tmpRnd = Math.floor(Math.random() * 10000);
//     var url = "graphs/" + graph_id + "/edges?_cmd=filter&_prop=" + fields + "&_condition=\"" + condition + "\"&_out=result" + tmpRnd;
//     var content = {
//         type: "GET",
//         url: url
//     }
//     execQuery(content, function() {
//         url = "graphs/" + graph_id + "/analytics?_cmd=print_all&_in=result" + tmpRnd + "&_maxnumvertices=2000";
//         content.url = url;
//         execQuery(content, callback);
//     })
// }

graphQuery.queryEdgeFilteredGraph = function(graph_id, fields, condition, callback) {
    // fields = escape(fields);
    // condition = escape(condition);
    var query = "filter_graph --graph " + graph_id + " --type edge --condition \"" + condition + "\" --prop " + fields;
    var url = "api/gshell?_cmd=" + escape(query);
    var content = {
        type: "GET",
        url: url,
        endpoint: ""
    }
    execQuery(content, callback);
}

graphQuery.flushGraph = function(graph_id) {
        // var url = "graphs/" + graph_id + "?_cmd=flush";
        // var content = {
        //     type: "POST",
        //     url: url
        // }
        // execQuery(content, null, false);
        var query = "flush --graph \"" + graph_id + "\"";
        graphQuery.runGShell(query);
    }
    // function deleteGraph($user_name, $graph_id) {
graphQuery.deleteGraph = function(graph_id, callback) {
    // var url = "graphs/" + graph_id;
    // var content = {
    //     type: "DELETE",
    //     url: url
    // }
    // execQuery(content, callback);
    var query = "delete --graph \"" + graph_id + "\"";
    graphQuery.runGShell(query, callback);
}

// function deleteNode($user_name, $graph_id, $node_id) {
graphQuery.deleteNode = function(graph_id, node_id, callback) {
    // var url = "graphs/" + graph_id + "/vertices/" + escape(node_id);
    // var content = {
    //     type: "DELETE",
    //     url: url
    // }
    // execQuery(content, callback);
    var query = "delete_vertex --graph \"" + graph_id + "\" --id \"" + node_id +"\"";
    graphQuery.runGShell(query, callback);
}

graphQuery.deleteEdge = function(graph_id, edge, callback) {
    var query = "delete_edge --graph \"" + graph_id + "\" --eid \"" + edge.id +"\" --src \"" + edge.source +"\" --targ \"" + edge.target +"\"";
    graphQuery.runGShell(query, callback);
}

// function updateNodeValue($user_name, $graph_id, $node_id, $prop, $value)
graphQuery.updateNodeValue = function(graph_id, node_id, prop, value, callback) {
    // var url = "graphs/" + escape("\"" + graph_id + "\"") + "/vertices/" + "\"" + escape(node_id) + "\"" + "?" + escape("\"" + prop + "\"") + "=" + escape("\"" + value + "\"");
    // var content = {
    //     type: "POST",
    //     url: url
    // }
    // execQuery(content, callback);
    var query = "add_vertex --graph \"" + graph_id + "\" --id \"" + node_id + "\" --prop " + prop + ":\"" + value + "\"";
    graphQuery.runGShell(query, callback);

}

graphQuery.updateEdgeValue = function(graph_id, edge, prop, value, callback) {
    // var url = "graphs/" + escape("\"" + graph_id + "\"") + "/vertices/" + "\"" + escape(node_id) + "\"" + "?" + escape("\"" + prop + "\"") + "=" + escape("\"" + value + "\"");
    // var content = {
    //     type: "POST",
    //     url: url
    // }
    // execQuery(content, callback);
    var query = "update_edge --graph \"" + graph_id + "\" --eid \"" + edge.id +"\" --src \"" + edge.source +"\" --targ \"" + edge.target +"\" --prop " + prop + ":\"" + value + "\"";
    graphQuery.runGShell(query, callback);

}

// function getSafeGraph($user_name, $graph_id, $node_size){
// graphQuery.getSafeGraph = function(graph_id, node_size, callback) {
//     var url = "graphs/" + graph_id + "/vertices?_cmd=count";
//     var content = {
//         type: "GET",
//         url: url
//     }
//     execQuery(content, function(data) {
//         var result = (data);
//         var v_number = result["info"][result["info"].length - 1]["number of vertices"];
//         if (v_number <= node_size) {
//             graphQuery.getGraph(graph_id, callback);
//         } else {
//             graphQuery.getRandomGraph(graph_id, node_size, callback);
//         }
//     })
// }

graphQuery.getSafeGraph = function(graph_id, node_size, callback) {
    var query = "get_sample_graph --depth 1 --graph " + graph_id + " --maxnumvertices " + node_size;
    var url = "api/gshell?_cmd=" + escape(query);
    var content = {
        type: "GET",
        url: url,
        endpoint: ""
    }
    execQuery(content, callback);
}

// function getRandomGraph($user_name, $graph_id, $node_size)
graphQuery.getRandomGraph = function(graph_id, node_size, callback) {
    // var url = "graphs/" + graph_id + "/vertices?_cmd=random&_num=10&_out=tmpValue";
    // var content = {
    //     type: "GET",
    //     url: url
    // }
    // execQuery(content, function(data) {
    //     var result = (data);
    //     graphQuery.getEgonet(graph_id, result["nodes"][0]["id"], callback);
    // })
    var url = "graphs/" + graph_id + "/vertices?_cmd=random&_num=1&_out=tmpValue";
    var content = {
        type: "GET",
        url: url
    }
    execQuery(content, function(data) {
        url = "graphs/" + graph_id + "?_cmd=egonet&_in=tmpValue&_depth=2";

        content = {
            type: "GET",
            url: url
        }
        execQuery(content, callback);
    })
}

graphQuery.calDegree = function(graph_id, callback) {
    var url = "graphs/" + graph_id + "/analytics?_cmd=analytic_degree_centrality&_debugmode=2";
    var content = {
        type: "GET",
        url: url
    }
    execQuery(content, callback);
}

// graphQuery.getEgonet($user_name, $graph_id, $node_id) {
graphQuery.getEgonet = function(graph_id, node_id, callback) {
    var url = "graphs/" + graph_id + "?_cmd=egonet&_id=" + escape(node_id) + "&_depth=2";
    var content = {
        type: "GET",
        url: url
    }
    execQuery(content, callback);
}

// function runAnalytics($user_name, $graph_id, $cmd) {
graphQuery.runAnalytics = function(graph_id, cmd, callback) {
    var url = "graphs/" + graph_id + "/analytics?" + cmd;
    var content = {
        type: "GET",
        url: url
    }
    execQuery(content, callback);
}

graphQuery.getGraphInfo = function(graph_id, callback) {
    var url = "api/gshell?_cmd=" + escape("get_graph_info --graph " + graph_id);
    var content = {
        type: "GET",
        url: url,
        endpoint: ""
    }
    execQuery(content, callback);
}

graphQuery.runGShell = function(query, callback) {
    var url = "api/gshell?_cmd=" + escape(query);
    var content = {
        type: "GET",
        url: url,
        endpoint: ""
    }
    execQuery(content, callback);
}

graphQuery.getAnalyticList = function(callback) {
    var url = "api/gshell?_cmd=" + escape("list_analytics");
    var content = {
        type: "GET",
        url: url,
        endpoint: ""
    }
    execQuery(content, callback);
}

graphQuery.runRawQuery = function(cmd, type, callback) {
    var url = "api/" + type + "?_cmd=" + escape(cmd).replaceAll("\\+", "%2B");
    var content = {
        type: "GET",
        url: url,
        endpoint: ""
    }
    execQuery(content, callback);
}
