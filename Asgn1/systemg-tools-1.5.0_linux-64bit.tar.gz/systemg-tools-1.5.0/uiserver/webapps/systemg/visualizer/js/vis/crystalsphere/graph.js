// Geomotry namespace
var Geomotry = {};

Graph = function(graph, scene, pickingScene) {
    var graphNeedsUpdateFlag = false;
    var surfaceNeedsUpdateFlag = false;
    var _graph = graph,
        _nodes = _graph["nodes"],
        _edges = _graph["links"],
        _genres = _graph["genres"],
        _kde = _graph["kde"],
        _scene = scene,
        _pickingScene = pickingScene;

    var nodes = null,
        edges = null,
        surface = null,
        pickingBox = null;

    // nodes = new Geomotry.Nodes(_nodes, _scene, _pickingScene);
    // edges = new Geomotry.Edges(_graph, _scene); //TODO
    surface = new Surface(_graph, _kde, _scene, _genres);

    if (Global.picking)
        pickingBox = new Geomotry.PickingBox(_nodes, _pickingScene);

    this.layout = function() {
        if (nodes) nodes.layout();
        if (edges) edges.layout();
        if (surface) surface.layout();
        if (pickingBox) pickingBox.layout();
    };

    this.render = function() {
        if (nodes) nodes.render();
        if (edges) edges.render();
        if (surface) surface.render();
        if (pickingBox) pickingBox.render();
    };

    this.update = function() {
        if (graphNeedsUpdateFlag) {
            graphNeedsUpdateFlag = false;

            if (nodes) nodes.update();
            if (edges) edges.update();
        }
        if (surfaceNeedsUpdateFlag) {
            surfaceNeedsUpdateFlag = false;

            if (surface) surface.update();
            if (pickingBox) pickingBox.update();
        }
    };

    this.translate = function(delta) {
        var dx = delta[0] * Global.translationFactor / ControlPanel.E2GFactor,
            dy = delta[1] * Global.translationFactor / ControlPanel.E2GFactor;

        ControlPanel.translate[0] += dx;
        ControlPanel.translate[1] += dy;

        // for (var i in _nodes) {
        //     var node = _nodes[i];
        //     node.x += dx,
        //     node.y += dy;
        // }
        // if (surface) surface.rotate(delta); //TODO
        // if (surface) surface.translate(dx, dy); //TODO
    };

    this.highlight = function(i) {
        if (surface) surface.highlight(i);
        if (nodes) nodes.highlight(i); //TODO
        this.needsUpdate(true, true);
    }

    this.unhighlight = function() {
        surface.unhighlight();
        // nodes.unhighlight();//TODO
        this.needsUpdate(false, true);
    }

    this.needsUpdate = function(updateGraph, updateSurface) {
        if (updateGraph != false) graphNeedsUpdateFlag = true;
        if (updateSurface != false) surfaceNeedsUpdateFlag = true;
    }

    this.layout();
    this.render();
};

Geomotry.PickingBox = function(nodes, pickingScene) {

    var _nodes = nodes,
        _pickingScene = pickingScene;

    var dataItems = [],
        pickingItems = [];

    this.layout = function() {

        dataItems = [];

        //

        for (var i in _nodes) {
            var node = _nodes[i];
            dataItems.push({
                "p3d": mapE2G([node.x + ControlPanel.translate[0], node.y + ControlPanel.translate[1]]),
                "i": node.i
            });
        }
    };

    this.render = function() {

        pickingItems = [];

        //

        var pickingMaterial = new THREE.MeshBasicMaterial({
            vertexColors: THREE.VertexColors
        });

        for (var i = 0; i < dataItems.length; i++) {
            var p3d = dataItems[i].p3d;
            var index = dataItems[i].i;

            var pickingGeom = new THREE.BoxGeometry(Global.nodeBoxSize, Global.nodeBoxSize, Global.nodeBoxSize);
            var pickingColor = new THREE.Color(index);
            applyVertexColors(pickingGeom, pickingColor);

            var pickingCube = new THREE.Mesh(pickingGeom, pickingMaterial);
            if (p3d[2] < 0) {
                pickingCube.position.x = 99999;
                pickingCube.position.y = 99999;
                pickingCube.position.z = 0;
            } else {
                pickingCube.position.x = p3d[0];
                pickingCube.position.y = p3d[1];
                pickingCube.position.z = p3d[2];
            }

            pickingItems.push(pickingCube);
            _pickingScene.add(pickingCube);
        }
    };

    this.update = function() {

        if (ControlPanel.E2GFactor <= Global.E2GFactorThreshold) return;

        this.layout();

        for (var i = 0; i < dataItems.length; i++) {
            var p3d = dataItems[i].p3d;

            if (p3d[2] < 0) {
                pickingItems[i].position.x = 99999;
                pickingItems[i].position.y = 99999;
                pickingItems[i].position.z = 0;
            } else {
                pickingItems[i].position.x = p3d[0];
                pickingItems[i].position.y = p3d[1];
                pickingItems[i].position.z = p3d[2];
            }
        }
    };
    //

    function applyVertexColors(g, c) {
        g.faces.forEach(function(f) {
            var n = (f instanceof THREE.Face3) ? 3 : 4;
            for (var j = 0; j < n; j++) {
                f.vertexColors[j] = c;
            }
        });
    }

    function mapE2G(ep) {

        var factor = ControlPanel.E2GFactor;
        var scale = Global.unit;

        var z = [ep[0] * factor, ep[1] * factor];

        var zModuleSq = ComplexMath.moduleSq(z);

        // be careful with the coordinate system in WebGL
        var XYZ = [
            2 * z[0] / (1 + zModuleSq) * scale,
            2 * z[1] / (1 + zModuleSq) * scale, //
            (1 - zModuleSq) / (1 + zModuleSq) * scale
        ];

        return XYZ;
    };
};


Geomotry.Nodes = function(nodes, scene, pickingScene) {

    var _nodes = nodes,
        _scene = scene,
        _pickingScene = pickingScene;

    var dataItems = [],
        visualItems = [],
        pickingItems = [];

    var material = new THREE.MeshBasicMaterial({
        color: Global.nodeColor3D
    });

    var highlightMaterial = new THREE.MeshBasicMaterial({
        color: 'red'
    });

    var highlighted = -1;

    this.highlight = function(i) {
        highlighted = i;
    }

    this.unhighlight = function() {
        highlighted = -1;
    }

    this.layout = function() {

        dataItems = [];

        //

        for (var i in _nodes) {
            var node = _nodes[i];
            node.p3d = mapE2G([node.x + ControlPanel.translate[0], node.y + ControlPanel.translate[1]]);
            dataItems.push({
                "p3d": node.p3d
            });
        }
    };

    this.render = function() {

        visualItems = [];
        pickingItems = [];

        //

        //**
        var pickingMaterial = new THREE.MeshBasicMaterial({
            vertexColors: THREE.VertexColors
        });
        //**

        for (var i = 0; i < dataItems.length; i++) {
            var p3d = dataItems[i].p3d;
            //
            var geo = new THREE.SphereGeometry(Global.nodeSize3D, Global.nodeSegmentW, Global.nodeSegmentH);
            var shape = new THREE.Mesh(geo, material);
            shape.position.x = p3d[0];
            shape.position.y = p3d[1];
            shape.position.z = p3d[2];
            _scene.add(shape);
            visualItems.push(shape);

            //**
            var pickingGeom = new THREE.BoxGeometry(Global.nodeBoxSize, Global.nodeBoxSize, Global.nodeBoxSize);
            var pickingColor = new THREE.Color(i);
            applyVertexColors(pickingGeom, pickingColor);

            var pickingCube = new THREE.Mesh(pickingGeom, pickingMaterial);
            pickingCube.position.copy(shape.position);

            pickingItems.push(pickingCube);
            if (_pickingScene) _pickingScene.add(pickingCube);
            //**
        }
    };

    this.update = function() {

        this.layout();

        for (var i = 0; i < dataItems.length; i++) {
            var p3d = dataItems[i].p3d;

            var visualItem = visualItems[i];

            visualItem.position.x = p3d[0];
            visualItem.position.y = p3d[1];
            visualItem.position.z = p3d[2];

            if (i == highlighted) {
                if (visualItem.material != highlightMaterial) {
                    visualItem.material = highlightMaterial;
                }
            } else if (visualItem.material == highlightMaterial) visualItem.material = material;

            //**
            pickingItems[i].position.copy(visualItem.position);
            //**
        }
    };
    //

    function applyVertexColors(g, c) {
        g.faces.forEach(function(f) {
            var n = (f instanceof THREE.Face3) ? 3 : 4;
            for (var j = 0; j < n; j++) {
                f.vertexColors[j] = c;
            }
        });
    }

    function mapE2G(ep) {

        var factor = ControlPanel.E2GFactor;
        var scale = Global.unit;

        var z = [ep[0] * factor, ep[1] * factor];

        var zModuleSq = ComplexMath.moduleSq(z);

        // be careful with the coordinate system in WebGL
        var XYZ = [
            2 * z[0] / (1 + zModuleSq) * scale,
            2 * z[1] / (1 + zModuleSq) * scale, //
            (1 - zModuleSq) / (1 + zModuleSq) * scale
        ];

        return XYZ;
    };

    function mapG2E(XYZ) {

        var factor = ControlPanel.E2GFactor;
        var scale = Global.unit;

        return [XYZ[0] / (scale + XYZ[2]) / factor, XYZ[1] / (scale + XYZ[2]) / factor];
    };
};

Geomotry.Edges = function(graph, scene) {

    var _graph = graph;
    var _scene = scene;

    var dataItems = [];
    var visualItems = [];

    this.layout = function() {

        dataItems = [];

        //

        var nodes = _graph["nodes"],
            edges = _graph["links"];

        for (var i in edges) {
            var edge = edges[i],
                source = edge.source,
                target = edge.target;

            var node1 = nodes[source],
                node2 = nodes[target];

            if (node1 == undefined || node2 == undefined) {
                Global.warning("Node pair not found, skipped : " + i, "Geomotry.Edges.layout");
                continue;
            }

            var p3D1 = node1.p3d,
                p3D2 = node2.p3d;

            // TODO: potential problem
            // If new overlapping happens in latter frame, e.g., after some rotations
            // The existing edges connecting those overlapping nodes will not be updated 
            // And it is slow to add / remove existing object, i.e., the edges from the scene
            // So, to keep the consistency, I removed this judgement to avoid this situation

            // if (VectorMath.equals(p3D1, p3D2)) {
            // Global.warning("Two nodes have the same position, skipped : " + i, "Geomotry.Edges.layout");
            // continue;
            // }

            var circle = getArcEdge(p3D1, p3D2),
                r = circle[0],
                c = circle[1],
                nv = circle[2];

            var rotation = VectorMath.rotationByAxis(Global.nv2D, nv),
                radian = rotation[0],
                axis = rotation[1],
                rotationMatrix = VectorMath.getRotationMatrix(axis, radian),

                irotation = VectorMath.rotationByAxis(nv, Global.nv2D),
                iradian = irotation[0],
                iaxis = irotation[1],

                irotationMatrix = VectorMath.getRotationMatrix(iaxis, iradian);

            //
            var origin0 = [r, 0, 0], // the end point of the starting line. it locates at the right side.
                originP3D1 = VectorMath.applyByMatrix3(irotationMatrix, VectorMath.sub3D(p3D1, c)),
                originP3D2 = VectorMath.applyByMatrix3(irotationMatrix, VectorMath.sub3D(p3D2, c));

            var rd1 = VectorMath.radian3D(originP3D1, origin0),
                rd2 = VectorMath.radian3D(originP3D2, origin0);

            if (originP3D1[1] < 0) rd1 = Math.PI * 2 - rd1;
            if (originP3D2[1] < 0) rd2 = Math.PI * 2 - rd2;

            var sortedrd = sort(rd1, rd2),
                rd1 = sortedrd[0],
                rd2 = sortedrd[1];

            //
            if (Global.debug) {
                Global.msg("3D points");
                Global.msg("points3D.push([" + p3D1 + "]);");
                Global.msg("points3D.push([" + p3D2 + "]);");
                Global.msg("2D points");
                Global.msg("points3D.push([" + originP3D1 + "]);");
                Global.msg("points3D.push([" + originP3D2 + "]);");

                Global.log("---");
                Global.log("Edge.layout");
                Global.log("p3D");
                Global.log(p3D1);
                Global.log(p3D2);

                Global.log("origin");
                Global.log(origin0);
                Global.log(originP3D1);
                Global.log(originP3D2);

                Global.log("radian before");
                Global.log(rd1);
                Global.log(rd2);
                Global.log(Math.abs(rd1 - rd2));
                Global.log(VectorMath.radianToDegree(rd1));
                Global.log(VectorMath.radianToDegree(rd2));
            }

            //
            var pole0 = VectorMath.applyByMatrix3(irotationMatrix, VectorMath.sub3D(Global.infinite, c)),
                poleRadian = VectorMath.radian3D(origin0, pole0);

            if (pole0[1] < 0) poleRadian = Math.PI * 2 - poleRadian;
            //

            if (Global.debug) {
                Global.msg("rd1: " + rd1);
                Global.msg("poleRadian: " + poleRadian);
                Global.msg("rd2: " + rd2);
            }

            var newrd = [rd1, rd2];

            if (rd1 < poleRadian && rd2 > poleRadian) {
                // Global.msg("rd1 < poleRadian && rd2 > poleRadian");
                if (rd2 - rd1 < Math.PI) {
                    // Global.msg("less than PI");
                    newrd = bigCircle(rd1, rd2);
                } else {
                    // Global.msg("larger than PI");
                    newrd = smallCircle(rd1, rd2);
                }
            } else {
                // Global.msg("NOT rd1 < poleRadian && rd2 > poleRadian");
                if (rd2 - rd1 < Math.PI) {
                    // Global.msg("less than PI");
                    newrd = smallCircle(rd1, rd2);
                } else {
                    // Global.msg("larger than PI");
                    // Global.msg("bigCircle");
                    newrd = bigCircle(rd1, rd2);
                }
            }

            rd1 = newrd[0], rd2 = newrd[1];

            // rd1 = 0;
            // rd2 = Math.PI / 2;

            //
            if (Global.debug) {
                Global.log("radian after");
                Global.log(rd1);
                Global.log(rd2);
                Global.log(Math.abs(rd1 - rd2));
                Global.log(VectorMath.radianToDegree(rd1));
                Global.log(VectorMath.radianToDegree(rd2));
                Global.log("---");
            }

            rd2 += Global.edgeFillGap;

            dataItems.push({
                "c": c,
                "r": r,
                "rd": [rd1, rd2],
                "rotation": rotation
            });
        }
    };

    this.render = function() {

        visualItems = [];

        //

        var material = new THREE.LineBasicMaterial({
            color: "gray",
            linewidth: Global.edgeWidth3D,
            transparent: true,
            opacity: 0.5
        });

        for (var i in dataItems) {
            var dataItem = dataItems[i],
                c = dataItem.c,
                r = dataItem.r,
                rd1 = dataItem.rd[0],
                rd2 = dataItem.rd[1],
                radian = dataItem.rotation[0],
                axis = dataItem.rotation[1];

            var geomotry = getArc2D(0, 0, r, rd1, rd2, true);
            var shape = new THREE.Line(geomotry, material);

            shape.position.x = c[0];
            shape.position.y = c[1];
            shape.position.z = c[2];
            shape.rotateOnAxis(new THREE.Vector3(axis[0], axis[1], axis[2]), radian);

            _scene.add(shape);
            visualItems.push(shape);
        }
    };

    function getArc2D(aX, aY, aRadius, aStartAngle, aEndAngle, aClockwise) {
        var arcShape = new THREE.Shape();
        arcShape.absarc(aX, aY, aRadius, aStartAngle, aEndAngle, aClockwise);
        var points = arcShape.createGeometry(arcShape.getPoints(Global.maxEdgeSegment, false));
        return points;
    }

    this.update = function() {

        this.layout();

        for (var i in dataItems) {
            var dataItem = dataItems[i],
                c = dataItem.c,
                r = dataItem.r,
                rd1 = dataItem.rd[0],
                rd2 = dataItem.rd[1],
                radian = dataItem.rotation[0],
                axis = dataItem.rotation[1];

            var visualItem = visualItems[i];

            visualItem.geometry.vertices = getArc2D(0, 0, r, rd1, rd2, true).vertices;
            visualItem.geometry.verticesNeedUpdate = true;

            // reset

            visualItem.rotation.x = 0;
            visualItem.rotation.y = 0;
            visualItem.rotation.z = 0;

            //

            visualItem.position.x = c[0];
            visualItem.position.y = c[1];
            visualItem.position.z = c[2];
            visualItem.rotateOnAxis(new THREE.Vector3(axis[0], axis[1], axis[2]), radian);
        }
    };

    //

    function sort(a, b) {
        if (a > b) return [b, a];
        else return [a, b];
    }

    // assume rd2 > rd1

    function smallCircle(rd1, rd2) {
        if (rd2 - rd1 > Math.PI)
            rd2 -= Math.PI * 2;
        return [rd1, rd2];
    }

    // assume rd2 > rd1

    function bigCircle(rd1, rd2) {
        if (rd2 - rd1 < Math.PI)
            rd1 += Math.PI * 2;

        return [rd1, rd2];
    }

    function getArcEdge(p1, p2) {
        var p0 = Global.infinite; // pole

        var nv = VectorMath.getNormalVector3D(p0, p1, p2);

        var circle = EuclideanMath.getCircle3D(p0, p1, p2, nv),
            center = circle[0],
            r = circle[1];

        if (Global.debug) {
            Global.log("-----")
            Global.log("getArcEdge")
            Global.log("p0");
            Global.log(p0);
            Global.log("p1");
            Global.log(p1);
            Global.log("p2");
            Global.log(p2);
            Global.log("nv");
            Global.log(nv);
            Global.log("circle");
            Global.log(circle);
            Global.log("-----");
        }

        return [r, center, nv];
    };
};

Geomotry.Sphere = function() {

    // private

    var sphereWireGeo = new THREE.SphereGeometry(Global.unit + 0.3, Global.sphereWireSegment, Global.sphereWireSegment);
    var sphereMeshGeo = new THREE.SphereGeometry(Global.unit, Global.sphereWireSegment, Global.sphereWireSegment);

    var sphereWireMaterial = new THREE.MeshBasicMaterial({
        // color: 0x777777,
        color: 0xDDDDDD,
        wireframe: true,
        transparent: true,
        opacity: 0.2
    });

    var sphereMeshMaterial = new THREE.MeshBasicMaterial({
        color: 0xFFFFFF,
        transparent: true,
        opacity: 0.5
    });

    var sphereWire = new THREE.Mesh(sphereWireGeo, sphereWireMaterial);
    var sphereMesh = new THREE.Mesh(sphereMeshGeo, sphereMeshMaterial);

    // public
    this.layout = function(scene) {
        if (Global.showWireSphere) scene.add(sphereWire);
        if (Global.showMeshSphere) scene.add(sphereMesh);
    };

    this.hide = function(scene) {
        sphereWire.material.opacity = 0.0;
    }

    this.rotate = function(speed) {
        if (speed == undefined) speed = 0.01;

        sphereWire.rotation.x += speed;
        sphereWire.rotation.y += speed;
    };

    this.translate = function(delta) {
        var dx = -1 * delta[1] * Global.translationFactor / ControlPanel.E2GFactor,
            dy = delta[0] * Global.translationFactor / ControlPanel.E2GFactor;

        sphereWire.rotation.x += dx;
        sphereWire.rotation.y += dy;
    };
};