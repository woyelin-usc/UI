var GraphSeer = function() {

    var _use_default_edge_color = true;
    var _use_default_node_color = false;
    var color = d3.scale.category10();
    var edge_color = d3.scale.category20b();
    var nsize = d3.scale.linear().range([3, 10]);
    var nthick = d3.scale.linear().range([.5, 4]);
    var lthick = d3.scale.linear().range([.5, 4]);
    var node_props;
    var edge_props;
    var prop_map;

    var groupFill = function(d, i) {
        return color(d.cid);
    };

    var configure = {};

    var rendererInstance;

    GraphSeer.prototype.bindClickNodeEvent = function(callback) {
        rendererInstance.bind('clickNode', function(e) {
            console.log(e.data.captor.isDragging);
            if (e.data.captor.isDragging) return;
            callback(e.data);
        });
    }

    GraphSeer.prototype.bindClickEdgeEvent = function(callback) {
        rendererInstance.bind('clickEdge', function(e) {
            console.log(e.data.captor.isDragging);
            // if (e.data.captor.isDragging) return;
            callback(e.data);
        });
    }

    GraphSeer.prototype.getInstance = function(){
        return rendererInstance;
    }

    GraphSeer.prototype.initialize = function() {
        rendererInstance = new sigma({
            renderers: [{
                container: document.getElementById('viscomp'),
                type: 'canvas' // sigma.renderers.canvas works as well
            }],
            settings: {
                defaultNodeColor: '#dddddd',
                drawEdges: true,
                drawNodes: true,
                defaultEdgeColor: "#eeeeee",
                borderSize: 1,
                minArrowSize: 10,
                labelColor: "node",
                labelSize: "fixed",
                labelThreshold: 6,
                maxNodeSize: 7,
                minNodeSize: 2,
                maxEdgeSize: 1,
                minEdgeSize: 0.1,
                labelAlignment: "bottom",
                edgeLabelSize: 'proportional',
                edgeLabelColor: 'edge',
                edgeColor: 'default',
                defaultEdgeLabelSize: 9,
                defaultLabelSize: 9,
                doubleClickEnabled: false,
                dragTimeout: 300,
                enableEdgeHovering: true,
                edgeHoverColor: 'edge',
                defaultEdgeHoverColor: '#ffeda0',
                edgeHoverSizeRatio: 1,
                edgeHoverExtremities: true,
                    // defaultNodeBorderWidth: 10
            }
        });

        var dragListener = sigma.plugins.dragNodes(rendererInstance, rendererInstance.renderers[0]);
    }

    GraphSeer.prototype.zoomToFit = function() {
        rendererInstance.camera.goTo({
            x: 0,
            y: 0,
            ratio: 1
        });
    }

    GraphSeer.prototype.zoomIn = function() {
        rendererInstance.camera.goTo({
            ratio: rendererInstance.camera.ratio / rendererInstance.camera.settings('zoomingRatio')
        });
    }

    GraphSeer.prototype.zoomOut = function() {
        rendererInstance.camera.goTo({
            ratio: rendererInstance.camera.ratio * rendererInstance.camera.settings('zoomingRatio')
        });
    }

    GraphSeer.prototype.clear = function() {
        rendererInstance.graph.clear();
        rendererInstance.refresh();
    }

    GraphSeer.prototype.refresh = function() {
        rendererInstance.refresh();
    }

    GraphSeer.prototype.graph = function(){
        return rendererInstance.graph;
    };

    GraphSeer.prototype.resetConfig = function() {
        configure = {
            "Node Default Color": {
                name: "defaultNodeColor",
                type: "color",
                valueType: "string",
                renderType: "global",
                value: "#dddddd"
            },
            "Edge Default Color": {
                name: "defaultEdgeColor",
                type: "color",
                valueType: "string",
                renderType: "global",
                value: "#eeeeee"
            },
            "Show Nodes": {
                name: "drawNodes",
                type: "boolean",
                valueType: "boolean",
                renderType: "global",
                value: true
            },
            "Node Color Mapping": {
                name: "color",
                type: "property",
                valueType: "string",
                renderType: "node",
                value: 'label'
            },
            "Node Size Mapping": {
                name: "size",
                type: "property",
                valueType: "string",
                renderType: "node",
                value: 'degree_in_display'
            },
            "Filter Node Label by Node Size": {
                name: "labelThreshold",
                type: "number",
                valueType: "number",
                renderType: "global",
                min: 1,
                max: 10,
                value: 6,
            },
            "Node Label Mapping": {
                name: "_label",
                type: "property",
                valueType: "string",
                renderType: "node",
                value: 'id'
            },
            "Node Label Size": {
                name: "defaultLabelSize",
                type: "number",
                valueType: "number",
                renderType: "global",
                min: 5,
                max: 15,
                value: 9,
            },
            "Show Edges": {
                name: "drawEdges",
                type: "boolean",
                valueType: "boolean",
                renderType: "global",
                value: true
            },
            "Edge Color Mapping": {
                name: "color",
                type: "property",
                valueType: "string",
                renderType: "edge",
                value: 'none'
            },
            "Edge Label Mapping": {
                name: "_label",
                type: "property",
                valueType: "string",
                renderType: "edge",
                value: 'none'
            },
            "Edge Label Size": {
                name: "defaultEdgeLabelSize",
                type: "number",
                valueType: "number",
                renderType: "global",
                min: 5,
                max: 15,
                value: 9,
            },
            "Edge Thickness Mapping": {
                name: "size",
                type: "property",
                valueType: "string",
                renderType: "edge",
                value: 'label'
            },
            "Edge Style": {
                name: "type",
                type: "category",
                valueType: "string",
                renderType: "edge",
                value: 'line',
                categories: {
                    'Line': 'line',
                    'Curve': 'curve',
                    'Line With Arrow': 'arrow',
                    'Curve With Arrow': 'curvedArrow'
                }
            }
        }

    };

    GraphSeer.prototype.updateDegree = function(){
        rendererInstance.graph.nodes().forEach(function(d){
            d.degree_in_display = rendererInstance.graph.degree(d.id);
            d.size = d.degree_in_display;
        });
    };
    GraphSeer.prototype.render = function(_is_new_graph, _graph, nodeProps, edgeProps, propMap, updateColorLegend) {
        rendererInstance.graph.clear();
        node_props = nodeProps;
        edge_props = edgeProps;
        prop_map = propMap;
        console.log(node_props);
        console.log(edge_props);
        console.log(prop_map);
        rendererInstance.graph.read(_graph);
        var number = _graph.nodes.length;
        var i_n = Math.min(300, Math.floor(8000 / Math.sqrt(number)));
        console.log("iteration:" + i_n);
        var frListener = sigma.layouts.fruchtermanReingold.configure(rendererInstance, {
            iterations: i_n,
            easing: 'quadraticInOut',
            duration: 800
        });
        // Start the Fruchterman-Reingold algorithm:
        frListener.bind('start', function(e) {
            $("#layout-msg").css('display', '');
        });

        frListener.bind('stop', function(e) {
            $("#layout-msg").css('display', 'none');
        });


        if (_is_new_graph) {
            this.resetConfig();
        }

        console.log(sigma.layouts.fruchtermanReingold.start(rendererInstance));

        if (!_is_new_graph) {
            for (var m in configure) {
                if (configure.hasOwnProperty(m)) {
                    if (configure[m].renderType == 'node') {
                        if (configure[m].type == "category") {
                            rendererInstance.graph.edges().forEach(function(d) {
                                d[configure[m].name] = configure[m].value;
                            })
                        } else if (configure[m].type == "property") {
                            if (configure[m].name == "color" && !_use_default_node_color && configure[m]['value'] != "none") {
                                rendererInstance.graph.nodes().forEach(function(d) {
                                    // console.log(d[configure[m]['value']]);
                                    d[configure[m].name] = color(d[configure[m]['value']]);
                                })
                                updateColorLegend(m, configure[m]['value'], configure[m].renderType, color);
                            } else {
                                rendererInstance.graph.nodes().forEach(function(d) {
                                    // if (configure[m].valueType == "string") {
                                        // d[configure[m].name] = d[configure[m]['value']] ? d[configure[m]['value']].toString() : d[configure[m]['value']];
                                    // } else {
                                        d[configure[m].name] = d[configure[m]['value']] ? d[configure[m]['value']] : 1;
                                    // }
                                })
                            }

                        }
                    } else if (configure[m].renderType == "edge") {
                        // console.log(configure[m]['value']);
                        if (configure[m].type == "category") {
                            rendererInstance.graph.edges().forEach(function(d) {
                                d[configure[m].name] = configure[m]['value'];
                            })
                        } else if (configure[m].type == "property") {
                            if (configure[m].name == "color" && !_use_default_edge_color && configure[m]['value'] != "none") {
                                rendererInstance.graph.edges().forEach(function(d) {
                                    d[configure[m].name] = edge_color(d[configure[m]['value']]);
                                })
                                updateColorLegend(m, configure[m]['value'], configure[m].renderType, edge_color);
                            } else if (configure[m]['value'] == "none") {
                                //Dont to anything..
                            } else
                            {
                                rendererInstance.graph.edges().forEach(function(d) {
                                    // if (configure[m].valueType == "string") {
                                    //     d[configure[m].name] = d[configure[m]['value']] ? d[configure[m]['value']].toString() : d[configure[m]['value']];
                                    // } else {
                                        d[configure[m].name] = d[configure[m]['value']] ? d[configure[m]['value']] : 1;
                                    // }
                                })
                            }
                        }
                    }
                }
            }
        } else {
            //handle initial color category
            console.log("set intital color for nodes");
            color.domain([]);
            rendererInstance.graph.nodes().forEach(function(d) {
                                    d[configure["Node Color Mapping"].name] = color(d[configure["Node Color Mapping"]['value']]);
                                });
            // var c = configure[m].renderType == "node" ? color : edge_color;
            updateColorLegend("Node Color Mapping", configure["Node Color Mapping"]['value'], configure["Node Color Mapping"].renderType, color);
        }
        rendererInstance.refresh();
        var l_nodes = rendererInstance.graph.nodes();
        _graph.nodes = l_nodes;

    };

    // function showProgress(){
    //     if (!sigma.layouts.fruchtermanReingold.isRunning(rendererInstance)){
    //         clearInterval(showProgress);
    //         $("#layout-msg").css('display', 'none');
    //     } else {
    //         $("#layout-msg").css('display', '');
    //         sigma.layouts.fruchtermanReingold.progress(rendererInstance);
    //         $("#layout-msg").html("Laying out the graph ("+ (progress*100) + "% completed)");
    //     }
    // }

    function runForceAtlas2() {
        console.log("start forceatlas2");
        rendererInstance.startForceAtlas2({
            worker: false,
            barnesHutOptimize: true
        });
        setTimeout(rendererInstance.stopForceAtlas2, 5000);
    }

    function runFruchtermanReingold() {
        var frListener = sigma.layouts.fruchtermanReingold.configure(rendererInstance, {
            iterations: 300,
            easing: 'quadraticInOut',
            duration: 800
        });
        // Start the Fruchterman-Reingold algorithm:
        sigma.layouts.fruchtermanReingold.start(rendererInstance);
    }

    GraphSeer.prototype.updateColor = function(type, property, m, color, index) {
        var items = (type == "node") ? rendererInstance.graph.nodes() : rendererInstance.graph.edges();
        items.forEach(function(d) {
            if (d[property] == index) {
                // console.log(d[configure[m].name]);
                d[configure[m].name] = "#" + color;
            }
        })
        rendererInstance.refresh();
    }

    GraphSeer.prototype.filterElement = function(type, property, value, isHidden){
        var items = (type == "node") ? rendererInstance.graph.nodes() : rendererInstance.graph.edges();
        items.forEach(function(d){
            if (d[property] == value){
                d.hidden = isHidden;
            }
        });
        rendererInstance.refresh();
    }
    GraphSeer.prototype.addControlPanelTo = function(_is_new_graph, dom, updateColorLegend, setting) {

        var gui = new dat.GUI({
            autoPlace: false,
            width: '100%'
        });

        gui.addColor(setting, 'background').name("Background Color").onChange(function(value) {
            $("#viscomp").css("background-color", value);
        });

        for (var n in configure) {
            if (configure.hasOwnProperty(n)) {
                if (configure[n].type == 'color') {
                    (function(m) {
                        gui.addColor(configure[m], 'value').name(m).onChange(function(value) {
                            // console.log(value);
                            if (m.indexOf("Node Default") >= 0) {
                                $("#node-legend").empty();
                                _use_default_node_color = true;
                                rendererInstance.graph.nodes().forEach(function(d) {
                                    d["color"] = value;
                                })
                            }
                            if (m.indexOf("Edge Default") >= 0) {
                                $("#edge-legend").empty();
                                _use_default_edge_color = true;
                                rendererInstance.graph.edges().forEach(function(d) {
                                    d["color"] = value;
                                })
                            }
                            rendererInstance.settings(configure[m].name, value);
                            rendererInstance.refresh();
                        })
                    })(n);
                } else if (configure[n].type == 'category') {
                    (function(m) {
                        gui.add(configure[m], 'value', configure[m].categories).name(m).onChange(function(value) {
                            // console.log(value);
                            if (configure[m].renderType == "edge") {
                                rendererInstance.graph.edges().forEach(function(d) {
                                    d[configure[m].name] = value;
                                })
                            } else if (configure[m].name == 'layout') {
                                // 'forceatlas2', 'fruchtermanReingold', 'forced'
                                console.log(value);
                                switch (value) {
                                    case "forceatlas2":
                                        runForceAtlas2();
                                        break;
                                    case "fruchtermanReingold":
                                        runFruchtermanReingold();
                                        break;
                                    case "fruchtermanReingold":
                                        break;
                                    default:
                                }
                            }
                            rendererInstance.refresh();
                        })
                    })(n);
                } else if (configure[n].type == 'property') {
                    (function(m) {
                        var props = [];
                        var items = configure[m].renderType == "node" ? rendererInstance.graph.nodes() : rendererInstance.graph.edges();
                        // console.log(items);
                        if (configure[m].renderType == "node") {
                            node_props.forEach(function(d) {
                                    // if (prop_map["node_" + d]['value'].charAt(0) == configure[m].valueType.charAt(0)) {
                                        props.push(d);
                                    // }
                                })
                                // props = props.concat(node_preserved);
                        } else {
                            edge_props.forEach(function(d) {
                                    // if (prop_map["link_" + d]['value'].charAt(0) == configure[m].valueType.charAt(0)) {
                                        props.push(d);
                                    // }
                                })
                                // props = props.concat(edge_preserved);
                        }
                        props.push("none");
                        props = props.sort();
                        gui.add(configure[m], 'value', props).name(m).onChange(function(value) {
                            if (configure[m].name == "color" && value != "none") {
                                // console.log("color");
                                if (configure[m].renderType == "node") {
                                    color.domain([]);
                                    _use_default_node_color = false;
                                    // console.log(items);
                                    items.forEach(function(d) {
                                        d[configure[m].name] = color(d[value]);
                                    })
                                } else {
                                    edge_color.domain([]);
                                    _use_default_edge_color = false;
                                    // console.log(items);s
                                    items.forEach(function(d) {
                                        d[configure[m].name] = edge_color(d[value]);
                                    })
                                }
                                var c = configure[m].renderType == "node" ? color : edge_color;
                                updateColorLegend(m, value, configure[m].renderType, c);
                            } else {
                                items.forEach(function(d) {
                                    // if (configure[m].valueType == "string") {
                                    //     d[configure[m].name] = d[value] ? d[value].toString() : d[value];
                                    // } else {
                                        d[configure[m].name] = d[value];
                                        // console.log(typeof d[value]);
                                    // }
                                })
                            }
                            if (value == "none") {
                                if (configure[m].renderType == "node" && configure[m].name == "size") {
                                    items.forEach(function(d) {
                                        d['size'] = 1;
                                    })

                                } else {
                                    items.forEach(function(d) {
                                        delete d[configure[m].name];
                                    })
                                }
                                if (configure[m].name == "color") {
                                    $("#" + configure[m].renderType + "-legend").empty();
                                }
                            }
                            rendererInstance.refresh();
                        })
                    })(n);
                } else {
                    (function(m) {
                        var c;
                        if (configure[m].valueType == "number") {
                            c = gui.add(configure[m], 'value', configure[m].min, configure[m].max).name(n);
                        } else {
                            c = gui.add(configure[m], 'value').name(n);
                        }
                        if (_is_new_graph) {
                            rendererInstance.settings(configure[m].name, configure[m].value);
                            rendererInstance.refresh();
                        }
                        c.onChange(function(value) {
                            // console.log(configure[n].name);

                            rendererInstance.settings(configure[m].name, value);

                            rendererInstance.refresh();
                        })
                    })(n);
                }
            }
        }

        var customContainer = document.getElementById(dom);
        $(customContainer).empty();
        customContainer.appendChild(gui.domElement);
    };


};
