/////////////////////////////////////
// graph visualization
// author: Conglei Shi
systemg = {};
var fontsize = 10.0;
systemg.graphvis = function(spiner) {
    var vgraph = {};
    // var _trans = [0, 0, 1];
    var _cur_node_id = "";
    var _graph = {};
    var __graph = {};
    var _is_new_graph = true;
    var _graph_id = "";
    var _is_directed = true;
    var color = d3.scale.category10();
    var edge_color = d3.scale.category20b();
    var node_props = [];
    var edge_props = [];
    var prop_map = {};
    var setting = {};
    setting.background = "#19193B";
    var node_preserved = ["id", "label", "degree_in_display"];
    var edge_preserved = ["eid", "label", "source", "target"];
    var _selected_renderer = "graphseer";
    var _renderer;
    var renderList = {
        "graphseer": GraphSeer,
        "crystalsphere": CrystalSphere
    };
    var progress_id = "";

    initializeRenderer(_selected_renderer);

    vgraph.setDirected = function(type) {

        // var categories = {
        //     'Line': 'line',
        //     'Curve': 'curve',
        //     'Line With Arrow': 'arrow',
        //     'Curve With Arrow': 'curvedArrow'
        // }
        // if (type == 'undirected') {
        //     categories = {
        //         'Line': 'line',
        //         'Curve': 'curve'
        //     }
        // }

        // configure["Edge Style"].categories = categories;
        _is_directed = type;
    }

    vgraph.renderer = function(name) {
        if (arguments.length == 0) {
            return _selected_renderer;
        }
        _selected_renderer = name;

        initializeRenderer(name);

        return vgraph;
    }

    vgraph.renderList = function() {
        return renderList;
    }


    vgraph.clear = function() {
        _renderer.clear();
    }


    function initializeRenderer(name) {
        $('#viscomp').empty();
        var fullScreenMode = false;

        _renderer = new renderList[name]();

        _renderer.initialize();

        _renderer.bindClickNodeEvent(displayNodeDetails);

        _renderer.bindClickEdgeEvent(displayEdgeDetails);


        $("#full-screen-btn").click(function(d) {
            if (!fullScreenMode) {
                var display = $("#display_panel").detach();
                $(".full-screen").show();
                $(".full-screen").append(display);
                $("#viscomp").height($(".full-screen").height() - 80);
                $("#full-screen-btn").text("window mode");
                $(".container").hide();
                fullScreenMode = true;
            } else {
                var display = $("#display_panel").detach();
                $(".full-screen").hide();
                $(".container").show();
                $("#window-panel").prepend(display);
                $("#viscomp").height(600);
                $("#full-screen-btn").text("full screen mode");
                fullScreenMode = false;
            }
            _renderer.refresh();
        });

        $("#fit-btn").click(function(d) {
            _renderer.zoomToFit();
        });

        $("#zoom-in-btn").click(function(d) {
            _renderer.zoomIn();

        });

        $("#zoom-out-btn").click(function(d) {
            _renderer.zoomOut();
        });

        $("#snapshot-btn").click(function(d) {
            download();
        });
    }

    function download() {
        var url = rendererInstance.renderers[0].snapshot({
            format: 'png',
            background: setting.background,
            filename: _graph_id + '.png',
            labels: true
        });
        window.open(url, "_blank");
    }

    var makeFullScreen = function(ele) {
        elem = document.getElementById(ele);
        if (elem.requestFullscreen) {
            elem.requestFullscreen();
        } else if (elem.msRequestFullscreen) {
            elem.msRequestFullscreen();
        } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullscreen) {
            elem.webkitRequestFullscreen();
        }
    };

    function updateColorLegend(m, property, type, c) {
        var ele = "#" + type + "-legend";
        $(ele).empty();
        $(ele).append("<span class='legend-front'>" + type + " color mapping: </span>");
        var div = d3.select(ele).append("div").attr("class", "legend-group");
        var r = 10;
        var height = 15;
        var offset = 15;
        var width = 100;
        var legend_group_width = $(ele).width() - $("#" + type + "-legend .legend-front").width() - 30;
        div.style("width", legend_group_width + "px");
        div.selectAll("legend-color")
            .data(c.domain())
            .enter()
            .append("div")
            .attr("class", "legend-item")
            .call(function(d) {
                d[0].forEach(function(ele) {
                    var g = d3.select(ele);
                    var colorB = g.append("div")
                        .attr("class", type == "node" ? "legend-color" : "legend-color-edge")
                        .style("background", function(d) {
                            return c(d);
                        })
                        .attr("value", function(d) {
                            return c(d);
                        });
                    $(colorB).colorpicker({
                        inline: false,
                        color: colorB.attr("value"),
                        ok: function(event, color) {
                            var that = this;
                            d3.select(that).style("background", "#" + color.formatted)
                            var range = c.range();
                            range[range.indexOf(c(that.__data__))] = "#" + color.formatted;
                            c.range(range);
                            //                 console.log(property);
                            _renderer.updateColor(type, property, m, color.formatted, that.__data__);
                        }
                    })

                    g.append("span")
                        .attr("class", "legend-text")
                        .text(function(d) {
                            if (typeof d === "undefined") {
                                return "undefined";
                            } else if (d == "") {
                                return "empty";
                            }
                            return d;
                        })
                        .on("click", function(d) {
                            // console.log(g);
                            // console.log(g.select("div"));
                            var isHidden = g.select("div").classed("hide-item");
                            _renderer.filterElement(type, property, d, !isHidden);
                            g.select("div").classed("hide-item", !isHidden);
                        });
                })
            });
        $(ele).append("<div class='clearfix'></div>");
    }

    function displayNodeDetails(data) {
        // console.log(data);
        $("#detail-title").html("Node Details: <strong>" + data.node.id + "</strong>");
        $("#detail-body").empty();
        node_props_all = node_props.concat(node_preserved);
        for (var i = 0; i < node_props_all.length; i++) {
            if (!data.node[node_props_all[i]]) continue;
            var html = "<tr>";
            var id = "n" + Math.round(Math.random() * 1000000);
            html += "<td>" + node_props_all[i] + "</td>";
            html += "<td><div style='float:left; width:150px' id='" + id + "'>" + data.node[node_props_all[i]] + "</div></td>";
            html += "</tr>";
            $("#detail-body").append(html);
            (function(m) {
                if (!(node_props_all[m].indexOf("analytic_") == 0) && (node_preserved.indexOf(node_props_all[m]) < 0)) {
                    $("#" + id).addClass("editable-text");
                    $($("#" + id).parent().get(0)).prepend("<span style='float:left' class='glyphicon glyphicon-pencil' aria-hidden='true'></span>");
                    $("#" + id).editable(function(value, settings) {
                        updateNodeValue(_graph_id, data.node.id, node_props_all[m], value, function(d) {
                            var old = _renderer.getInstance().graph.nodes(data.node.id);
                            if (typeof old[node_props_all[m]] === 'number') {
                                old[node_props_all[m]] = +value;
                            } else {
                                old[node_props_all[m]] = value;
                            }
                            _renderer.getInstance().refresh();
                        });
                        return (value);
                    }, {
                        submit: 'OK',
                    })
                }
            }(i));
        }

        var actionContent = '<button type="button" id="delete-node" class="btn btn-danger btn-sm" data-dismiss="modal">Delete Node</button><button type="button" id="query-ego" class="btn btn-primary btn-sm" data-dismiss="modal">Show Ego Network</button>'
        $("#detail-action").html(actionContent);
        $("#delete-node").click(function(d) {
            if (confirm("Are you sure you want to delete node [" + data.node.id + "]?")) {
                deleteNode(_graph_id, data.node.id, function() {
                    _renderer.getInstance().graph.dropNode(data.node.id);
                    // adjustDegreeInDisplay(data);
                    _renderer.updateDegree();
                    _renderer.getInstance().refresh();
                });
            }
        })
        $("#query-ego").click(function(d) {
            renderGraph(_graph_id, data.node.id);
        })
        $("#data-explorer").modal("show");
        $('.modal-backdrop').removeClass("modal-backdrop");
        // $("#data-explorer").draggable({
        //     handle: ".modal-header"
        // });
    }

    function displayEdgeDetails(data) {

        $("#detail-title").html("Edge Details: <strong>" + data.edge.id + "</strong>");
        $("#detail-body").empty();
        edge_props_all = edge_props.concat(edge_preserved);
        for (var i = 0; i < edge_props_all.length; i++) {
            if (!data.edge[edge_props_all[i]]) continue;
            var html = "<tr>";
            var id = "n" + Math.round(Math.random() * 1000000);
            html += "<td>" + edge_props_all[i] + "</td>";
            html += "<td><div style='float:left; width:150px' id='" + id + "'>" + data.edge[edge_props_all[i]] + "</div></td>";
            html += "</tr>";
            $("#detail-body").append(html);
            (function(m) {
                if (!(edge_props_all[m].indexOf("analytic_") == 0) && (edge_preserved.indexOf(edge_props_all[m]) < 0)) {
                    $("#" + id).addClass("editable-text");
                    $($("#" + id).parent().get(0)).prepend("<span style='float:left' class='glyphicon glyphicon-pencil' aria-hidden='true'></span>");
                    $("#" + id).editable(function(value, settings) {
                        updateEdgeValue(_graph_id, data.edge, edge_props_all[m], value, function(d) {
                            var old = _renderer.graph().edges(data.edge.id);
                            if (typeof old[edge_props_all[m]] === 'number') {
                                old[edge_props_all[m]] = +value;
                            } else {
                                old[edge_props_all[m]] = value;
                            }
                            _renderer.refresh();
                        });
                        return (value);
                    }, {
                        submit: 'OK',
                    })
                }
            }(i));
        }

         var actionContent = '<button type="button" id="delete-edge" class="btn btn-danger btn-sm" data-dismiss="modal">Delete Edge</button>';
            $("#detail-action").html(actionContent);
            $("#delete-edge").click(function(d) {
                if (confirm("Are you sure you want to delete edge [" + data.edge.id + "]?")) {
                    console.log(data.edge);
                    deleteEdge(_graph_id, data.edge, function() {
                        _renderer.getInstance().graph.dropEdge(data.edge.id);
                        _renderer.updateDegree();
                        _renderer.getInstance().refresh();
                        // adjustDegreeInDisplay(data.edge);
                    });
                }
            });

        $("#data-explorer").modal("show");
        $('.modal-backdrop').removeClass("modal-backdrop");
        // $("#data-explorer").draggable({
        //     handle: ".modal-header"
        // });
    }

    vgraph.refresh = function() {
        _renderer.refresh();
    }

    vgraph.showTimeLine = function(field) {
        // console.log(_renderer.graph());
        clearInterval(progress_id);
        $("#time-line").empty();
        var nodes = _renderer.graph().nodes();
        var formatTime = d3.time.format("%Y-%m-%d");
        // var parseTime = d3.time.parse("%Y-%m-%d");
        if (!nodes[0][field]) return;
        var timeExtend = d3.extent(nodes.map(function(d) {
            d["color"]="#dddddd";
            return formatTime.parse(d[field]);
        }))
        var width = $("#viscomp").width();
        var margin = {
            left: 20,
            right: 100
        };
        width = width - margin.right - margin.left;
        var x = d3.time.scale().domain(timeExtend).range([0, width]);

        var svg = d3.select("#time-line").append('svg').attr('width', (width + margin.left + 10) + "px").attr('height', "50px");
        var timeGroup = svg.append("g").attr("transform", "translate(" + margin.left + ",15)");

        var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom");

        timeGroup
            .attr("class", "x axis")
            .call(xAxis);

        var curDate = new Date(timeExtend[0].getTime());

        var point_drag = d3.behavior.drag()
            .on("drag", dragmove)
            .on("dragend", dragend);

        function dragmove(d) {
            var deltaX = d3.event.dx;
            var xAfterChange = x(d) + deltaX;
            xAfterChange = Math.min(xAfterChange, width);
            xAfterChange = Math.max(0, xAfterChange);
            d.setTime(x.invert(xAfterChange).getTime());
            d3.selectAll(".time-point")
               .attr("cx", function(dd) {
                    return x(dd);
                })
                // console.log(d);
        }

        function dragend(d) {
            _renderer.graph().nodes().forEach(function(d) {
                var timeValue = formatTime.parse(d[field]).getTime();
                if (curDate.getTime() > timeValue) {
                    d['color'] = "#FF0000";
                } else {
                    d['color'] = "#dddddd";
                }
            })
            _renderer.refresh();
        }

        timeGroup.selectAll("curTime").data([curDate]).enter()
            .append("circle")
            .attr("class", "time-point")
            .attr("cx", function(d) {
                return x(d);
            })
            .attr("cy", 0)
            .attr("r", 10)
            .attr("fill", "#3182bd")
            .call(point_drag);

        var button = $("#time-line").append("<button class='play-button'>Play</button>");

        var timeDiff = Math.abs(timeExtend[0].getTime() - timeExtend[1].getTime());
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

        $(".play-button").click(function(d) {
            var curStatus = $(".play-button").text();
            if (curStatus == "Play") {
                startPlaying();
                $(".play-button").text("Stop");
            } else {
                stopPlaying();
                $(".play-button").text("Play");
            }
        });


        function startPlaying() {
            var interval = Math.max(diffDays / 20, 1);
            progress_id = window.setInterval(function() {
                if (curDate == timeExtend[1]) {
                    window.clearInterval(progress_id);
                }
                var nextDate = new Date(curDate.getTime() + interval * 1000 * 3600 * 24);

                if (nextDate.getTime() > timeExtend[1].getTime()) {
                    nextDate = timeExtend[1];
                }

                curDate.setTime(nextDate.getTime());
                d3.selectAll(".time-point")
                    .transition()
                    .ease("linear")
                    .duration(1000)
                    .attr("cx", function(d) {

                        return x(d);
                    })
                _renderer.graph().nodes().forEach(function(d) {
                    var timeValue = formatTime.parse(d[field]).getTime();
                    if (curDate.getTime() > timeValue) {
                        if (d['color'] == "#FF0000") {
                            d['color'] = "#770000"
                        } else if (d['color'] != "#770000") {
                            d['color'] = "#FF0000"
                        }
                    }
                })
                _renderer.refresh();
            }, 1000)
        }

        function stopPlaying() {
            window.clearInterval(progress_id);
        }
    }

    vgraph.graph = function(x) {
        if (arguments.length == 0) {
            return __graph;
        } else {
            __graph.raw = x;
            __graph.nodes = {};
            __graph.edges = {};
            __graph.raw.nodes.forEach(function(d) {
                __graph.nodes[d.id] = d;
                d['degree_in_display'] = 0;
                d['size'] = 0;
            });
            __graph.edges = __graph.raw.edges;
            __graph.edges.forEach(function(d) {
                __graph.nodes[d.source]['degree_in_display'] += 1;
                __graph.nodes[d.target]['degree_in_display'] += 1;
                __graph.nodes[d.source]['size'] += 1;
                __graph.nodes[d.target]['size'] += 1;
            });
        }
        return __graph;

    }

    function adjustDegreeInDisplay(removed){

        __graph.raw.nodes.forEach(function(d) {
             d['degree_in_display'] = 0;
             d['size'] = 0;
        });
    }

    vgraph.addControlPanelTo = function(dom) {
        _renderer.addControlPanelTo(_is_new_graph, dom, updateColorLegend, setting);
    }

    vgraph.render = function() {
        _renderer.render(_is_new_graph, _graph, node_props.concat(node_preserved), edge_props.concat(edge_preserved), prop_map, updateColorLegend);
        this.addControlPanelTo("gui-controller");
    }

    vgraph.name = function() {
        return _graph_id;
    }

    vgraph.data = function(gid, x) {

        if (arguments.length == 0) {
            return _graph;
        }

        console.log(gid);

        if (gid != _graph_id) {
            _graph_id = gid;
            $("#node-legend").empty();
            $("#edge-legend").empty();
            _is_new_graph = true;
        } else {
            _is_new_graph = false;
        }

        _graph = x;

        if (!_graph.properties) {
            _graph.properties = [];
        }

        this.graph(_graph);

        // prop_map = _graph.properties.map(function(d){
        //     var prefix = d.type;
        //     return {}
        // })

        _graph.properties.forEach(function(d) {
            var prefix = d.type == "edge" ? "link" : d.type;
            prop_map[prefix + "_" + d.name] = d;
        });

        prop_map["node_degree_in_display"] = {
            type: "node",
            name: "degree_in_display",
            value: "number"
        }
        prop_map["node_id"] = {
            type: "node",
            name: "id",
            value: "string"
        };
        prop_map["node_label"] = {
            type: "node",
            name: "label",
            value: "string"
        };
        prop_map["link_label"] = {
            type: "link",
            name: "label",
            value: "string"
        };
        prop_map["link_eid"] = {
            type: "link",
            name: "eid",
            value: "string"
        };



        node_props = _graph.properties.filter(function(d) {
            return d.type == "node";
        }).map(function(d) {
            return d.name;
        });

        edge_props = _graph.properties.filter(function(d) {
            return d.type == "edge";
        }).map(function(d) {
            return d.name;
        });

        return vgraph;
    };

    return vgraph;

}
