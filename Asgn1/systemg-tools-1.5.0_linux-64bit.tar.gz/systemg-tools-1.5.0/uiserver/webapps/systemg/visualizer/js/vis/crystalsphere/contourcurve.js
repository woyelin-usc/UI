var Cell = function() {
    this.i = -1;
    this.j = -1;
    this.face = [ContourCurve.TERMINAL, ContourCurve.TERMINAL];
    this.visited;
};

var ContourCurve = function(grid, nx, ny) {
    this.TERMINAL = 0;

    this.LEFT = 1;
    this.RIGHT = 2;
    this.TOP = 3;
    this.BOTTOM = 4;
    this.ARRAYSIZE = 1000;
    this.MAXARRAYSIZE = 20000;
    this.grid = grid;
    this.nx = nx;
    this.ny = ny;
    this.curve = null;
    this.size = 0;
    this.value = 0.0;
    this.cells = null;

    //

    this.setValue = function(value) {
        this.value = value;
        if (this.grid == null) {
            return;
        }
        this.createCells();
    };

    this.createCells = function() {
        var bl, br, tl, tr;
        var bottom, top, right, left;
        var cell;
        var jcell, icell;
        var i, j, count;

        this.cells = [];

        for (j = 0; j < this.ny - 1; j++) {

            jcell = j * this.nx;

            for (i = 0; i < this.nx - 1; i++) {

                icell = i + jcell;

                bl = this.grid[icell];
                br = this.grid[icell + 1];
                tl = this.grid[icell + nx];
                tr = this.grid[icell + nx + 1];

                bottom = false;
                top = false;
                left = false;
                right = false;

                if ((bl - this.value) * (br - this.value) <= 0.0) {
                    bottom = true;
                }
                if ((br - this.value) * (tr - this.value) <= 0.0) {
                    right = true;
                }
                if ((tr - this.value) * (tl - this.value) <= 0.0) {
                    top = true;
                }
                if ((tl - this.value) * (bl - this.value) <= 0.0) {
                    left = true;
                }

                if (top && bottom && left && right) {
                    cell = new Cell();
                    cell.i = i;
                    cell.j = j;
                    cell.face[0] = this.TOP;
                    cell.face[1] = this.LEFT;
                    this.cells.push(cell);

                    cell = new Cell();
                    cell.i = i;
                    cell.j = j;
                    cell.face[0] = this.BOTTOM;
                    cell.face[1] = this.RIGHT;
                    this.cells.push(cell);
                } else if (top || bottom || left || right) {
                    cell = new Cell();
                    this.cells.push(cell);
                    cell.i = i;
                    cell.j = j;
                    if (bl == this.value && br == this.value) {
                        bottom = false;
                    }
                    if (bl == this.value && tl == this.value) {
                        left = false;
                    }
                    if (tr == this.value && tl == this.value) {
                        top = false;
                    }
                    if (tr == this.value && br == this.value) {
                        right = false;
                    }

                    count = 0;
                    if (bottom)
                        count++;
                    if (top)
                        count++;
                    if (left)
                        count++;
                    if (right)
                        count++;

                    if (count > 2) {} else {
                        count = 0;
                        if (bottom) {
                            cell.face[count] = this.BOTTOM;
                            count++;
                        }
                        if (top) {
                            cell.face[count] = this.TOP;
                            count++;
                        }
                        if (left) {
                            cell.face[count] = this.LEFT;
                            count++;
                        }
                        if (right) {
                            cell.face[count] = this.RIGHT;
                            count++;
                        }
                    }
                }
            }
        }
    };

    this.getCurve = function(xmin, xmax, ymin, ymax) {
        this.size = 0;
        this._getcurve();
        if (this.size == 0 || this.curve == null) {
            return null;
        }
        var tmp = new Array(this.size);
        var xscale = (xmax - xmin) / parseFloat(nx - 1);
        var yscale = (ymax - ymin) / parseFloat(ny - 1);
        for (var j = 0; j < this.size;) {
            tmp[j] = xmin + this.curve[j] * xscale;
            j++;
            tmp[j] = ymin + this.curve[j] * yscale;
            j++;
        }
        return tmp;
    };

    this._getcurve = function() {
        var current;
        var face = this.TERMINAL;
        var ifcell = -1;
        var jfcell = -1;
        var icell, jcell;
        var index;
        this.size = 0;

        if (this.cells == null || this.cells.length == 0)
            return;

        current = this.cells[0];
        if (current.face[0] == this.TERMINAL && current.face[1] == this.TERMINAL) {
            cells.shift();
            return;
        }

        icell = current.i;
        jcell = current.j;

        ifcell = -1;
        jfcell = -1;

        if (this.search(icell - 1, jcell) == null && (current.face[0] == this.LEFT || current.face[1] == this.LEFT)) {
            this.addDataPoint(this.LEFT, icell, jcell);
            face = this.LEFT;
        } else if (this.search(icell + 1, jcell) == null && (current.face[0] == this.RIGHT || current.face[1] == this.RIGHT)) {
            this.addDataPoint(this.RIGHT, icell, jcell);
            face = this.RIGHT;
        } else if (this.search(icell, jcell - nx) == null && (current.face[0] == this.BOTTOM || current.face[1] == this.BOTTOM)) {
            this.addDataPoint(this.BOTTOM, icell, jcell);
            face = this.BOTTOM;
        } else if (this.search(icell, jcell + nx) == null && (current.face[0] == this.TOP || current.face[1] == this.TOP)) {
            this.addDataPoint(this.TOP, icell, jcell);
            face = this.TOP;
        } else {
            index = 0;
            if (current.face[0] == this.TERMINAL) {
                index = 1;
            }
            this.addDataPoint(current.face[index], icell, jcell);
            face = current.face[index];

            if (face == this.TOP) {
                ifcell = current.i;
                jfcell = current.j + 1;
            } else if (face == this.BOTTOM) {
                ifcell = current.i;
                jfcell = current.j - 1;
            } else if (face == this.LEFT) {
                ifcell = current.i - 1;
                jfcell = current.j;
            } else if (face == this.RIGHT) {
                ifcell = current.i + 1;
                jfcell = current.j;
            }
        }

        while (current != null) {
            icell = current.i;
            jcell = current.j;
            if (current.face[0] == face) {
                face = current.face[1];
            } else {
                face = current.face[0];
            }

            if (face != this.TERMINAL) {
                this.addDataPoint(face, icell, jcell);
            }

            if (face == this.TOP) {
                jcell++;
                face = this.BOTTOM;
            } else if (face == this.BOTTOM) {
                jcell--;
                face = this.TOP;
            } else if (face == this.LEFT) {
                icell--;
                face = this.RIGHT;
            } else if (face == this.RIGHT) {
                icell++;
                face = this.LEFT;
            }

            this.cells.splice(this.cells.indexOf(current), 1);

            if (icell == ifcell && jcell == jfcell) {
                this.addDataPoint(curve[0], curve[1]);
                current = null;
            } else {
                current = this.search(icell, jcell);
            }
        }
    };

    this.getPoint = function(wall, icell, jcell) {
        var d = new Array(2);
        var bl, br, tl, tr;
        var index = icell + jcell * this.nx;

        if (wall == this.TOP) {
            tl = this.grid[index + this.nx];
            tr = this.grid[index + this.nx + 1];
            d[1] = parseFloat(jcell + 1);
            d[0] = parseFloat(icell) + (this.value - tl) / (tr - tl);
        } else if (wall == this.BOTTOM) {
            bl = this.grid[index];
            br = this.grid[index + 1];
            d[1] = parseFloat(jcell);
            d[0] = parseFloat(icell) + (this.value - bl) / (br - bl);
        } else if (wall == this.LEFT) {
            bl = this.grid[index];
            tl = this.grid[index + this.nx];
            d[1] = parseFloat(jcell) + (this.value - bl) / (tl - bl);
            d[0] = parseFloat(icell);
        } else if (wall == this.RIGHT) {
            br = this.grid[index + 1];
            tr = this.grid[index + 1 + this.nx];
            d[1] = parseFloat(jcell) + (this.value - br) / (tr - br);
            d[0] = parseFloat(icell + 1);
        }

        return d;
    };

    this.addDataPoint = function(wall, icell, jcell) {
        var d = [];

        d = this.getPoint(wall, icell, jcell);

        this._addDataPoint(d[0], d[1]);
    };

    this._addDataPoint = function(x, y) {

        if (this.curve == null) {
            this.curve = new Array(this.ARRAYSIZE);
        }

        this.curve[this.size] = x;
        this.size++;
        this.curve[this.size] = y;
        this.size++;
    };

    this.search = function(icell, jcell) {
        var i;
        var current = null;
        if (this.cells.length == 0) {
            return null;
        }
        for (i = 0; i < this.cells.length; i++) {
            current = this.cells[i];
            if (current.i == icell && current.j == jcell)
                return current;
        }
        return null;
    };
};