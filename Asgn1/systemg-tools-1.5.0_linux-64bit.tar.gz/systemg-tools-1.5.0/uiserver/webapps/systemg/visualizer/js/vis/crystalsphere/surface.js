Surface = function(graph, kde, scene, genres) {

    var _nodes = graph["nodes"],
        _edges = graph["links"],
        _kde = kde,
        _scene = scene,
        _genres = genres;

    var dataItems = [],
        sampleDataItems = [],
        visualItems = [];

    var translate = new THREE.Vector2(0.0, 0.0);

    // shader
    var sphereMeshGeo = new THREE.SphereGeometry(Global.unit, Global.sphereMeshSegment, Global.sphereMeshSegment);

    var attributes = {};
    var uniforms = {
        tex: {
            type: "t",
            value: null
        },
        unit: {
            type: "f",
            value: Global.unit
        },
        texWidth: {
            type: "f",
            value: 2.0
        }
    };
    var shaderMaterial = new THREE.ShaderMaterial({
        transparent: true,
        uniforms: uniforms,
        attributes: attributes,
        // side: THREE.DoubleSide,
        vertexShader: $('#heatmap-vertex-shader').text(),
        fragmentShader: $('#heatmap-fragment-shader').text()
    });

    var sphereMesh = new THREE.Mesh(sphereMeshGeo, shaderMaterial);

    // public
    var quadtree_rects;
    var ROI;
    var ROV;

    function updateDisplaysParams() {
        if (Global.debug_surface) console.log("##", ControlPanel.E2GFactor);

        if (ControlPanel.E2GFactor <= Global.E2GFactorThreshold1) {
            if (Global.debug_surface) console.log("**", 1);
            ControlPanel.showKDE = true;

            ControlPanel.showEdges = false;

            ControlPanel.nodeStroke = false;
            ControlPanel.showNodes = true;

        } else if (ControlPanel.E2GFactor > Global.E2GFactorThreshold1 && ControlPanel.E2GFactor <= Global.E2GFactorThreshold2) {
            if (Global.debug_surface) console.log("**", 2);
            ControlPanel.showKDE = false;

            ControlPanel.showEdges = false;

            ControlPanel.nodeStroke = true;
            ControlPanel.showNodes = true;

        } else if (ControlPanel.E2GFactor > Global.E2GFactorThreshold2) {
            if (Global.debug_surface) console.log("**", 3);
            ControlPanel.showKDE = false;

            ControlPanel.showEdges = true;

            ControlPanel.nodeStroke = true;
            ControlPanel.showNodes = true;

        } else {
            if (Global.debug_surface) console.log("**", "error");
        }
    }

    this.layout = function() {
        updateDisplaysParams();

        //
        dataItems = [];
        //
        for (var i in _nodes) {
            var node = _nodes[i];
            var x = node.x,
                y = node.y;
            dataItems.push([x, y, 1.0]);
        }

        // dataItems = getRandomSubarray(dataItems, dataItems.length / 1.1);
        // sampling(dataItems);

        ROI = [
            (-Global.ROIWidth / ControlPanel.E2GFactor - ControlPanel.translate[0]), //
            (-Global.ROIWidth / ControlPanel.E2GFactor - ControlPanel.translate[1]), //
            (Global.ROIWidth / ControlPanel.E2GFactor - ControlPanel.translate[0]), //
            (Global.ROIWidth / ControlPanel.E2GFactor - ControlPanel.translate[1]), //
            -ControlPanel.translate[0], //
            -ControlPanel.translate[1], //
            Global.ROIWidth / ControlPanel.E2GFactor
        ];

        ROV = [
            (-Global.ROVWidth / ControlPanel.E2GFactor - ControlPanel.translate[0]), //
            (-Global.ROVWidth / ControlPanel.E2GFactor - ControlPanel.translate[1]), //
            (Global.ROVWidth / ControlPanel.E2GFactor - ControlPanel.translate[0]), //
            (Global.ROVWidth / ControlPanel.E2GFactor - ControlPanel.translate[1]), //
            -ControlPanel.translate[0], //
            -ControlPanel.translate[1], //
            Global.ROVWidth / ControlPanel.E2GFactor
        ];

        if (ControlPanel.showKDE)
            sampleDataItems = sampling_quadtree(dataItems);
    };

    function generate_texture() {
        var kde = null;
        if (ControlPanel.showKDE)
            var kde = get_kde_js();

        var canvas = dataCanvas2D(kde);
        var texture = new THREE.Texture(canvas);
        texture.needsUpdate = true;
        texture.flipY = false;
        return texture;
    }

    this.render = function() {
        uniforms.tex.value = generate_texture();

        //
        if (!ControlPanel.showAs2DCanvas)
            _scene.add(sphereMesh);
    };

    this.update = function() {
        this.layout();
        uniforms.tex.value = generate_texture();
    };

    this.translate = function(dx, dy) {
        translate.x -= dy;
        translate.y -= dx;
    };

    var highlighted = -1;
    this.highlight = function(i) {
        highlighted = i;
    }

    this.unhighlight = function(i) {
        highlighted = -1;
    }

    function sampling(dataItems) {
        var view_width = 2.0;
        var view_width_half = view_width * 0.5;

        var bin_size = Global.kdeSamplingBlockSize;
        var bin_size2 = bin_size * bin_size;
        var bin_width = view_width / bin_size;
        var bin_width_half = bin_width * 0.5;

        var new_dataItems = {};
        for (var i = 0; i < dataItems.length; i++) {
            var item = dataItems[i];

            var ix = parseInt((item[0] + view_width_half) / bin_width),
                iy = parseInt((item[1] + view_width_half) / bin_width);

            var index = iy * bin_size + ix;
            if (new_dataItems[index] == undefined) {
                new_dataItems[index] = {
                    "p2d": [ix * bin_width + bin_width_half - view_width_half, iy * bin_width + bin_width_half - view_width_half],
                    "d": 0
                };
            }
            new_dataItems[index].d += item[2];
        }

        var new_dataItems_array = [];
        for (var i in new_dataItems) {
            new_dataItems_array.push(new_dataItems[i]);
        }
        if (Global.debug_surface) console.log(dataItems.length, new_dataItems_array.length);
        return new_dataItems_array;
    }

    function rect_not_in_ROI(roi, x1, y1, x2, y2) {
        var xmin = x1,
            ymin = y1,
            xmax = x2,
            ymax = y2;

        if (x1 > x2) {
            xmin = x2;
            xmax = x1;
        }
        if (y1 > y2) {
            ymin = y2;
            ymax = y1;
        }

        return roi[0] >= xmax || roi[1] >= ymax || roi[2] < xmin || roi[3] < ymin;
    }

    function point_not_in_circle(roi, x, y) {
        var x0 = roi[4],
            y0 = roi[5],
            r = roi[6];

        var d2 = (x - x0) * (x - x0) + (y - y0) * (y - y0);
        return d2 >= r * r;
    }

    function sampling_quadtree(dataItems) {
        var quadtree = d3.geom.quadtree()(dataItems);

        var statics = {};

        var thresholdResH = dataItems.length * Global.quadtreeResH / ControlPanel.E2GFactor;
        var thresholdResL = dataItems.length * Global.quadtreeResL;
        if (thresholdResH < 1) thresholdResH = 1;


        // console.log(ROV);

        var rects = [];
        quadtree.visit(function(node, x1, y1, x2, y2) {
            // console.log("visit", x1, y1, x2, y2);
            var threshold, isFocus;
            if (rect_not_in_ROI(ROI, x1, y1, x2, y2)) {
                // no overlapping
                threshold = thresholdResL;
                isFocus = false;
            } else {
                threshold = thresholdResH;
                isFocus = true;
            }
            var leaf = leaf_info(node);
            if (leaf[0] <= threshold) {
                // console.log("#", threshold, leaf[0]);
                rects.push({
                    x: x1,
                    y: y1,
                    width: x2 - x1,
                    height: y2 - y1,
                    center: [leaf[1], leaf[2]],
                    count: leaf[0],
                    focus: isFocus
                });
                return true;
            }
        });

        quadtree_rects = rects;
        if (Global.debug_surface) console.log("thresholdResH", thresholdResH, "thresholdResL", thresholdResL, "quadtree_rects", quadtree_rects.length);

        //

        var new_dataItems = [];
        for (var i = 0; i < rects.length; i++) {
            var item = rects[i];

            new_dataItems.push({
                "p2d": item.center,
                "d": Math.sqrt(item.count)
            });
        }

        // console.log(dataItems.length, new_dataItems.length);
        return new_dataItems;
    }

    function draw_quadtree(context) {
        var canvas_width = ControlPanel.E2GFactor * Global.textureWidth;
        var magnifyfactor = ControlPanel.E2GFactor * Global.textureWidth;
        var offset1 = (canvas_width - Global.textureWidth) * -0.5;
        var t_rects = [];
        for (var i = 0; i < quadtree_rects.length; i++) {
            var r = quadtree_rects[i];
            var t_r = {};
            t_r.x = (r.x + 1.0 + ControlPanel.translate[0]) * 0.5 * magnifyfactor;
            t_r.y = (r.y + 1.0 + ControlPanel.translate[1]) * 0.5 * magnifyfactor;
            t_r.width = r.width * 0.5 * magnifyfactor;
            t_r.height = r.height * 0.5 * magnifyfactor;
            t_r.cx = (r.center[0] + 1.0 + ControlPanel.translate[0]) * 0.5 * magnifyfactor;
            t_r.cy = (r.center[1] + 1.0 + ControlPanel.translate[1]) * 0.5 * magnifyfactor;
            t_r.focus = r.focus;
            t_rects.push(t_r);
        }
        // console.log(t_rects);

        context.setTransform(1, 0, 0, 1, 0, 0);
        context.translate(offset1, offset1);
        context.lineWidth = 2;

        context.strokeStyle = 'rgba(0, 0, 0, 1.0)';
        context.beginPath();
        for (var i = 0; i < t_rects.length; i++) {
            var r = t_rects[i];
            if (!r.focus) context.rect(r.x, r.y, r.width, r.height);
        }
        context.stroke();

        context.strokeStyle = 'rgba(0, 255, 0, 1.0)';
        context.beginPath();
        for (var i = 0; i < t_rects.length; i++) {
            var r = t_rects[i];
            if (r.focus) context.rect(r.x, r.y, r.width, r.height);
        }
        context.stroke();

        //

        context.setTransform(1, 0, 0, 1, 0, 0);
        var t_ROI = [
            ((ROI[0] + ControlPanel.translate[0]) * ControlPanel.E2GFactor + 1.0) * 0.5 * Global.textureWidth, //
            ((ROI[1] + ControlPanel.translate[1]) * ControlPanel.E2GFactor + 1.0) * 0.5 * Global.textureWidth, //
            ((ROI[2] + ControlPanel.translate[0]) * ControlPanel.E2GFactor + 1.0) * 0.5 * Global.textureWidth, //
            ((ROI[3] + ControlPanel.translate[1]) * ControlPanel.E2GFactor + 1.0) * 0.5 * Global.textureWidth //
        ];

        // context.beginPath();
        // context.strokeStyle = 'rgba(0, 0, 255, 1.0)';
        // context.rect(t_ROI[0], t_ROI[1], t_ROI[2] - t_ROI[0], t_ROI[3] - t_ROI[1]);
        // context.stroke();

        context.beginPath();
        context.setLineDash([5]);
        context.strokeStyle = 'rgba(255, 0, 0, 1.0)';
        context.arc((t_ROI[0] + t_ROI[2]) * 0.5, (t_ROI[1] + t_ROI[3]) * 0.5, (t_ROI[2] - t_ROI[0]) * 0.5, 0, 2 * Math.PI);
        context.stroke();
    }

    function leaf_info(node) {
        var queue = [node];
        var count = 0,
            X = 0.0,
            Y = 0.0;
        while (queue.length > 0) {
            var cur = queue.shift();
            if (cur.leaf) {
                count += 1;
                X += cur.point[0];
                Y += cur.point[1];
            } else {
                for (var i in cur.nodes) {
                    queue.push(cur.nodes[i]);
                }
            }
        }
        return [count, X / count, Y / count];
    }

    function get_kde_js() {
        // console.log("kde start");
        var kde = {};
        kde.colors = Global.kdeColors;
        kde.size = Global.kdeRenderBlockSize;
        kde.width = 2.0 * Global.kdeTextureWidth / Global.textureWidth;
        kde.size2 = kde.size * kde.size;

        //
        kde.densities = [];
        var kde_obj = new KDE(sampleDataItems);
        //TODO optimize bandwidth here

        //
        kde_obj.set_bandwidth(ControlPanel.KDEBandwidth);

        var bin_width = kde.width / kde.size;
        var bin_width_half = bin_width * 0.5;
        var width_half = kde.width * 0.5;

        for (var i = 0; i < kde.size; i++) {
            for (var j = 0; j < kde.size; j++) {
                var x = j * bin_width + bin_width_half - width_half;
                var y = i * bin_width + bin_width_half - width_half;
                kde.densities.push(kde_obj.get(x, y));
            }
        }

        kde.contours = get_contours(Global.contourNLevels, kde.densities, kde.size);

        // console.log(kde.contours);

        //
        return kde;
    }

    function get_contours(nlevels, data, size) {
        var contourCloud = new ContourCloud();
        contourCloud.setGrid(data, size, size);
        contourCloud.setNLevels(nlevels);
        var contour_size = {
            "x": 0,
            "y": 0,
            "width": Global.kdeTextureWidth,
            "height": Global.kdeTextureWidth
        };
        contourCloud.createContourMap(contour_size);

        var contours = [];
        for (var i = 0; i < nlevels; i++) {
            var subcontours = contourCloud.getContourMap(i);
            for (var ii = 0; ii < subcontours.length; ii++) {
                var contour = subcontours[ii];
                for (var j = 0; j < contour.length; j++) {
                    contour[j][1] = Global.kdeTextureWidth - contour[j][1];
                }
            }
            contours.push(subcontours);
        }

        return contours;
    }

    function dataCanvas2D(kde) {
        var statics = {};
        statics.translate_contour = [ControlPanel.translate[0] * 0.5 * Global.textureWidth, ControlPanel.translate[1] * 0.5 * Global.textureWidth];
        statics.magnifyfactor_contour = ControlPanel.E2GFactor;
        statics.magnifyfactor_node = 0.5 * ControlPanel.E2GFactor * Global.textureWidth;

        // console.log(contours);

        var canvas = document.getElementById("tmpcanvas");
        var canvas_width = ControlPanel.E2GFactor * Global.textureWidth;
        canvas.width = Global.textureWidth;
        canvas.height = Global.textureWidth;

        if (ControlPanel.showAs2DCanvas)
            canvas.style.display = "inline";
        var context = canvas.getContext("2d");

        //
        context.fillStyle = 'rgba(0, 0, 0, 0.0)';
        context.fillRect(0, 0, canvas.width, canvas.height);
        //
        var offset1 = (canvas_width - Global.textureWidth) * -0.5;
        //

        if (ControlPanel.showKDE && !ControlPanel.forceHideKDE) {

            var contours = kde.contours;
            var colors = kde.colors;

            var offset2 = (canvas_width - Global.kdeTextureWidth * ControlPanel.E2GFactor) * 0.5;
            context.setTransform(1, 0, 0, 1, 0, 0);
            context.translate(offset1 + offset2, offset1 + offset2);

            context.strokeStyle = 'rgba(255, 255, 255, 1)';
            for (var i = 0; i < contours.length; i++) {

                var subcontours = contours[i];
                context.beginPath();
                for (var ii = 0; ii < subcontours.length; ii++) {

                    var contour = subcontours[ii];
                    var t_contour = [];
                    for (var j = 0; j < contour.length; j++) {
                        t_contour[j] = [
                            (contour[j][0] + statics.translate_contour[0]) * statics.magnifyfactor_contour, (contour[j][1] + statics.translate_contour[1]) * statics.magnifyfactor_contour
                        ];
                    }
                    context.moveTo(t_contour[0][0], t_contour[0][1]);
                    //
                    if (ii % 2 == 0) {
                        for (var j = 1; j < t_contour.length; j++) {
                            context.lineTo(t_contour[j][0], t_contour[j][1]);
                        }
                    } else {
                        for (var j = t_contour.length - 1; j >= 1; j--) {
                            context.lineTo(t_contour[j][0], t_contour[j][1]);
                        }
                    }
                    context.closePath();
                }
                context.fillStyle = Global.contourColor;
                // context.fillStyle = colors[i];
                context.fill();
                // context.stroke();
            }
        }

        //
        if (ControlPanel.showEdges || ControlPanel.showNodes || ControlPanel.forceShowEdges) {
            var t_nodes = {};
            for (var i in _nodes) {
                var node = _nodes[i];
                if (point_not_in_circle(ROV, node.x, node.y))
                    continue;

                var t_x = (node.x + ControlPanel.translate[0] + 1.0) * statics.magnifyfactor_node,
                    t_y = (node.y + ControlPanel.translate[1] + 1.0) * statics.magnifyfactor_node,
                    index = node.i;
                t_nodes[i] = [t_x, t_y, index];
            }

            context.setTransform(1, 0, 0, 1, 0, 0);
            context.translate(offset1, offset1);
        }

        if (ControlPanel.showEdges || ControlPanel.forceShowEdges) {
            context.lineWidth = 1;
            context.strokeStyle = Global.edgeColor;
            for (var i in _edges) {
                var edge = _edges[i],
                    source = edge.source,
                    target = edge.target;

                // if (edge.value < 2) continue;
                // var light = 255 * edge.value / Global.edgeMaxWeight;
                // if (light > 255) light = 255;
                // context.strokeStyle = 'rgba(' + light + ', ' + light + ', ' + light + ', ' + (light / 255) + ')';
                var node1 = _nodes[source],
                    node2 = _nodes[target],
                    t_node1 = t_nodes[source],
                    t_node2 = t_nodes[target];

                if (t_node1 == undefined || t_node2 == undefined) {
                    // Global.warning("Node pair not found, skipped : " + i, "Geomotry.Edges.layout");
                    continue;
                }

                // if (point_not_in_circle(ROI, node1.x, node1.y) || point_not_in_circle(ROI, node2.x, node2.y))
                // continue;

                var x1 = t_node1[0],
                    x2 = t_node2[0],
                    y1 = t_node1[1],
                    y2 = t_node2[1];

                context.beginPath();
                context.moveTo(x1, y1);
                context.lineTo(x2, y2);
                context.stroke();
            }
        }
        //

        if (ControlPanel.showNodes && !ControlPanel.forceHideNodes) {
            var alpha = Global.nodeAlpha[1] * ControlPanel.E2GFactor;
            if (alpha < Global.nodeAlpha[0]) alpha = Global.nodeAlpha[0];
            if (alpha > Global.nodeAlpha[2]) alpha = Global.nodeAlpha[2];

            var size = Global.nodeSize[0] * ControlPanel.E2GFactor;
            size = Math.min(Global.nodeSize[1], size);

            context.lineWidth = 1.0;
            context.strokeStyle = 'rgba(0, 0, 0, 0.1)';

            var defaultFillStyle = Global.nodeColor + alpha + ")";
            var darkFillStyle = 'rgba(255, 255, 255,' + alpha + ")";
            context.fillStyle = defaultFillStyle;
            // if (ControlPanel.forceHideKDE) context.fillStyle = 'steelblue';

            for (var i in t_nodes) {
                var node = t_nodes[i];
                var x = node[0],
                    y = node[1],
                    index = node[2];

                if (index == highlighted) {
                    var tmp = context.fillStyle;
                    context.fillStyle = Global.nodeColorHighlight;
                }
                // } else if (ControlPanel.showNodeColorBy == "decade") {
                //     var decade = parseInt(_nodes[i].year / 10) * 10;
                //     context.fillStyle = 'rgba(' + Global.year_color_map[decade] + ',' + alpha + ')';
                // } else if (ControlPanel.showNodeColorBy == "genre") {
                //     var genre = _nodes[i].genre,
                //         cat = 0,
                //         count = 0;
                //     for (var i = 0; i < genre.length; i++) {
                //         if (genre[i]) {
                //             cat = i;
                //             count++;
                //             if (count > 1) break;
                //         }
                //     }
                //     if (count == 1) context.fillStyle = Global.category20(cat);
                //     else context.fillStyle = darkFillStyle;
                // }

                strokeCircle(context, x, y, size);
                if (index == highlighted) context.fillStyle = tmp;

                if (ControlPanel.nodeStroke) context.stroke();
            }
        }
        //
        if (ControlPanel.showQuadtree) draw_quadtree(context);


        return canvas;
    }



    function draw_legend(div, map, total_width) {
        var width = total_width / Object.keys(map).length,
            height = 25,
            rect_height = 10;

        var svg = d3.select(div[0]).append("svg")
            .attr("width", total_width)
            .attr("height", height);

        svg.selectAll("text")
            .data(Object.keys(map))
            .enter().append("text")
            .style("font-size", function(d) {
                return "10px";
            })
            .style("fill", function(d, i) {
                return "gray";
            })
            .attr("text-anchor", "middle")
            .attr("x", function(d, i) {
                return i * width + width / 2;
            })
            .attr("y", function() {
                return rect_height + 13;
            })
            .text(function(d) {
                return d;
            });

        svg.selectAll("rect")
            .data(Object.keys(map))
            .enter().append("rect")
            .style("fill", function(d) {
                return 'rgb(' + map[d] + ')';
            })
            .attr("width", function() {
                return width;
            })
            .attr("height", function() {
                return rect_height;
            })
            .attr("x", function(d, i) {
                return i * width;
            })
            .attr("y", function() {
                return 0;
            })
            .text(function(d) {
                return d;
            });
    }

    function log2(x) {
        return Math.log(x) / Math.LN2;
    }

    function strokeCircle(context, x, y, size) {
        context.beginPath();
        context.arc(x, y, size, 0, 2 * Math.PI, true);
        context.fill();
    }

    // private
};
