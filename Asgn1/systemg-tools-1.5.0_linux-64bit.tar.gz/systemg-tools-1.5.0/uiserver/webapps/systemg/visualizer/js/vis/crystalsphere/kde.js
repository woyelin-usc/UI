var KDE = function(data) {
    //bandwidth: the smaller, the sharper [x, y]

    var bandwidth = [0.01, 0.01];

    var n = data.length,
        bw0bw1 = bandwidth[0] * bandwidth[1];

    var sum_weight = 0.0;
    for (var i = 0; i < n; i++) {
        sum_weight += data[i].d;
    }

    //

    function gaussian(u) {
        return 1.0 / Math.sqrt(2.0 * Math.PI) * Math.exp(-0.5 * u * u);
    }

    function kernel(u1, u2) {
        return gaussian(u1) * gaussian(u2);
    }

    this.set_bandwidth = function(band) {
        bandwidth = [band, band];
        bw0bw1 = bandwidth[0] * bandwidth[1];
    }

    this.get = function(x, y) {
        var sum_value = 0.0;

        for (var i = 0; i < n; i++) {
            var xi = data[i].p2d[0],
                yi = data[i].p2d[1],
                weight = data[i].d;

            sum_value += weight * kernel((x - xi) / bandwidth[0], (y - yi) / bandwidth[1]);
        }
        return sum_value / bw0bw1 / sum_weight;
    }
}