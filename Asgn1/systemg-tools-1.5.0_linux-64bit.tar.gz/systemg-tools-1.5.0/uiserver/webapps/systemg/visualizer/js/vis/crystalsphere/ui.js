// $(document).ready(function() {
//     $("#iframes-container").height($(window).height());
// });

// $('#display button').click(function() {
//     var rel = $(this).attr("rel");
//     var forceHide = null,
//         forceShow = null;

//     if ($(this).hasClass("active")) {
//         $(this).removeClass("active");
//         forceHide = true;

//     } else {
//         $(this).addClass("active");
//         forceHide = false;
//     }
//     forceShow = !forceHide;

//     if (window.frames['riemann'].rView != undefined) {
//         if (rel == 'kde') {
//             window.frames['riemann'].ControlPanel.forceHideKDE = forceHide
//         } else if (rel == 'node') {
//             window.frames['riemann'].ControlPanel.forceHideNodes = forceHide;
//         } else if (rel == 'quadtree') {
//             window.frames['riemann'].ControlPanel.showQuadtree = forceShow;
//         } else if (rel == 'edge') {
//             window.frames['riemann'].ControlPanel.forceShowEdges = forceShow;
//         } else if (rel == 'wordle') {
//             window.frames['riemann'].ControlPanel.showWordle = forceShow;
//             if (forceShow) window.frames['riemann'].ControlPanel.forceWordleUpdate = true;
//         }
//         // else if (rel == '2d') {
//         //     window.frames['riemann'].ControlPanel.showAs2DCanvas = forceShow;
//         //     if (forceShow) {
//         //         window.frames['riemann'].Global.textureWidth = 500;
//         //     } else {
//         //         window.frames['riemann'].Global.kdeTextureWidth = window.frames['riemann'].Global.textureWidth * 1.5;
//         //     }
//         // }
//         window.frames['riemann'].rView.needsUpdate(false, true);
//     }
// });

// $('#colorby button').click(function() {

//     $("#colorby button").removeClass("active");
//     $(this).addClass("active");

//     var rel = $(this).attr("rel");

//     if (window.frames['riemann'].rView != undefined) {
//         window.frames['riemann'].ControlPanel.showNodeColorBy = rel;
//         window.frames['riemann'].ControlPanel.forceWordleUpdate = true;
//         window.frames['riemann'].rView.needsUpdate(false, true);
//     }
// });

// //

// var bandwidth_slider = document.querySelector("#bandwidth-slider");
// if (bandwidth_slider != null) {
//     var initVals = new Powerange(bandwidth_slider, {
//         min: 1,
//         max: 200,
//         start: 110,
//         decimal: true,
//         step: 1,
//         callback: updateBandwidthSlider
//     });

//     function updateBandwidthSlider() {
//         var val = bandwidth_slider.value;
//         var fval = parseFloat(val) / 1000;
//         $("#bandwidth-slider-wrapper .range-min").text(fval);

//         if (window.frames['riemann'].rView != undefined) {
//             window.frames['riemann'].ControlPanel.KDEBandwidth = fval;
//             window.frames['riemann'].rView.needsUpdate(false, true);
//         }
//     }
// }
