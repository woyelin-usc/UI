// Mouse namespace
var Mouse = {};

//renderer.domElement
Mouse.Drag = function(domElement, object) {

    var dom = domElement;
    var state = false;
    var start, end, delta;

    dom.addEventListener('mousedown', onMouseDown, false);

    function onMouseDown(event) {
        // console.log("onMouseDown");
        // Touchpad
        // 0: three or left
        // 2: right
        // Mouse
        // 0: left
        // 1: middle
        // 2: right
        if (event.button === 0) {
            ControlPanel.mouseStatus = 1;
            state = true;
            start = [event.clientX, event.clientY];
        }
        dom.addEventListener('mousemove', onMouseMove, false);
        dom.addEventListener('mouseup', onMouseUp, false);
    }

    function onMouseMove(event) {
        // console.log("onMouseMove");
        if (state) {
            ControlPanel.mouseStatus = 2;
            end = [event.clientX, event.clientY];
            delta = [end[0] - start[0], -end[1] + start[1]];
            start = end;

            //
            object.translate(delta);
            object.needsUpdate(true, true);
        }
    }

    function onMouseUp(event) {
        // console.log("onMouseUp");
        ControlPanel.mouseStatus = 0;
        dom.removeEventListener('mousemove', onMouseMove, false);
        dom.removeEventListener('mouseup', onMouseUp, false);
        state = false;
        object.needsUpdate(true, true);
    }
};

//renderer.domElement
Mouse.Wheel = function(domElement, object) {

    var dom = domElement;
    var state = false;
    var start, end, delta;
    // var delta_sum = 0.0;

    dom.addEventListener('mousewheel', onMouseWheel, false);
    dom.addEventListener('DOMMouseScroll', onMouseWheel, false);

    function onMouseWheel(event) {
        event.preventDefault();
        var delta = 0;
        if (event.wheelDelta !== undefined) { // WebKit / Opera / Explorer 9
            delta = event.wheelDelta;
        } else if (event.detail !== undefined) { // Firefox
            delta = -event.detail;
        }
        delta /= 200;
        var factor = ControlPanel.E2GFactor + delta;
        if (factor < Global.E2GFactorMin) factor = Global.E2GFactorMin;
        ControlPanel.E2GFactor = factor;

        //
        // delta_sum += Math.abs(delta);
        // if (delta_sum > 0.2) {
        //     delta_sum = 0.0;
        //     ControlPanel.mouseStatus = 0;

        // } else {
        //     ControlPanel.mouseStatus = 3;
        // }
        ControlPanel.mouseStatus = 3;
        object.needsUpdate(true, true);
    }
};

//