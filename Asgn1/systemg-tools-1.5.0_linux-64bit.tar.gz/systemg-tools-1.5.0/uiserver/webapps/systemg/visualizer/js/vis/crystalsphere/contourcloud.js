var ContourCloud = function() {

    this.NLEVELS = 12;
    this.nx = 0;
    this.ny = 0;
    this.curves = null;
    this.autoLevels = true;
    this.levels = new Array(this.NLEVELS);
    this.grid = null;
    this.xmin = 0.0;
    this.xmax = 0.0;
    this.ymin = 0.0;
    this.ymax = 0.0;
    this.zmin = 0.0;
    this.zmax = 0.0;

    this.init = function() {
        this.setRange(0, 2, 0, 2);
        this.setNLevels(5);
    }

    this.setRange = function(xmin, xmax, ymin, ymax) {
        if (xmin >= xmax || ymin >= ymax)
            return;
        this.xmin = xmin;
        this.xmax = xmax;
        this.ymin = ymin;
        this.ymax = ymax;
    }

    this.getRange = function() {
        return [this.xmin, this.xmax, this.ymin, this.ymax];
    }

    this.setLevels = function(levels) {
        if (levels == null || levels.length <= 0) {
            return;
        }
        this.curves = null;
        this.autoLevels = false;
        this.levels = levels;
    }

    this.setGrid = function(grid, nx, ny) {
        this.grid = grid;
        this.nx = nx;
        this.ny = ny;
        this.zrange();
        this.calcLevels();
    }

    this.getLevels = function() {
        return this.levels;
    }

    this.setNLevels = function(l) {
        if (l <= 0) {
            return;
        }
        this.levels = new Array(l);
        this.calcLevels();
        this.curves = null;
    }

    this.setAutoLevels = function(b) {
        this.autoLevels = b;
    }

    this.calcLevels = function() {
        var i;

        if (!this.autoLevels)
            return;

        if (this.levels == null) {
            this.levels = new Array(this.NLEVELS);
        }
        var inc = (this.zmax - this.zmin) / parseFloat(this.levels.length + 1);
        for (i = 0; i < this.levels.length; i++) {
            this.levels[i] = this.zmin + parseFloat(i + 1) * inc;
        }
    }

    this.zrange = function() {
        var i;

        this.zmin = this.grid[0];
        this.zmax = this.grid[0];
        for (i = 0; i < this.grid.length; i++) {
            this.zmin = Math.min(this.zmin, this.grid[i]);
            this.zmax = Math.max(this.zmax, this.grid[i]);
        }

        if (this.zmin == this.zmax) {
            console.log("Cannot produce contours of a constant surface!");
        }
    }

    this.getContourMap = function(level) {
        if (level >= this.levels.length) {
            return null;
        }
        return this.curves[level];
    }

    this.createContourMap = function(bounds) {
        this.curves = new Array(this.levels.length);
        var curve = null;
        var isocurve = new ContourCurve(this.grid, this.nx, this.ny);

        for (var i = 0; i < this.levels.length; i++) {
            isocurve.setValue(this.levels[i]);
            this.curves[i] = [];
            while ((curve = isocurve.getCurve(this.xmin, this.xmax, this.ymin, this.ymax)) != null) {
                var path = this.generate(curve, bounds);
                if (path == null)
                    continue;
                this.curves[i].push(path);
            }
        }
    }

    this.generate = function(path, w) {
        var i;
        var stride = 2;
        var inside0 = false;
        var inside1 = false;
        var x0 = 0,
            y0 = 0;
        var x1 = 0,
            y1 = 0;
        var clip = w;
        var xcmin = clip.x;
        var xcmax = clip.x + clip.width;
        var ycmin = clip.y;
        var ycmax = clip.y + clip.height;

        var g = [];

        if (path == null || path.length < stride)
            return null;

        var xrange = this.xmax - this.xmin;
        var yrange = this.ymax - this.ymin;

        if ((inside0 = this.inside(path[0], path[1]))) {
            x0 = parseInt(w.x + ((path[0] - this.xmin) / xrange) * w.width);
            y0 = parseInt(w.y + (1.0 - (path[1] - this.ymin) / yrange) * w.height);
            if (x0 < xcmin || x0 > xcmax || y0 < ycmin || y0 > ycmax) {
                inside0 = false;
            }
        }

        for (i = stride; i < path.length; i += stride) {
            inside1 = this.inside(path[i], path[i + 1]);
            if (inside1 || inside0) {
                x1 = parseInt(w.x + ((path[i] - this.xmin) / xrange) * w.width);
                y1 = parseInt(w.y + (1.0 - (path[i + 1] - this.ymin) / yrange) * w.height);
                if (x1 < xcmin || x1 > xcmax || y1 < ycmin || y1 > ycmax)
                    inside1 = false;
            }
            if (!inside0 && inside1) {
                x0 = parseInt(w.x + ((path[i - stride] - this.xmin) / xrange) * w.width);
                y0 = parseInt(w.y + (1.0 - (path[i - stride + 1] - this.ymin) / yrange) * w.height);
            }
            if (inside0 || inside1) {
                var pt = g[g.length - 1];
                if (pt == undefined) {
                    g.push([x0, y0]);
                }
                g.push([x1, y1]);
            }

            inside0 = inside1;
            x0 = x1;
            y0 = y1;
        }
        return g;
    }

    this.inside = function(x, y) {
        if (x >= this.xmin && x <= this.xmax && y >= this.ymin && y <= this.ymax)
            return true;
        return false;
    }

    this.init();
};