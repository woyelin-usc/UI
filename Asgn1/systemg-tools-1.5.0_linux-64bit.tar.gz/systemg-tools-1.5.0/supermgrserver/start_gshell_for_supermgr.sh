#/bin/sh

echo $1  $2  $3  $4  $5  $6  $7  $8

cd ../

# the run command below will pick up these JAVADDS values
export JAVADDS=-Duser.home=`pwd`/home/

cd ggsserver
bin/run.sh --sandboxing off --port $1 --user $4  > ../log/run.ggs.$1.log 2>&1
