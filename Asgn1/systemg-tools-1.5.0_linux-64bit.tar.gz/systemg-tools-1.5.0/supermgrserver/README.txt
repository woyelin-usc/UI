This directory is used to run the System G Super Manager Server.  This
serve spins of personal copies of Gremlin+GShell servers for each new
user.

Starting Up

To start this server, simply invoke bin/run.sh.
The default server port is 8755.


