#!/bin/bash

spark-submit \
  --class "systemgGraph" \
  --master local[4] \
  ./target/scala-2.11/systemg-spark_2.11-1.0.jar

