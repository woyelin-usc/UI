import scala.reflect.ClassTag
import scala.collection.mutable.ArrayBuffer
import scala.util.Random
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.graphx._
import org.apache.spark.graphx.EdgeTriplet
import org.apache.log4j.Logger
import org.apache.log4j.Level

object systemgGraph {  

  def main (arg: Array[String]) {
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    val conf  = new SparkConf().setMaster("local[2]").setAppName("Simple Application").set("spark.executor.memory", "1g")
    val sc = new SparkContext(conf)

    val loader = new graphRddGenerator(sc)
    
    // load vertex csv "vfile" with column 0 as vertex id, edge csv file "efile" with column 0 as source and column 1 as target, use ',' as delimiter, with header
    // set last argument to "true" if the csv file has no header information      
    val vfile = "../../examples/data/test.vertices.csv"
    val efile = "../../examples/data/test.edges.csv"  
    loader.loadGraph(vfile, 0, efile, 0, 1, ',', false)
    
    val query = new graphRddQuery(sc, loader.getVertices(), loader.getEdges(), loader.getInvKeyMap(), loader.getVtxPropNames(), loader.getEdgePropNames())

    // print graph
    println("Graph:")
    query.printGraph()
    
    // create graph for GraphX, call PageRank, and output the result sorted by vertex id
    val g = Graph(loader.getVertices(), loader.getEdges())
    val vertex_ranks = g.pageRank(0.001).vertices
    val result = loader.getInvKeyMap.join(vertex_ranks).map{ case (vid, (vertex, rank)) =>
      (vertex, rank)  
    }
    println("PageRank result:")
    println(result.collect().sortWith((x,y)=> x._1 < y._1).mkString("\t"))    
  }
}