import scala.reflect.ClassTag
import scala.collection.mutable.ArrayBuffer
import scala.math
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.graphx._
import org.apache.spark.graphx.EdgeTriplet

/**
 * @author yxia
 */
class graphCsvEdgeLoader(sc: SparkContext) {

  def csvEdgeLoader(csvfile: String, srcIdx: Int, targIdx: Int, sep: Char, noheader: Boolean): RDD[Edge[Array[String]]] = {
    if (srcIdx == targIdx)
      return sc.emptyRDD

    val lines = sc.textFile(csvfile).filter { line => 
      if (line.isEmpty())
        false
      else
        line(0) != '#'
      }
    
    val body = if (noheader) {
      lines  
    } else {
      lines.zipWithIndex().filter(_._2>0).map(_._1)  // skip the first line
    } 
    
    val edges = body.flatMap { line =>
      if (line.isEmpty) {
        None
      } else {
        val lineArray = line.split(sep)
        val srcId = lineArray(srcIdx)
        val targId = lineArray(targIdx)

        val left = math.min(srcIdx, targIdx)
        val right = math.max(srcIdx, targIdx)

        val properties = lineArray.take(left) ++ lineArray.slice(left + 1, right) ++ lineArray.drop(right + 1)
        Some(Edge(srcId.hashCode().toLong, targId.hashCode().toLong, properties))
      }
    }
    return edges
  }
}