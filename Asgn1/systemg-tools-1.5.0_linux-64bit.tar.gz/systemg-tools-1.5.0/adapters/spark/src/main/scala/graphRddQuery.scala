import scala.reflect.ClassTag
import scala.collection.mutable.ArrayBuffer
import scala.util.Random
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.graphx._
import org.apache.spark.graphx.EdgeTriplet
import org.apache.log4j.Logger
import org.apache.log4j.Level

/**
 * @author yxia
 */
class graphRddQuery(sc:SparkContext, v:RDD[(Long,(Array[String]))], 
    e:RDD[Edge[Array[String]]], k:RDD[(Long,String)], 
    vp:RDD[String], ep:RDD[String]) {
  val edges:RDD[Edge[Array[String]]] = e
  val vertices:RDD[(Long,(Array[String]))] = v
  val vPropNames:RDD[String] = vp
  val ePropNames:RDD[String] = ep
  val InvKeyMap:RDD[(Long,String)] = k
  
  def getVtxPropName(i: Int):String= {
    val s = vPropNames.zipWithIndex.filter(_._2 == i).map(_._1)
    return if (s.isEmpty()) "n/a" else s.first()
  }
  def getEdgePropName(i: Int):String= {
    val s = ePropNames.zipWithIndex.filter(_._2 == i).map(_._1)
    return if (s.isEmpty()) "n/a" else s.first()
  }
  def getExternalKey(id:Long):String= {
    val c = InvKeyMap.filter(_._1 == id).map(_._2)
    return if (c.isEmpty()) "n/a" else c.first()
  }
  def getVertex(exid:String):(Long,(Array[String]))= {
    val vid = exid.hashCode().toLong
    val v = vertices.filter(_._1 == vid)
    return if (v.isEmpty()) (-1,(Array[String]())) else v.first()
  }
  def printVertex(v:(Long,(Array[String]))) {
    if (v._1 == -1) {
      println("vertex not found")
    } else {
      println("Vertex:")
      println("\tExternalID:\t" + getExternalKey(v._1))
      println("\tInternalID:\t" + v._1)
      print("\tProperty:\n\t\t")
      vPropNames.foreach { x => print(x + " \t") }
      print("\n\t\t")
      v._2.foreach { x => print(x + " \t") }
      println("")
    }
  }
  def getEdge(src:String, targ:String):Edge[Array[String]]= {
    val srcId:Long = src.hashCode().toLong
    val targId:Long = targ.hashCode().toLong
    val e = edges.filter { x => (x.srcId == srcId) && (x.dstId == targId) }
    return if (e.isEmpty()) Edge(-1,-1,Array[String]()) else e.first()
  }
  def printEdge(e:Edge[Array[String]]) {
    if (e.srcId == -1) {
      println("edge not found")      
    } else {
      println("Edge:")
      println("\tSrc:\t" + getExternalKey(e.srcId))
      println("\tTarg:\t" + getExternalKey(e.dstId))
      print("\tProperty:\n\t\t")
      ePropNames.foreach { x => print(x + " \t") }
      print("\n\t\t")
      e.attr.foreach{ x=> print(x+" \t")}
      println("")
    }
  }
  def findRandomVertices(n:Int):RDD[String]= {
    val r = Array.fill(n)(Random.nextLong.abs % vertices.count())
    val v = vertices.zipWithIndex.filter{ x => r.contains(x._2) }.map{_._1._1}
    return v.map{ x =>  getExternalKey(x) }
  }
  def findVertexByProp(pname:String, pval:String):RDD[(Long, (Array[String]))]= {
    val pidrdd = vPropNames.zipWithIndex.filter { x =>
      x._1 == pname
    }.map(_._2)
    if (pidrdd.isEmpty()) {
      return sc.emptyRDD
    }
    
    val pid = pidrdd.first()
    return vertices.filter{ v => 
      v._2(pid.toInt) == pval  
    }
  }
  def findEdgeByProp(pname:String, pval:String):RDD[Edge[Array[String]]]= {
    val pidrdd = ePropNames.zipWithIndex.filter(_._1 == pname).map(_._2)
    return if (pidrdd.isEmpty()) {
      sc.emptyRDD
    } else {
      val pid = pidrdd.first()
      edges.filter { e => e.attr(pid.toInt) == pval }
    }
  }
  def getNumVertices():Long= {
    return vertices.count()
  }
  def getNumEdges():Long= {
    return edges.count()
  }
  def printGraph() {    
    println("num vertices:\t" + vertices.count)
    println("num edges:\t" + edges.count)
        
    vertices.collect.foreach(printVertex)
    edges.collect.foreach(printEdge)    
  } 
}

