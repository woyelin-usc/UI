import scala.reflect.ClassTag
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.graphx._
import org.apache.spark.graphx.EdgeTriplet

/**
 * @author yxia
 */
class propMetadataMgr(sc: SparkContext) {

  def getVertexPropNames(csvfile: String, vtxIdx: Int, sep: Char, noheader: Boolean): RDD[String] = {
    val lines = sc.textFile(csvfile).filter { line => 
      if (line.isEmpty())
        false
      else  
        line(0) != '#' 
    } // skip all comment lines
    
    val headerline = lines.zipWithIndex.filter(_._2 == 0).map(_._1) // take the first line
    val headers = headerline.flatMap { line =>
      if (line.isEmpty()) {
        None
      } else {
        val fields = line.split(sep)
        val ret = fields.take(vtxIdx) ++ fields.drop(vtxIdx + 1) // skip the vtxId
        ret
      }
    }

    return if (noheader) {
      headers.zipWithIndex.map { x => "Prop_" + x._2 }
    } else { headers }       
  }
  
  def getEdgePropNames(csvfile: String, srcIdx: Int, targIdx: Int, sep: Char, noheader: Boolean): RDD[String] = {
    if (srcIdx == targIdx)
      return sc.emptyRDD
      
    val lines = sc.textFile(csvfile).filter { line => 
      if (line.isEmpty()) 
        false
      else
        line(0)!='#' 
    }
  
    val headerline = lines.zipWithIndex.filter (_._2 == 0).map(_._1)  
    val headers = headerline.flatMap { line=>
      if (line.isEmpty()) {
        None
      } else {
        val fields = line.split(sep)
        val left = math.min(srcIdx, targIdx)
        val right = math.max(srcIdx, targIdx)
        val ret = fields.take(left) ++ fields.slice(left+1, right) ++ fields.drop(right+1); // skip srcId and targId
        ret
      }
    }
    
    return if (noheader) {
      headers.zipWithIndex.map { y => "Prop_" + y._2}  
    } else { headers } 
  }
  
}