import scala.reflect.ClassTag
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.graphx._
import org.apache.spark.graphx.EdgeTriplet

/**
 * @author yxia
 */
class vertexKeyMap(sc:SparkContext) {
  
  def getKeyMapFromEdges(csvfile:String, srcIdx:Int, targIdx:Int, sep:Char):RDD[(Long,String)]= {   
    val srcMap = sc.textFile(csvfile).flatMap { line =>
      if (line.isEmpty() || line(0)=='#') {
        None
      } else {
        val lineArray = line.split(sep)
        if (lineArray.length < 2) {
          None
        } else {
          val srcId = lineArray(srcIdx)
          Some(srcId)
        }
      }
    }.map{ strId => (strId.hashCode().toLong, strId) }.reduceByKey((x,y)=>x)  //_++_??
  
    val targMap = sc.textFile(csvfile).flatMap { line =>
      if (line.isEmpty() || line(0)=='#') {
        None
      } else {
        val lineArray = line.split(sep)
        if (lineArray.length < 2) {
          None
        } else {
          val targId = lineArray(targIdx)
          Some(targId)
        }
      }
    }.map{ targId => (targId.hashCode().toLong, targId) }.reduceByKey((x,y)=>x)
  
    val edgeKeyMap = srcMap ++ targMap 
    return edgeKeyMap 
  }
  
  def getKeyMapFromVertices(csvfile:String, vtxIdx:Int, sep:Char):RDD[(Long,String)]= {
    val vtxKeyMap = sc.textFile(csvfile).flatMap{ line=>
      if (line.isEmpty() || line(0)=='#') {
        None
      } else {
        val lineArray = line.split(sep)
        if (lineArray.length < 1) {
          None
        } else {
          val vtxId = lineArray(vtxIdx)
          Some(vtxId)
        }
      }
    }.map{ vtxId => (vtxId.hashCode().toLong, vtxId) }.reduceByKey((x,y)=>x)
    
    return vtxKeyMap
  }
  
  def getKeyMapFromBothVerticesAndEdges(vtxCsvfile:String, vtxIdx:Int, edgeCsvfile:String, srcIdx:Int, targIdx:Int, sep:Char):RDD[(Long,String)]= {
    val vtxKeyMap = getKeyMapFromVertices(vtxCsvfile, vtxIdx, sep)
    val edgeKeyMap = getKeyMapFromEdges(edgeCsvfile, srcIdx, targIdx, sep)
    val allKeyMap = vtxKeyMap ++ edgeKeyMap
    return allKeyMap
  }
  
}