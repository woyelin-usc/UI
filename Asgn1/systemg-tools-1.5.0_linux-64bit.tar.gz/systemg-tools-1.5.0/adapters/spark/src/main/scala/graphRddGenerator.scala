import scala.reflect.ClassTag
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.graphx._
import org.apache.spark.graphx.EdgeTriplet

/**
 * @author yxia
 */
class graphRddGenerator(sc:SparkContext) {  
  var edges:RDD[Edge[Array[String]]] = sc.emptyRDD
  var vertices:RDD[(Long,(Array[String]))] = sc.emptyRDD
  var vPropNames:RDD[String] = sc.emptyRDD
  var ePropNames:RDD[String] = sc.emptyRDD
  var InvKeyMap:RDD[(Long,String)] = sc.emptyRDD
  
  def loadGraph(vFile:String, vIdx:Int, eFile:String, sIdx:Int, tIdx:Int, sep:Char, noheader:Boolean) {
    // load vertices
    if (vFile != "") {
      val vLoader = new graphCsvVertexLoader(sc);
      vertices = vLoader.csvVertexLoader(vFile, vIdx, sep, noheader)
    }
    
    // load edges
    if (eFile != "") {
      val eLoader = new graphCsvEdgeLoader(sc);
      edges = eLoader.csvEdgeLoader(eFile, sIdx, tIdx, sep, noheader)
    }
    
    // load property metadata
    if (vFile != "" && eFile != "") {
      val pLoader = new propMetadataMgr(sc)
      vPropNames = pLoader.getVertexPropNames(vFile, vIdx, sep, noheader)
      ePropNames = pLoader.getEdgePropNames(eFile, sIdx, tIdx, sep, noheader)
    } else {
      val pLoader = new propMetadataMgr(sc)
      ePropNames = pLoader.getEdgePropNames(eFile, sIdx, tIdx, sep, noheader)
    }
    
    // load inverse map to external IDs
    if (vFile != "" && eFile != "" ) {
      val kLoader = new vertexKeyMap(sc)
      InvKeyMap = kLoader.getKeyMapFromBothVerticesAndEdges(vFile, vIdx, eFile, sIdx, tIdx, sep).distinct()
    } else {
      val kLoader = new vertexKeyMap(sc)
      InvKeyMap = kLoader.getKeyMapFromEdges(eFile, sIdx, tIdx, sep).distinct()
    }
  }
  
  def getVertices(): RDD[(Long,(Array[String]))]=  { return vertices }
  def getEdges(): RDD[Edge[Array[String]]]= { return edges }
  def getVtxPropNames(): RDD[String]= { return vPropNames }
  def getEdgePropNames(): RDD[String]= { return ePropNames }
  def getInvKeyMap(): RDD[(Long,String)]= { return InvKeyMap }
}