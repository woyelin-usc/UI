import scala.reflect.ClassTag
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.graphx._
import org.apache.spark.graphx.EdgeTriplet

/**
 * @author yxia
 */
class graphCsvVertexLoader(sc:SparkContext) {
  
  def csvVertexLoader(csvfile:String, vtxIdx:Int, sep:Char, noheader:Boolean): RDD[(Long,(Array[String]))]= {
    val lines = sc.textFile(csvfile).filter { line => 
      if (line.isEmpty())
        false
      else
        line(0) != '#' 
    }
    
    val body = if (noheader) {
      lines
    } else {
      lines.zipWithIndex().filter(_._2>0).map(_._1)  // skip the first line
    }
    
    val vertices = body.flatMap { line => 
      if (line.isEmpty) {
        None
      } else {
        val lineArray = line.split(sep)
        val vtxId = lineArray(vtxIdx)
        val properties = lineArray.take(vtxIdx) ++ lineArray.drop(vtxIdx+1)
        Some(vtxId.hashCode().toLong, properties)
      }
    }
    return vertices
  }
}